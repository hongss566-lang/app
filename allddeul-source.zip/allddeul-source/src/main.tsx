import React from "react";
import ReactDOM from "react-dom/client";
import { AppProvider } from "./app/AppProvider";
import { App } from "./app/App";
import "@fontsource/jua/400.css";
import "./styles/global.css";

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <AppProvider>
      <App />
    </AppProvider>
  </React.StrictMode>,
);

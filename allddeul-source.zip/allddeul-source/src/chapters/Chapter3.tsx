import {
  MissionTrail,
  useFinishChapter,
} from "../components/game/MissionTrail";
import { useState } from "react";
import { useLearning } from "../app/useLearning";
import { productCases } from "../data/cases";
import {
  compare,
  decimal,
  divide,
  formatQuotient,
  formatWon,
  fraction,
  roundPrice,
  toLitres,
} from "../lib/math";
import { pairPrices, pairWinner, parseFractionAnswer } from "../lib/learning";
import {
  ChoiceButtons,
  Hint,
  Products,
  Verdict,
} from "../components/game/Shared";
import { PredictionSummary } from "../components/game/CollectionForms";
import type { CalculationRecord, Choice, ProductPair } from "../types";
import { Icon } from "../components/ui/Icon";
import s from "../components/game/Lesson.module.css";

const stageLabels = ["단위 맞추기", "나눗셈", "어림하기", "비교"];
const cleaned = (text: string) =>
  text.replace(/[\s,…]/g, "").replace(/\.{3}$/, "");
function matches(text: string, expected: string) {
  const input = parseFractionAnswer(cleaned(text));
  const value = parseFractionAnswer(cleaned(expected));
  return !!input && !!value && compare(input, value) === 0;
}

export function Chapter3() {
  const { note, patch, state, dispatch, id } = useLearning();
  const finish = useFinishChapter();
  const current =
    productCases.find((item) => item.id === note.selectedCase) ??
    productCases[0];
  const canonicalDone = note.calculations.drink?.stage === 4;
  const actualChoice = pairWinner(productCases[0]);
  const prices = pairPrices(current);
  const shelf = note.shelfWork?.[current.id] ?? {
    values: note.shelfPrices,
    checked: false,
  };
  const updateShelf = (next: Partial<typeof shelf>) =>
    patch({
      shelfWork: { ...note.shelfWork, [current.id]: { ...shelf, ...next } },
    });
  const remainingCase = productCases.find(
    (item) => note.calculations[item.id]?.stage !== 4,
  );

  return (
    <MissionTrail chapter={3}>
      <section className={s.card}>
        <h2>단계별 계산 퍼즐</h2>
        <div className={s.progress} aria-label="계산 사건 고르기">
          {productCases.map((item) => (
            <button
              key={item.id}
              disabled={item.id !== "drink" && !canonicalDone}
              aria-current={current.id === item.id ? "step" : undefined}
              onClick={() =>
                patch({ selectedCase: item.id, shelfPrices: ["", ""] })
              }
            >
              {item.label}
              {note.calculations[item.id]?.stage === 4 ? " · 해결" : ""}
            </button>
          ))}
        </div>
        <p>
          필수 금고: 음료·우유·주스 각각 네 단계를 해결해요. 현재{" "}
          {
            productCases.filter(
              (item) => note.calculations[item.id]?.stage === 4,
            ).length
          }
          /3개 해결.
        </p>
        <p className={s.caseArrival} key={current.id}>
          지금은 {current.label} 사건 · 아래 두 상품의 양과 가격을 새로
          확인해요.
        </p>
        <Products pair={current} />
        <CalculationPuzzle
          key={current.id}
          caseId={current.id}
          pair={current}
        />
        {note.calculations[current.id]?.stage === 4 && remainingCase && (
          <button
            className="btn primary"
            onClick={() =>
              patch({ selectedCase: remainingCase.id, shelfPrices: ["", ""] })
            }
          >
            다음 필수 금고 · {remainingCase.label}
          </button>
        )}
        {canonicalDone && !state.envelopeRevealed && (
          <button
            className="btn secondary"
            onClick={() =>
              patch({ missionPages: { ...note.missionPages, 3: 1 } })
            }
          >
            예측 봉투 열러 가기
          </button>
        )}
        {canonicalDone && (
          <p>
            계산을 마쳤다면 위의 ‘예측 봉투 개봉’ 미션에서 봉투도 열어 주세요.
          </p>
        )}
      </section>
      {canonicalDone && (
        <section className={s.card}>
          <h2>1장 봉인 봉투 개봉</h2>
          {!state.envelopeRevealed ? (
            <button
              className="btn primary"
              onClick={() => dispatch({ type: "reveal", participantId: id })}
            >
              <Icon name="envelope" size={20} />
              예측 봉투 열기
            </button>
          ) : (
            <div className={`${s.envelope} ${s.opened}`}>
              <Icon name="envelope" size={45} />
              <span className={s.stamp}>
                계산으로 찾은 답 ·{" "}
                {actualChoice === "same" ? "똑같다" : actualChoice}
              </span>
              <p>
                {actualChoice === "same"
                  ? "두 상품의 1L당 가격이 같아요."
                  : `${productCases[0][actualChoice].name}의 1L당 가격이 더 낮아요.`}
              </p>
              <p>
                {note.prediction
                  ? `나의 예측은 ${note.prediction.choice === "same" ? "똑같다" : note.prediction.choice}였어요. ${note.prediction.choice === actualChoice ? "예측과 계산이 같네요!" : "계산으로 첫 생각을 새롭게 살펴봤어요."}`
                  : "예측 기록이 없어도 계산으로 답을 찾을 수 있어요."}
              </p>
              <p>
                개봉 전에 {actualChoice === "same" ? "똑같다" : actualChoice}를
                예측한 모둠·개인에게 보너스 5점을 한 번 반영했어요.
              </p>
            </div>
          )}
          <PredictionSummary />
        </section>
      )}
      <section className={s.card}>
        <h2>선택 미션 · 100mL당 가격으로 바꿔 보기</h2>
        <p>
          앞에서 구한 1L당 가격을 이용해 100mL당 가격을 구해 보세요. 1L는
          100mL의 10배이므로 1L당 가격을 10으로 나누어요. 반올림하여 일의
          자리까지 나타내세요.
        </p>
        <p>
          지금 고른 상품: <strong>{current.label}</strong> · 이 활동은
          건너뛰어도 돼요.
        </p>
        {(note.calculations[current.id]?.stage ?? 0) >= 2 ? (
          <>
            <div className={s.grid}>
              {(["A", "B"] as const).map((key, i) => (
                <div key={key}>
                  <p>
                    상품 {key}의 1L당 가격: {formatQuotient(prices[key])}원
                  </p>
                  <label>
                    상품 {key}의 100mL당 가격 (원)
                    <input
                      inputMode="numeric"
                      value={shelf.values[i]}
                      maxLength={24}
                      onChange={(event) =>
                        updateShelf({
                          values: shelf.values.map((value, index) =>
                            index === i ? event.target.value : value,
                          ) as [string, string],
                          checked: false,
                        })
                      }
                    />
                  </label>
                  {shelf.checked && (
                    <p
                      className={
                        matches(
                          shelf.values[i],
                          roundPrice(
                            divide(prices[key], fraction(10)),
                          ).toString(),
                        )
                          ? s.success
                          : s.feedback
                      }
                    >
                      {matches(
                        shelf.values[i],
                        roundPrice(
                          divide(prices[key], fraction(10)),
                        ).toString(),
                      )
                        ? "맞았어요! "
                        : "반올림할 자리를 다시 확인해 봐요. "}
                      {formatQuotient(prices[key])} ÷ 10 ={" "}
                      {formatQuotient(divide(prices[key], fraction(10)))} →
                      반올림하면 {formatWon(divide(prices[key], fraction(10)))}{" "}
                      / 100mL
                    </p>
                  )}
                </div>
              ))}
            </div>
            <button
              className="btn primary"
              style={{ marginTop: 18 }}
              disabled={shelf.values.some((value) => !value.trim())}
              onClick={() => updateShelf({ checked: true })}
            >
              100mL당 가격 확인하기
            </button>
          </>
        ) : (
          <p>
            먼저 ‘네 칸의 계산 금고’에서 {current.label}의 나눗셈까지 확인하면
            이 활동을 할 수 있어요.
          </p>
        )}
        {state.mode !== "teacher" && (
          <button
            className="btn secondary"
            style={{ marginTop: 18 }}
            onClick={finish}
          >
            건너뛰고 사건 해결로 이동
          </button>
        )}
      </section>
    </MissionTrail>
  );
}
function CalculationPuzzle({
  caseId,
  pair,
}: {
  caseId: string;
  pair: ProductPair;
}) {
  const { note, patch, reward } = useLearning();
  const [message, setMessage] = useState("");
  const record: CalculationRecord = note.calculations[caseId] ?? {
    stage: 0,
    place: 1,
    entries: [[], [], [], []],
  };
  const stage = record.stage;
  const prices = pairPrices(pair);
  const update = (next: Partial<CalculationRecord>) =>
    patch({
      calculations: { ...note.calculations, [caseId]: { ...record, ...next } },
    });
  const input = (index: number, text: string) =>
    update({
      entries: record.entries.map((row, step) =>
        step === stage
          ? Array.from({ length: stage === 3 ? 1 : 2 }, (_, i) =>
              i === index ? text : (row[i] ?? ""),
            )
          : row,
      ),
    });
  const expected =
    stage === 0
      ? (["A", "B"] as const).map((key) =>
          formatQuotient(toLitres(pair[key].amount, pair[key].unit)),
        )
      : stage === 1
        ? [formatQuotient(prices.A), formatQuotient(prices.B)]
        : [
            roundPrice(prices.A, record.place).toString(),
            roundPrice(prices.B, record.place).toString(),
          ];
  const check = () => {
    const correct =
      stage === 3
        ? record.entries[3][0] === pairWinner(pair)
        : expected.every((answer, index) =>
            matches(record.entries[stage][index] ?? "", answer),
          );
    if (!correct) {
      setMessage("다시 생각해 봐요. 단위와 자릿수를 확인하고 힌트를 볼까요?");
      return;
    }
    update({ stage: stage + 1 });
    reward(`c3-${caseId}-${stage}`, 8, 3);
    setMessage("좋아요! 다음 계산 단서가 열렸어요.");
  };
  return (
    <div>
      <label style={{ marginTop: 22 }}>
        어림하기
        <select
          aria-label="어림하기"
          value={record.place}
          onChange={(event) => {
            update({
              place: Number(event.target.value) as 1 | 10,
              stage: Math.min(record.stage, 2),
            });
            setMessage(
              "반올림할 자리를 바꿨어요. 어림하기부터 다시 확인해 봐요.",
            );
          }}
        >
          <option value="1">반올림하여 일의 자리까지</option>
          <option value="10">반올림하여 십의 자리까지</option>
        </select>
      </label>
      <ol>
        {stageLabels.map((label, i) => (
          <li key={label}>
            {i < stage ? "완료 · " : ""}
            {label}
          </li>
        ))}
      </ol>
      {stage > 0 && (
        <div className={s.evidenceScroll}>
          <table className={s.evidenceTable}>
            <caption>
              {pair.A.name}와 {pair.B.name} · 내가 확인한 계산 기록
            </caption>
            <thead>
              <tr>
                <th scope="col">상품</th>
                <th scope="col">양과 나눗셈 식</th>
                {stage > 1 && (
                  <th scope="col">
                    어림하기 전 몫<br />
                    (원/L)
                  </th>
                )}
                {stage > 2 && (
                  <th scope="col">
                    반올림한 가격
                    <br />
                    (원/L)
                  </th>
                )}
              </tr>
            </thead>
            <tbody>
              {(["A", "B"] as const).map((key, i) => (
                <tr key={key}>
                  <th scope="row">{key}</th>
                  <td>
                    {record.entries[0][i]}L<br />
                    {Number(pair[key].price).toLocaleString("ko-KR")} ÷{" "}
                    {record.entries[0][i]}
                  </td>
                  {stage > 1 && (
                    <td>
                      <strong>
                        {record.entries[1][i]}
                        {formatQuotient(prices[key]).endsWith("…") ? "…" : ""}
                      </strong>
                    </td>
                  )}
                  {stage > 2 && <td>{record.entries[2][i]}원</td>}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {stage < 4 ? (
        <>
          <h3>
            {stage + 1}단계 · {stageLabels[stage]}
          </h3>
          {stage === 0 && (
            <p>각 상품의 양을 L로 바꾸어 적어요. 이미 L라면 그대로 적어요.</p>
          )}
          {stage === 1 && (
            <p>
              가격 ÷ 양(L)을 계산해요. 나누어떨어지면 몫을 그대로 적어요. 끝나지
              않는 몫은 버림하여 소수 둘째 자리까지 나타내세요. 쉼표와 …는
              생략해도 좋아요.
            </p>
          )}
          {stage === 2 && (
            <p>
              앞에서 소수 둘째 자리까지 나타낸 수가 아닌 원래 몫을 반올림하여{" "}
              {record.place === 1 ? "일의 자리" : "십의 자리"}까지 나타내세요.
            </p>
          )}
          {stage < 3 ? (
            <div className={s.grid}>
              {(["A", "B"] as const).map((key, i) => (
                <label key={key}>
                  상품 {key}{" "}
                  {stage === 0
                    ? "양 (L)"
                    : stage === 1
                      ? "나눗셈의 몫"
                      : "어림한 가격 (원)"}
                  <input
                    inputMode="decimal"
                    value={record.entries[stage][i] ?? ""}
                    maxLength={64}
                    onChange={(event) => input(i, event.target.value)}
                  />
                </label>
              ))}
            </div>
          ) : (
            <>
              <p>어림하기 전의 몫이 더 작은 상품은 어느 쪽인가요?</p>
              <ChoiceButtons
                label="더 저렴한 상품"
                value={record.entries[3][0]}
                onChange={(choice: Choice) => input(0, choice)}
              />
            </>
          )}
          <button
            className="btn primary"
            style={{ marginTop: 18 }}
            onClick={check}
          >
            이 단계 확인하기
          </button>
          <p role="status">{message}</p>
          <Hint
            task={`c3-${caseId}-${stage}`}
            hints={[
              "가격을 같은 양으로 맞추려면 먼저 단위를 맞추어야 해요. 비교는 어림하기 전 값으로 해요.",
              <>
                A: {Number(pair.A.price).toLocaleString("ko-KR")} ÷{" "}
                {formatQuotient(toLitres(pair.A.amount, pair.A.unit))}, B:{" "}
                {Number(pair.B.price).toLocaleString("ko-KR")} ÷{" "}
                {formatQuotient(toLitres(pair.B.amount, pair.B.unit))}를
                살펴봐요.
              </>,
              <>
                <p>
                  L 단위 양: A{" "}
                  {formatQuotient(toLitres(pair.A.amount, pair.A.unit))}, B{" "}
                  {formatQuotient(toLitres(pair.B.amount, pair.B.unit))}
                </p>
                <p>
                  몫: A {formatQuotient(prices.A)}, B {formatQuotient(prices.B)}
                </p>
                <p>
                  어림하기: A {formatWon(prices.A, record.place)}, B{" "}
                  {formatWon(prices.B, record.place)}
                </p>
                <p>
                  알뜰 선택:{" "}
                  {pairWinner(pair) === "same" ? "똑같다" : pairWinner(pair)}
                </p>
              </>,
            ]}
          />
        </>
      ) : (
        <>
          <Verdict pair={pair} place={record.place} />
          <p>이 사건의 네 단계를 모두 해결했어요. 다음 연습 사건도 살펴봐요.</p>
        </>
      )}
    </div>
  );
}

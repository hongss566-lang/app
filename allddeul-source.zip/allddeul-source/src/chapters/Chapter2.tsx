import { MissionTrail } from "../components/game/MissionTrail";
import { useState } from "react";
import { useLearning } from "../app/useLearning";
import { fractionCases } from "../data/cases";
import { parseFractionAnswer, scoopQuotient } from "../lib/learning";
import { compare, fraction, reciprocalSteps, toMixed } from "../lib/math";
import { FractionInput } from "../components/math/FractionInput";
import { Fraction } from "../components/math/Fraction";
import { Hint } from "../components/game/Shared";
import s from "../components/game/Lesson.module.css";

export function Chapter2() {
  const { note, patch, reward } = useLearning();
  const [message, setMessage] = useState("");
  const index = note.fractionIndex;
  const item = fractionCases[index];
  const record = note.scoops[item.id] ?? {
    prediction: "",
    locked: false,
    scoops: 0,
    done: false,
  };
  const dividend = fraction(item.a[0], item.a[1]),
    divisor = fraction(item.b[0], item.b[1]);
  const answer = scoopQuotient(index);
  const full = Number(answer.numerator / answer.denominator);
  const partial =
    Number(answer.numerator % answer.denominator) / Number(answer.denominator);
  const cups = full + (partial > 0 ? 1 : 0);
  const update = (entry: Partial<typeof record>) =>
    patch({ scoops: { ...note.scoops, [item.id]: { ...record, ...entry } } });
  const scoop = () => {
    if (!record.locked || record.done) return;
    const next = record.scoops + 1;
    const done = next >= cups;
    update({ scoops: next, done });
    if (done) {
      reward(`c2-${item.id}`, 10, 2);
      const prediction = parseFractionAnswer(record.prediction);
      if (prediction && compare(prediction, answer) === 0) {
        reward(`c2-prediction-${item.id}`, 3, 2);
        setMessage("예측이 맞았어요! 보너스 단서도 찾았어요.");
      } else
        setMessage("실험으로 몫을 찾아냈어요. 처음 생각과 어떻게 달랐나요?");
    }
  };
  const mixed = toMixed(answer);
  return (
    <MissionTrail chapter={2}>
      <section className={s.card}>
        <h2>도입 · 6을 반 컵씩 덜어내면?</h2>
        <div className={s.math}>
          6 ÷ <Fraction value={fraction(1, 2)} /> = ?
        </div>
        <div className={s.choices} role="group" aria-label="도입 예측">
          {["3", "12"].map((value) => (
            <button
              key={value}
              aria-pressed={note.introGuess === value}
              disabled={!!note.scoops["six-half"]?.done}
              onClick={() => patch({ introGuess: value })}
            >
              {value}번일 것 같아요
            </button>
          ))}
        </div>
        <p>
          {note.scoops["six-half"]?.done
            ? "반 컵은 1L 안에 두 번 들어가요. 6L에는 열두 번 들어가네요!"
            : "생각을 고른 다음 아래 실험으로 확인해 봐요."}
        </p>
      </section>
      <section className={s.card}>
        <h2>덜어내기 실험실</h2>
        <div className={s.progress} aria-label="덜어내기 문제">
          {fractionCases.map((c, i) => (
            <button
              key={c.id}
              aria-current={i === index ? "step" : undefined}
              disabled={i > 0 && !note.scoops[fractionCases[i - 1].id]?.done}
              onClick={() => {
                patch({ fractionIndex: i });
                setMessage("");
              }}
            >
              레벨 {c.level} · {i + 1}
              {note.scoops[c.id]?.done ? " 완료" : ""}
            </button>
          ))}
        </div>
        <div className={s.math}>
          <Fraction value={dividend} mixed />L ÷ <Fraction value={divisor} />L
        </div>
        <FractionInput
          key={item.id}
          value={record.prediction}
          disabled={record.locked}
          onChange={(prediction) => update({ prediction })}
        />
        {!record.locked && (
          <button
            className="btn primary"
            style={{ marginTop: 16 }}
            disabled={!note.introGuess || !record.prediction.trim()}
            onClick={() => {
              if (!parseFractionAnswer(record.prediction))
                setMessage(
                  "답의 모양을 고르고 숫자 칸을 모두 채워 주세요. 분모는 0보다 커야 해요.",
                );
              else {
                update({ locked: true });
                setMessage("예측을 담았어요. 한 컵씩 덜어 보세요.");
              }
            }}
          >
            예측하고 실험하기
          </button>
        )}
        <p className={s.totalVolume}>
          전체 <Fraction value={dividend} mixed />L
        </p>
        <div className={s.volumeScale} aria-label="물통의 L 눈금">
          {Array.from(
            {
              length:
                Math.floor(
                  Number(dividend.numerator) / Number(dividend.denominator),
                ) + 1,
            },
            (_, litre) => (
              <span
                key={litre}
                style={{
                  left: `${(litre / (Number(dividend.numerator) / Number(dividend.denominator))) * 100}%`,
                }}
              >
                {litre}L
              </span>
            ),
          )}
          {dividend.denominator !== 1n && (
            <span style={{ left: "100%" }}>
              <Fraction value={dividend} mixed />L
            </span>
          )}
        </div>
        <div className={s.waterContainer}>
          <div
            className={s.water}
            role="img"
            aria-label={`${cups}칸 중 ${record.scoops}칸 덜어냈어요${partial ? ", 마지막 컵은 일부만 채워져요" : ""}`}
            onDragOver={(event) => event.preventDefault()}
            onDrop={(event) => {
              event.preventDefault();
              scoop();
            }}
          >
            {Array.from({ length: cups }, (_, i) => (
              <div
                key={i}
                className={`${s.cupSegment} ${i < record.scoops ? s.filled : ""} ${i === full && partial ? s.partial : ""}`}
                style={{
                  width: `${((i === full && partial ? partial : 1) / (full + partial)) * 100}%`,
                }}
              >
                {i < record.scoops &&
                  (i < full ? (
                    i + 1
                  ) : (
                    <Fraction
                      value={fraction(
                        answer.numerator % answer.denominator,
                        answer.denominator,
                      )}
                    />
                  ))}
              </div>
            ))}
          </div>
          <div className={s.litreLines} aria-hidden="true">
            {Array.from(
              {
                length:
                  Math.ceil(
                    Number(dividend.numerator) / Number(dividend.denominator),
                  ) - 1,
              },
              (_, i) => (
                <span
                  key={i}
                  style={{
                    left: `${((i + 1) / (Number(dividend.numerator) / Number(dividend.denominator))) * 100}%`,
                  }}
                />
              ),
            )}
          </div>
        </div>
        <p className={s.muted}>
          칸 안의 숫자는 덜어낸 컵 수예요. 가는 점선은 한 컵의 경계, 굵은 실선은
          1L마다의 눈금이에요.
        </p>
        <button
          className={s.cupButton}
          draggable={record.locked && !record.done}
          onDragStart={(event) =>
            event.dataTransfer.setData("text/plain", "cup")
          }
          disabled={!record.locked || record.done}
          onClick={scoop}
        >
          한 컵 덜어내기 · <Fraction value={divisor} />L
        </button>
        <p>
          컵을 누르거나 물통으로 끌어다 놓아요. 마지막 컵은 남은 만큼만 채워요.
        </p>
        <p>
          덜어낸 컵:{" "}
          {record.done ? (
            <>
              <Fraction value={answer} mixed /> 컵만큼
            </>
          ) : (
            `${record.scoops}컵`
          )}
        </p>
        {record.done && (
          <div className={s.success}>
            <div className={s.math}>
              <Fraction value={dividend} mixed /> ÷ <Fraction value={divisor} />{" "}
              = <Fraction value={dividend} mixed /> ×{" "}
              <Fraction
                value={reciprocalSteps(dividend, divisor).reciprocal}
                raw
              />{" "}
              = <Fraction value={answer} mixed />
            </div>
            {partial > 0 && (
              <p>
                가득 찬 {mixed.whole.toString()}컵과 마지막 컵의{" "}
                <Fraction
                  value={fraction(mixed.numerator, mixed.denominator)}
                />
                만큼이에요.
              </p>
            )}
            {index < 5 && (
              <button
                className="btn primary"
                onClick={() => {
                  patch({ fractionIndex: index + 1 });
                  setMessage("");
                }}
              >
                다음 실험
              </button>
            )}
          </div>
        )}
        <p role="status">{message}</p>
        <Hint
          task={`c2-${item.id}`}
          hints={[
            "한 컵의 양이 1L보다 작으면 1L에서 여러 번 덜어낼 수 있어요.",
            <>
              나누는 수 <Fraction value={divisor} />의 분자와 분모를 바꾸어 곱해
              보세요.
            </>,
            <>
              <Fraction value={dividend} mixed /> ×{" "}
              <Fraction
                value={reciprocalSteps(dividend, divisor).reciprocal}
                raw
              />{" "}
              = <Fraction value={answer} mixed />
            </>,
          ]}
        />
      </section>
      <section className={s.card}>
        <h2>발견한 수학 원리</h2>
        <p>1보다 작은 양으로 나누면 몫이 처음 수보다 커져요.</p>
        <p>
          분수로 나누는 것은 나누는 수의 분자와 분모를 바꾸어 곱하는 것과
          같아요.
        </p>
      </section>
    </MissionTrail>
  );
}

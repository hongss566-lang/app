import {
  MissionTrail,
  useMissionNavigation,
} from "../components/game/MissionTrail";
import { CartCourse } from "../components/game/CartCourse";
import { useEffect, useState } from "react";
import { useLearning } from "../app/useLearning";
import {
  productCases,
  speedCases,
  speedSeconds,
  studentPrompts,
} from "../data/cases";
import { clonePair, pairPrices, pairWinner, validPair } from "../lib/learning";
import { formatQuotient, toLitres } from "../lib/math";
import {
  ChoiceButtons,
  Hint,
  Products,
  PromptCard,
  Verdict,
} from "../components/game/Shared";
import type { Choice, ProductPair } from "../types";
import s from "../components/game/Lesson.module.css";

export function ProductEditor({
  pair,
  onChange,
}: {
  pair: ProductPair;
  onChange: (pair: ProductPair) => void;
}) {
  return (
    <div className={s.grid}>
      {(["A", "B"] as const).map((key) => (
        <div key={key} className={s.product} data-product={key}>
          <div className={s.productHead}>
            <span className={s.letter}>{key}</span>
            <h3>상품 {key}</h3>
          </div>
          <div className={s.editor}>
            {(["name", "price", "amount"] as const).map((field) => (
              <label key={field}>
                상품 {key}{" "}
                {field === "name"
                  ? "이름"
                  : field === "price"
                    ? "가격 (원)"
                    : "양"}
                <input
                  maxLength={field === "name" ? 80 : 24}
                  inputMode={field === "name" ? "text" : "decimal"}
                  value={pair[key][field]}
                  onChange={(event) =>
                    onChange({
                      ...pair,
                      [key]: { ...pair[key], [field]: event.target.value },
                    })
                  }
                />
              </label>
            ))}
            <label>
              상품 {key} 단위
              <select
                value={pair[key].unit}
                onChange={(event) =>
                  onChange({
                    ...pair,
                    [key]: {
                      ...pair[key],
                      unit: event.target.value as "L" | "mL",
                    },
                  })
                }
              >
                <option>L</option>
                <option>mL</option>
              </select>
            </label>
          </div>
        </div>
      ))}
    </div>
  );
}
export function Chapter5() {
  const { note, patch, reward } = useLearning();
  const [error, setError] = useState("");
  const usePair = (pair: ProductPair) => {
    patch({
      toolPair: clonePair(pair),
      toolCalculated: false,
      handVerified: false,
    });
    setError("");
  };
  return (
    <MissionTrail chapter={5}>
      <section className={s.card}>
        <h2>미션 1 · 나의 알뜰 소비 탐정기</h2>
        <p>가격과 양은 소수 셋째 자리까지 적어요. 단위는 L 또는 mL로 골라요.</p>
        <div className={s.choices} role="group" aria-label="탐정기 예시 상품">
          {productCases.map((pair) => (
            <button key={pair.id} onClick={() => usePair(pair)}>
              {pair.label} 예시 넣기
            </button>
          ))}
        </div>
        <ProductEditor pair={note.toolPair} onChange={usePair} />
        <button
          className="btn primary"
          style={{ marginTop: 20 }}
          onClick={() => {
            const message = validPair(note.toolPair);
            if (message) {
              setError(message);
              return;
            }
            setError("");
            patch({ toolCalculated: true });
            reward("c5-tool", 10, 5);
          }}
        >
          1L당 가격 비교하기
        </button>
        {error && (
          <p role="alert" className={s.feedback}>
            {error}
          </p>
        )}
        {note.toolCalculated && !validPair(note.toolPair) && (
          <Verdict pair={note.toolPair} />
        )}
      </section>
      <SpeedRound />
      <PromptCard text={studentPrompts.make} />
    </MissionTrail>
  );
}
function SpeedRound() {
  const { note, state, patch, reward, dispatch } = useLearning();
  const goToMission = useMissionNavigation();
  const speed = note.speed;
  const [now, setNow] = useState(Date.now());
  const [feedback, setFeedback] = useState<{
    index: number;
    correct: boolean;
  }>();
  const timeout = () => {
    if (speed && !speed.finished)
      patch({
        speed: {
          ...speed,
          answers: [
            ...speed.answers,
            ...Array.from(
              { length: 5 - speed.answers.length },
              () => "timeout" as const,
            ),
          ],
          elapsedMs: speedSeconds * 1000,
          finished: true,
        },
      });
  };
  useEffect(() => {
    if (!speed || speed.finished) return;
    const tick = () => {
      const time = Date.now();
      setNow(time);
      if (speed.timed && time - speed.startedAt >= speedSeconds * 1000)
        timeout();
    };
    tick();
    const timer = window.setInterval(tick, 250);
    return () => window.clearInterval(timer);
  }, [speed]);
  const elapsed = speed
    ? Math.max(0, speed.finished ? speed.elapsedMs : now - speed.startedAt)
    : 0;
  const index = feedback?.index ?? Math.min(speed?.answers.length ?? 0, 4);
  const pair = speedCases[index];
  const choose = (choice: Choice) => {
    if (!speed || speed.finished || feedback) return;
    const duration = Math.max(0, Date.now() - speed.startedAt);
    if (speed.timed && duration >= speedSeconds * 1000) {
      timeout();
      return;
    }
    const correct = choice === pairWinner(pair);
    const answers = [...speed.answers, choice];
    const finished = answers.length === 5;
    patch({ speed: { ...speed, answers, elapsedMs: duration, finished } });
    if (correct) reward(`c5-speed-${index}`, 8, 5);
    if (finished) {
      const count = answers.filter(
        (answer, i) => answer === pairWinner(speedCases[i]),
      ).length;
      if (count >= 3 && duration <= 90000) reward("c5-speed-time", 5, 5);
    } else setFeedback({ index, correct });
  };
  const start = () => {
    const time = Date.now();
    patch({
      speed: {
        startedAt: time,
        elapsedMs: 0,
        answers: [],
        timed: state.settings.speedLimit,
        finished: false,
      },
    });
    setNow(time);
    setFeedback(undefined);
  };
  return (
    <section className={s.card}>
      <h2>미션 2 · 반짝마트 스피드 라운드</h2>
      <CartCourse visited={speed?.answers.length ?? 0} />
      <p>
        다섯 상품 쌍에서 알뜰 선택을 찾아요. 탐정기에 넣거나 직접 계산해도
        좋아요.
      </p>
      {!speed ? (
        <>
          {state.mode !== "teacher" && (
            <label className={s.checkLabel}>
              <input
                type="checkbox"
                checked={state.settings.speedLimit}
                onChange={(event) =>
                  dispatch({
                    type: "settings",
                    patch: { speedLimit: event.target.checked },
                  })
                }
              />
              선택 도전 · 150초 시간 제한 켜기
            </label>
          )}
          <p>
            시간 제한은 현재{" "}
            {state.settings.speedLimit
              ? "켜져 있어요. 150초 안에 다섯 문제를 도전해요."
              : "꺼져 있어요. 천천히 생각해도 괜찮아요."}
          </p>
          <button className="btn primary" onClick={start}>
            스피드 라운드 시작
          </button>
        </>
      ) : speed.finished ? (
        <>
          <div className={s.success}>
            <h3>다섯 사건을 살펴봤어요!</h3>
            <p>
              정답{" "}
              {
                speed.answers.filter(
                  (answer, i) => answer === pairWinner(speedCases[i]),
                ).length
              }{" "}
              / 5 · 걸린 시간 {Math.floor(speed.elapsedMs / 1000)}초
            </p>
            <p>
              정답마다 기본 8점, 세 문제 이상을 90초 안에 맞히면 보너스
              5점이에요. 힌트 보상 감소는 각 문제에 적용돼요.
            </p>
            <p>
              시간이 끝났거나 틀린 문제도 아래 풀이로 다시 살펴봐요. 감점은
              없어요.
            </p>
          </div>
          {speedCases.map((item, i) => (
            <details key={item.id} className={s.hint}>
              <summary>
                {i + 1}번 {item.A.name} vs {item.B.name} ·{" "}
                {speed.answers[i] === "timeout"
                  ? "시간 종료"
                  : speed.answers[i] === pairWinner(item)
                    ? "맞았어요"
                    : "다시 살펴보기"}
              </summary>
              <Verdict pair={item} />
            </details>
          ))}
          <button className="btn secondary" onClick={start}>
            다시 연습하기
          </button>
          <p className={s.muted}>
            다시 연습해도 같은 문제의 점수는 중복해서 주지 않아요.
          </p>
        </>
      ) : (
        <>
          <div className={s.row}>
            <span className={s.tag}>{index + 1} / 5 사건</span>
            <span aria-label="걸린 시간">{Math.floor(elapsed / 1000)}초</span>
            {speed.timed && (
              <span>
                남은 시간{" "}
                {Math.max(0, speedSeconds - Math.floor(elapsed / 1000))}초
              </span>
            )}
          </div>
          <Products pair={pair} />
          <button
            className="btn secondary"
            style={{ marginTop: 18 }}
            onClick={() => {
              patch({
                toolPair: clonePair(pair),
                toolCalculated: false,
                handVerified: false,
              });
              goToMission(0);
            }}
          >
            이 상품을 위 탐정기에 넣기
          </button>
          <ChoiceButtons
            value={speed.answers[index]}
            disabled={!!feedback}
            onChange={choose}
            label="스피드 라운드 알뜰 선택"
          />
          {feedback && (
            <div className={feedback.correct ? s.success : s.feedback}>
              <p>
                {feedback.correct
                  ? "알뜰 선택을 찾았어요!"
                  : "다시 생각해 봐요. 가격을 양(L)으로 나누면 단서를 찾을 수 있어요."}
              </p>
              <button
                className="btn secondary"
                onClick={() => setFeedback(undefined)}
              >
                다음 상품 쌍
              </button>
            </div>
          )}
          <Hint
            task={`c5-speed-${index}`}
            hints={[
              "표시된 가격만 보지 말고, 두 상품을 같은 양으로 맞춰 봐요.",
              <>
                A: {Number(pair.A.price).toLocaleString("ko-KR")} ÷{" "}
                {formatQuotient(toLitres(pair.A.amount, pair.A.unit))}, B:{" "}
                {Number(pair.B.price).toLocaleString("ko-KR")} ÷{" "}
                {formatQuotient(toLitres(pair.B.amount, pair.B.unit))}를
                계산해요.
              </>,
              <Verdict pair={pair} />,
            ]}
          />
        </>
      )}
    </section>
  );
}

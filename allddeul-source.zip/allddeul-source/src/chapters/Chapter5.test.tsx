import { act, render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import { AppProvider } from "../app/AppProvider";
import { emptyNotebook } from "../lib/learning";
import { initialState, saveState, STORAGE_KEY } from "../lib/storage";
import { Chapter5 } from "./Chapter5";

describe("스피드 라운드의 실제 시간 제한", () => {
  it("제한 시간이 지나면 남은 문제를 시간 종료로 저장하고 감점하지 않는다", () => {
    vi.useFakeTimers();
    const note = emptyNotebook();
    note.missionPages = { 5: 1 };
    note.speed = {
      startedAt: Date.now() - 149000,
      elapsedMs: 0,
      answers: ["A"],
      timed: true,
      finished: false,
    };
    saveState({ ...initialState(), mode: "group", learning: { g1: note } });
    const app = render(
      <AppProvider>
        <Chapter5 />
      </AppProvider>,
    );
    try {
      act(() => {
        vi.advanceTimersByTime(1500);
      });
      expect(
        screen.getByRole("heading", { name: "다섯 사건을 살펴봤어요!" }),
      ).toBeInTheDocument();
      const state = JSON.parse(localStorage.getItem(STORAGE_KEY)!);
      expect(state.learning.g1.speed.answers).toEqual([
        "A",
        "timeout",
        "timeout",
        "timeout",
        "timeout",
      ]);
      expect(state.learning.g1.speed.finished).toBe(true);
      expect(state.scores).toEqual([]);
    } finally {
      app.unmount();
      vi.useRealTimers();
    }
  });
  it("시간 제한을 끄면 오래 걸려도 문제를 강제로 끝내지 않는다", () => {
    vi.useFakeTimers();
    const note = emptyNotebook();
    note.missionPages = { 5: 1 };
    note.speed = {
      startedAt: Date.now() - 600000,
      elapsedMs: 0,
      answers: [],
      timed: false,
      finished: false,
    };
    saveState({ ...initialState(), mode: "group", learning: { g1: note } });
    const app = render(
      <AppProvider>
        <Chapter5 />
      </AppProvider>,
    );
    try {
      act(() => {
        vi.advanceTimersByTime(3000);
      });
      expect(
        screen.getByRole("group", { name: "스피드 라운드 알뜰 선택" }),
      ).toBeInTheDocument();
      expect(
        JSON.parse(localStorage.getItem(STORAGE_KEY)!).learning.g1.speed
          .finished,
      ).toBe(false);
    } finally {
      app.unmount();
      vi.useRealTimers();
    }
  });
});

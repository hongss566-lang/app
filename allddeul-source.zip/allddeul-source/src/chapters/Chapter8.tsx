import { MilkLab } from "../components/game/MilkLab";
import { CertificateArt } from "../components/game/CertificateArt";
import { MissionTrail } from "../components/game/MissionTrail";
import { useCallback, useState } from "react";
import { useLearning } from "../app/useLearning";
import { adCases, badgeNames, productCases } from "../data/cases";
import { chapterReady, pairPrices, pairWinner } from "../lib/learning";
import {
  compare,
  decimal,
  divide,
  formatQuotient,
  formatWon,
  unitPrice,
} from "../lib/math";
import {
  ChoiceButtons,
  Hint,
  Products,
  Verdict,
} from "../components/game/Shared";
import { FamilyForm, FamilySummary } from "../components/game/CollectionForms";
import { Presentation } from "../components/game/Presentation";
import { Icon } from "../components/ui/Icon";
import { rankFor, scoreFor } from "../lib/scoring";
import type { Choice } from "../types";
import s from "../components/game/Lesson.module.css";

export function Chapter8() {
  const { note, patch, reward, state, id } = useLearning();
  const [adChoices, setAdChoices] = useState<Record<string, Choice>>(note.ads);
  const [messages, setMessages] = useState<Record<string, string>>({});
  const milk = productCases[1];
  return (
    <MissionTrail chapter={8}>
      <MilkLab />
      <section className={s.card}>
        <h2>게임 2 · 우리 가족에게 알맞은 선택</h2>
        <Products pair={milk} />
        <FamilyForm />
        {state.mode === "teacher" && <FamilySummary />}
      </section>
      <section className={s.card}>
        <h2>게임 3 · 헷갈리는 광고를 찾아라</h2>
        <p>
          아래 상품명과 가격, 양은 모두 수업을 위해 만든 가상 예시예요. 광고가
          붙어도 항상 더 저렴하지는 않아요.
        </p>
        <div className={s.stack}>
          {adCases.map((item) => (
            <article className={s.card} key={item.id}>
              <span className={s.tag}>가상 광고</span>
              <h3 style={{ marginTop: 14 }}>{item.headline}</h3>
              <Products pair={item} />
              <ChoiceButtons
                label={`${item.headline} 알뜰 선택`}
                value={adChoices[item.id]}
                disabled={!!note.ads[item.id]}
                onChange={(choice) =>
                  setAdChoices((previous) => ({
                    ...previous,
                    [item.id]: choice,
                  }))
                }
              />
              <button
                className="btn primary"
                disabled={!adChoices[item.id] || !!note.ads[item.id]}
                onClick={() => {
                  const correct = adChoices[item.id] === pairWinner(item);
                  if (correct) {
                    patch({
                      ads: { ...note.ads, [item.id]: adChoices[item.id] },
                    });
                    reward(`c8-ad-${item.id}`, 10, 8);
                  }
                  setMessages((previous) => ({
                    ...previous,
                    [item.id]: correct
                      ? "계산으로 광고 속 단서를 찾았어요!"
                      : "다시 생각해 봐요. 묶음의 전체 양과 실제 내는 가격으로 나누어 봐요.",
                  }));
                }}
              >
                {note.ads[item.id]
                  ? "광고 확인 완료"
                  : "광고 속 알뜰 선택 확인하기"}
              </button>
              {(note.ads[item.id] || messages[item.id]) && (
                <p
                  role="status"
                  className={note.ads[item.id] ? s.success : s.feedback}
                >
                  {note.ads[item.id]
                    ? "단위가격을 계산해 광고를 확인했어요."
                    : messages[item.id]}
                </p>
              )}
              {note.ads[item.id] && <Verdict pair={item} />}
              <Hint
                task={`c8-ad-${item.id}`}
                hints={[
                  "1+1이나 묶음이면 전체 양을 먼저 구해요. 광고 문구만으로 판단하지 않아요.",
                  <>
                    묶음 전체 가격을 전체 양(L)으로 나누어요. A와 B를 같은 1L
                    기준으로 맞추어요.
                  </>,
                  <Verdict pair={item} />,
                ]}
              />
            </article>
          ))}
        </div>
      </section>
      <section className={s.card}>
        <h2>우리 반 알뜰 소비 다짐</h2>
        <label>
          앞으로 나는 이렇게 선택할 거예요
          <textarea
            aria-label="앞으로 나는 이렇게 선택할 거예요"
            value={note.pledge}
            maxLength={1000}
            placeholder="예: 단위가격을 확인하고, 다 마실 수 있는 만큼만 산다."
            onChange={(event) =>
              patch({ pledge: event.target.value, pledgeSaved: false })
            }
          />
        </label>
        <button
          className="btn primary"
          style={{ marginTop: 16 }}
          disabled={!note.pledge.trim()}
          onClick={() => {
            patch({ pledge: note.pledge.trim(), pledgeSaved: true });
            reward("c8-pledge", 10, 8);
          }}
        >
          소비 다짐 남기기
        </button>
        {note.pledgeSaved && (
          <p role="status" className={s.success}>
            우리의 다짐을 수첩에 담았어요.
          </p>
        )}
        <p>
          {chapterReady(state, id, 8)
            ? "이번 장의 미션을 마쳤어요. 사건 해결 단계에서 마지막 배지를 받아요."
            : "마신 양 탐구, 가족 선택과 이유, 광고 세 장, 소비 다짐을 모두 살펴봐요."}
        </p>
      </section>
      <Certificate />
    </MissionTrail>
  );
}
export function Certificate() {
  const { state, id, name, note } = useLearning();
  const progress = state.progress[id];
  const [presenting, setPresenting] = useState(false);
  const close = useCallback(() => setPresenting(false), []);
  if (progress?.completedChapters.length !== 8)
    return (
      <div className={s.notice}>
        여덟 사건을 모두 해결하면 수석 탐정 수료증이 열려요. 현재{" "}
        {progress?.completedChapters.length ?? 0} / 8장 해결.
      </div>
    );
  const score = scoreFor(state, id);
  const card = (
    <CertificateArt
      name={name}
      score={score}
      rank={rankFor(score).name}
      pledge={note.pledge}
    />
  );
  return (
    <section className={s.stack}>
      {card}
      <button className="btn secondary" onClick={() => setPresenting(true)}>
        수료증 크게 보기
      </button>
      {presenting && (
        <Presentation title="수석 탐정 수료증" onClose={close}>
          {card}
        </Presentation>
      )}
    </section>
  );
}

import { MissionTrail } from "../components/game/MissionTrail";
import { useCallback, useState } from "react";
import { useLearning } from "../app/useLearning";
import { productCases } from "../data/cases";
import { makeReport, validPair } from "../lib/learning";
import { compare, divide, fraction, toLitres } from "../lib/math";
import { Fraction } from "../components/math/Fraction";
import {
  PeerReviewForm,
  ReviewSummary,
} from "../components/game/CollectionForms";
import { Presentation } from "../components/game/Presentation";
import type { Report } from "../types";
import s from "../components/game/Lesson.module.css";
import { CharacterJury } from "../components/game/CharacterJury";

export function ReportView({ report }: { report: Report }) {
  const small = (["A", "B"] as const).find(
    (key) =>
      compare(
        toLitres(report.pair[key].amount, report.pair[key].unit),
        fraction(1),
      ) < 0,
  );
  return (
    <article className={s.report}>
      <span className={s.stamp}>사건 브리핑</span>
      <h2>우리의 알뜰 선택 보고서</h2>
      <dl>
        {[
          ["사건", report.event],
          ["증거 A", report.evidenceA],
          ["증거 B", report.evidenceB],
          ["원리", report.principle],
          ["결론", report.conclusion],
        ].map(([label, text]) => (
          <div key={label} style={{ display: "contents" }}>
            <dt>{label}</dt>
            <dd>{text}</dd>
          </div>
        ))}
      </dl>
      {small && (
        <div className={s.math}>
          1 ÷{" "}
          <Fraction
            value={toLitres(report.pair[small].amount, report.pair[small].unit)}
          />{" "}
          ={" "}
          <Fraction
            value={divide(
              fraction(1),
              toLitres(report.pair[small].amount, report.pair[small].unit),
            )}
          />{" "}
          (개)
        </div>
      )}
    </article>
  );
}
export function Chapter7() {
  const { note, patch, reward, state } = useLearning();
  const [source, setSource] = useState(
    note.report?.source ?? `case:${note.selectedCase}`,
  );
  const [message, setMessage] = useState("");
  const [presenting, setPresenting] = useState(false);
  const close = useCallback(() => setPresenting(false), []);
  const sourcePair =
    source === "tool"
      ? note.toolPair
      : (productCases.find((item) => `case:${item.id}` === source) ??
        productCases[0]);
  const error = validPair(sourcePair);
  const report =
    note.report ?? (!error ? makeReport(sourcePair, source) : undefined);
  const fields = [
    ["event", "사건"],
    ["evidenceA", "증거 A"],
    ["evidenceB", "증거 B"],
    ["principle", "원리"],
    ["conclusion", "결론"],
  ] as const;
  return (
    <MissionTrail chapter={7}>
      <section className={s.card}>
        <h2>미션 1 · 사건 보고서 만들기</h2>
        <label>
          보고서에 사용할 상품
          <select
            aria-label="보고서에 사용할 상품"
            value={source}
            onChange={(event) => setSource(event.target.value)}
          >
            {productCases.map((pair) => (
              <option key={pair.id} value={`case:${pair.id}`}>
                3장 · {pair.label} 사건
              </option>
            ))}
            <option value="tool">5장 · 내가 입력한 탐정기 상품</option>
          </select>
        </label>
        <button
          className="btn secondary"
          style={{ marginTop: 16 }}
          disabled={!!error}
          onClick={() => {
            if (!error) {
              patch({
                report: makeReport(sourcePair, source),
                reportSaved: false,
              });
              setMessage("고른 상품의 증거와 결론을 새로 채웠어요.");
            }
          }}
        >
          이 상품으로 보고서 채우기
        </button>
        {error && <p role="alert">{error}</p>}
        {report && (
          <>
            <div className={s.stack} style={{ marginTop: 24 }}>
              {fields.map(([key, label]) => (
                <label key={key}>
                  {label} 문장
                  <textarea
                    aria-label={`${label} 문장`}
                    value={report[key]}
                    maxLength={2000}
                    onChange={(event) =>
                      patch({
                        report: { ...report, [key]: event.target.value },
                        reportSaved: false,
                      })
                    }
                  />
                </label>
              ))}
            </div>
            <p>
              자동으로 채운 문장을 우리 모둠의 말로 다듬어 봐요. 상품을 바꾸어도
              저장한 보고서는 스스로 새로 채우기 전까지 보존돼요.
            </p>
            <button
              className="btn primary"
              disabled={fields.some(([key]) => !report[key].trim())}
              onClick={() => {
                patch({ report, reportSaved: true });
                reward("c7-report", 10, 7);
                setMessage("증거와 결론을 담은 사건 보고서를 저장했어요.");
              }}
            >
              사건 보고서 저장하기
            </button>
            <button
              className="btn secondary"
              style={{ marginLeft: 12 }}
              onClick={() => setPresenting(true)}
            >
              발표 화면 크게 보기
            </button>
            <p role="status">
              {message || (note.reportSaved ? "보고서가 저장되어 있어요." : "")}
            </p>
            <ReportView report={report} />
            {presenting && (
              <Presentation title="사건 보고서 발표" onClose={close}>
                <ReportView report={report} />
              </Presentation>
            )}
          </>
        )}
      </section>
      <section className={s.card}>
        <h2>미션 2 · 탐정단의 세 질문</h2>
        {state.mode === "teacher" ? (
          <>
            <PeerReviewForm />
            <ReviewSummary />
          </>
        ) : (
          <>
            <p>
              보고서를 고른 상품의 계산을 바탕으로 올리·두리·모아의 질문에
              답해요. 혼자서도 끝까지 진행할 수 있어요.
            </p>
            <CharacterJury />
            {state.mode === "group" && (
              <details className={s.hint}>
                <summary>선택 활동 · 실제 친구에게도 의견 전하기</summary>
                <PeerReviewForm />
                <ReviewSummary />
              </details>
            )}
          </>
        )}
      </section>
    </MissionTrail>
  );
}

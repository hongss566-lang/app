import { MissionTrail } from "../components/game/MissionTrail";
import { useCallback, useState } from "react";
import { useLearning } from "../app/useLearning";
import { productCases } from "../data/cases";
import { makeReport, validPair } from "../lib/learning";
import { compare, divide, fraction, toLitres } from "../lib/math";
import { Fraction } from "../components/math/Fraction";
import {
  PeerReviewForm,
  ReviewSummary,
} from "../components/game/CollectionForms";
import { Presentation } from "../components/game/Presentation";
import type { Report } from "../types";
import s from "../components/game/Lesson.module.css";
import { Products } from "../components/game/Shared";
import { ProductArt } from "../components/game/ProductArt";
import { Icon } from "../components/ui/Icon";
import r from "../components/game/Report.module.css";
import { CharacterJury } from "../components/game/CharacterJury";

export function ReportView({ report }: { report: Report }) {
  const small = (["A", "B"] as const).find(
    (key) =>
      compare(
        toLitres(report.pair[key].amount, report.pair[key].unit),
        fraction(1),
      ) < 0,
  );
  return (
    <article className={s.report}>
      <span className={s.stamp}>사건 브리핑</span>
      <h2>우리의 알뜰 선택 보고서</h2>
      <dl>
        {[
          ["사건", report.event],
          ["증거 A", report.evidenceA],
          ["증거 B", report.evidenceB],
          ["원리", report.principle],
          ["결론", report.conclusion],
        ].map(([label, text]) => (
          <div key={label} style={{ display: "contents" }}>
            <dt>{label}</dt>
            <dd>{text}</dd>
          </div>
        ))}
      </dl>
      {small && (
        <div className={s.math}>
          1 ÷{" "}
          <Fraction
            value={toLitres(report.pair[small].amount, report.pair[small].unit)}
          />{" "}
          ={" "}
          <Fraction
            value={divide(
              fraction(1),
              toLitres(report.pair[small].amount, report.pair[small].unit),
            )}
          />{" "}
          (병만큼)
        </div>
      )}
    </article>
  );
}
export function Chapter7() {
  const { note, patch, reward, state } = useLearning();
  const source = note.report?.source ?? `case:${note.selectedCase}`;
  const [message, setMessage] = useState("");
  const [presenting, setPresenting] = useState(false);
  const close = useCallback(() => setPresenting(false), []);
  const sourcePair =
    source === "tool"
      ? note.toolPair
      : (productCases.find((item) => `case:${item.id}` === source) ??
        productCases[0]);
  const error = validPair(note.report?.pair ?? sourcePair);
  const report =
    note.report ?? (!error ? makeReport(sourcePair, source) : undefined);
  const changeSource = (next: string) => {
    if (!report || next === source) return;
    const pair =
      next === "tool"
        ? note.toolPair
        : productCases.find((item) => `case:${item.id}` === next)!;
    if (validPair(pair)) return;
    const draft = note.reportDrafts?.[next];
    patch({
      reportDrafts: {
        ...note.reportDrafts,
        [source]: {
          report,
          saved: note.reportSaved,
          answers: note.briefingAnswers ?? {},
        },
      },
      report: draft?.report ?? makeReport(pair, next),
      reportSaved: draft?.saved ?? false,
      briefingAnswers: draft?.answers ?? {},
    });
    setMessage("사건의 계산 증거를 펼쳤어요. 내 설명을 다듬어 봐요.");
  };
  const fields = [
    ["event", "사건"],
    ["evidenceA", "증거 A"],
    ["evidenceB", "증거 B"],
    ["principle", "원리"],
    ["conclusion", "결론"],
  ] as const;
  return (
    <MissionTrail chapter={7}>
      <section className={`${s.card} ${r.file}`}>
        <div className={r.fileHeading}>
          <Icon name="envelope" size={32} />
          <div>
            <span className="eyebrow">반짝마을 탐정 사무소 · 증거 보관함</span>
            <h2>미션 1 · 사건 보고서 만들기</h2>
          </div>
        </div>
        <h3>친구들에게 어떤 사건을 소개할까요?</h3>
        <div
          className={r.caseCards}
          role="group"
          aria-label="소개할 사건 고르기"
        >
          {[
            ...productCases.map((pair) => ({
              source: `case:${pair.id}`,
              label: `${pair.label} 사건`,
              pair,
            })),
            { source: "tool", label: "내 탐정기 사건", pair: note.toolPair },
          ].map((item) => (
            <button
              key={item.source}
              aria-pressed={source === item.source}
              disabled={!!validPair(item.pair)}
              onClick={() => changeSource(item.source)}
            >
              <span className={r.caseArt} aria-hidden="true">
                <ProductArt product={item.pair.A} />
              </span>
              <strong>{item.label}</strong>
              <small>두 상품의 계산 증거</small>
            </button>
          ))}
        </div>
        {error && <p role="alert">{error}</p>}
        {report && (
          <>
            <Products pair={report.pair} />
            <p className={s.notice}>
              계산 증거를 가져왔어요. 내 말로 설명을 다듬고 보고서를 봉인해요.
              사건을 바꿔도 고친 문장은 보관돼요.
            </p>
            <div className={r.evidenceBoard}>
              {fields.map(([key, label], index) => (
                <article
                  key={key}
                  className={`${r.evidence} ${key === "conclusion" ? r.conclusion : ""}`}
                >
                  <span className={r.pin} aria-hidden="true" />
                  <span className={r.evidenceNumber}>단서 {index + 1}</span>
                  <label>
                    {label} 문장
                    <textarea
                      aria-label={`${label} 문장`}
                      value={report[key]}
                      rows={key === "event" ? 2 : 3}
                      maxLength={2000}
                      onChange={(event) =>
                        patch({
                          report: { ...report, [key]: event.target.value },
                          reportSaved: false,
                        })
                      }
                    />
                  </label>
                </article>
              ))}
            </div>
            <div className={r.actions}>
              <button
                className="btn primary"
                disabled={fields.some(([key]) => !report[key].trim())}
                onClick={() => {
                  patch({
                    report,
                    reportSaved: true,
                    reportDrafts: {
                      ...note.reportDrafts,
                      [source]: {
                        report,
                        saved: true,
                        answers: note.briefingAnswers ?? {},
                      },
                    },
                  });
                  reward("c7-report", 10, 7);
                  setMessage(
                    "보고서를 봉인했어요. 탐정단의 세 질문에 도전해 봐요!",
                  );
                }}
              >
                보고서 봉인하기
              </button>
              <button
                className="btn secondary"
                onClick={() => setPresenting(true)}
              >
                발표 화면 크게 보기
              </button>
            </div>
            <p role="status">
              {message || (note.reportSaved ? "보고서가 봉인되어 있어요." : "")}
            </p>
            <details>
              <summary>완성된 보고서 펼쳐보기</summary>
              <ReportView report={report} />
            </details>
            {presenting && (
              <Presentation title="사건 보고서 발표" onClose={close}>
                <ReportView report={report} />
              </Presentation>
            )}
          </>
        )}
      </section>
      <section className={s.card}>
        <h2>미션 2 · 탐정단의 세 질문</h2>
        {state.mode === "teacher" ? (
          <>
            <PeerReviewForm />
            <ReviewSummary />
          </>
        ) : (
          <>
            <p>
              올리·두리·모아가 내 사건에 대해 물어봐요. 상품과 계산 증거를 보며
              세 확인 문제를 풀어 봐요.
            </p>
            <CharacterJury />
          </>
        )}
      </section>
    </MissionTrail>
  );
}

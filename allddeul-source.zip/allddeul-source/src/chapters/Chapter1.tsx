import { MissionTrail } from "../components/game/MissionTrail";
import { useState } from "react";
import { useLearning } from "../app/useLearning";
import { contextCards, productCases } from "../data/cases";
import {
  PredictionForm,
  PredictionSummary,
} from "../components/game/CollectionForms";
import { Products } from "../components/game/Shared";
import s from "../components/game/Lesson.module.css";

export function Chapter1() {
  const { note, patch, reward, state } = useLearning();
  const [saved, setSaved] = useState(false);
  return (
    <MissionTrail chapter={1}>
      <section className={s.card}>
        <h2>미션 1 · 수상한 두 가격표</h2>
        <p>
          지금은 계산보다 첫 생각을 담는 시간이에요. 정답은 3장에서 밝혀져요.
        </p>
        <Products pair={productCases[0]} litresOnly />
        <PredictionForm />
      </section>
      <section className={s.card}>
        <h2>미션 2 · 같은 양으로 비교할 때</h2>
        <p>
          같은 양으로 맞춰 비교하면 도움이 되는 상황을 고르고, 우리 생활 속 예도
          하나 적어 봐요.
        </p>
        <div className={s.checkList}>
          {contextCards.map((card) => (
            <label key={card} className={s.checkLabel}>
              <input
                type="checkbox"
                checked={note.contexts.includes(card)}
                onChange={(event) => {
                  patch({
                    contexts: event.target.checked
                      ? [...note.contexts, card]
                      : note.contexts.filter((x) => x !== card),
                  });
                  setSaved(false);
                }}
              />
              {card}
            </label>
          ))}
        </div>
        <label>
          내가 찾은 생활 속 비교
          <textarea
            maxLength={500}
            value={note.ownContext}
            onChange={(event) => {
              patch({ ownContext: event.target.value });
              setSaved(false);
            }}
            placeholder="예: 크기가 다른 물감 두 통의 가격"
          />
        </label>
        <button
          className="btn primary"
          style={{ marginTop: 16 }}
          disabled={!note.contexts.length || !note.ownContext.trim()}
          onClick={() => {
            reward("c1-context", 10, 1);
            setSaved(true);
          }}
        >
          생활 속 단서 기록하기
        </button>
        {saved && (
          <p role="status" className={s.success}>
            같은 양으로 비교할 이유를 찾았어요!
          </p>
        )}
      </section>
      {state.mode === "teacher" && (
        <section className={s.card}>
          <PredictionSummary />
        </section>
      )}
    </MissionTrail>
  );
}

import { MissionTrail } from "../components/game/MissionTrail";
import { useState } from "react";
import { useLearning } from "../app/useLearning";
import {
  bugCases,
  bugCauses,
  productCases,
  studentPrompts,
} from "../data/cases";
import {
  clonePair,
  pairPrices,
  parseFractionAnswer,
  validPair,
} from "../lib/learning";
import { compare, formatWon, fraction, roundPrice } from "../lib/math";
import { PourDiagram } from "../components/math/PourDiagram";
import { Hint, PromptCard } from "../components/game/Shared";
import s from "../components/game/Lesson.module.css";

export function Chapter6() {
  const { note, patch, reward, state } = useLearning();
  const [bugIndex, setBugIndex] = useState(() =>
    Math.max(
      0,
      bugCases.findIndex((item) => !note.bugs[item.id]?.solved),
    ),
  );
  const [messages, setMessages] = useState<Record<string, string>>({});
  const [handMessage, setHandMessage] = useState("");
  const error = validPair(note.toolPair);
  const handCheck = () => {
    if (error) return;
    const prices = pairPrices(note.toolPair);
    const correct = (["A", "B"] as const).every((key, i) => {
      const value = parseFractionAnswer(note.hand[i].replace(/,/g, ""));
      return value && compare(value, fraction(roundPrice(prices[key]))) === 0;
    });
    patch({ handVerified: correct });
    if (correct) {
      reward("c6-hand", 10, 6);
      setHandMessage("맞았어요! 손계산과 탐정기의 결과가 같아요.");
    } else
      setHandMessage(
        `다시 확인: 탐정기는 A ${formatWon(prices.A)}, B ${formatWon(prices.B)}이에요. 단위와 나누는 순서를 살펴봐요.`,
      );
  };
  return (
    <MissionTrail chapter={6}>
      <section className={s.card}>
        <h2>미션 1 · 1L 안에는 몇 개가 들어갈까?</h2>
        {error ? (
          <>
            <p>{error}</p>
            <button
              className="btn secondary"
              onClick={() =>
                patch({
                  toolPair: clonePair(productCases[0]),
                  toolCalculated: true,
                  handVerified: false,
                })
              }
            >
              기본 음료 예시로 살펴보기
            </button>
          </>
        ) : (
          <div className={s.grid}>
            <PourDiagram product={note.toolPair.A} label="A" />
            <PourDiagram product={note.toolPair.B} label="B" />
          </div>
        )}
      </section>
      <section className={s.card}>
        <h2>미션 2 · AI 버그 사냥</h2>
        <p>
          조건: A {productCases[0].A.name} {productCases[0].A.amount}
          {productCases[0].A.unit}{" "}
          {Number(productCases[0].A.price).toLocaleString("ko-KR")}원 / B{" "}
          {productCases[0].B.name} {productCases[0].B.amount}
          {productCases[0].B.unit}{" "}
          {Number(productCases[0].B.price).toLocaleString("ko-KR")}원.
          반올림하여 일의 자리까지 나타내기로 했어요.
        </p>
        <p>답을 판단하고, 버그라면 원인까지 골라 봐요.</p>
        {state.mode !== "teacher" && (
          <>
            <p>
              터널 점검:{" "}
              {bugCases.filter((item) => note.bugs[item.id]?.solved).length} / 6
              기록 해결
            </p>
            <nav className={s.progress} aria-label="버그 터널 기록 선택">
              {bugCases.map((item, index) => (
                <button
                  key={item.id}
                  aria-current={index === bugIndex ? "step" : undefined}
                  onClick={() => setBugIndex(index)}
                >
                  기록 {index + 1}
                  {note.bugs[item.id]?.solved ? " · 해결" : ""}
                </button>
              ))}
            </nav>
          </>
        )}
        <div className={s.stack}>
          {bugCases.map((item, index) => {
            const answer = note.bugs[item.id] ?? {
              verdict: "",
              cause: "",
              solved: false,
            };
            const update = (part: Partial<typeof answer>) =>
              patch({
                bugs: { ...note.bugs, [item.id]: { ...answer, ...part } },
              });
            return (
              <article
                key={item.id}
                className={s.card}
                hidden={state.mode !== "teacher" && index !== bugIndex}
              >
                <h3>AI의 답: {item.output}</h3>
                <div
                  className={s.choices}
                  role="group"
                  aria-label={`${item.output} 판단`}
                >
                  {[
                    ["right", "맞아요"],
                    ["bug", "버그예요"],
                  ].map(([value, text]) => (
                    <button
                      key={value}
                      disabled={answer.solved}
                      aria-pressed={answer.verdict === value}
                      onClick={() => update({ verdict: value })}
                    >
                      {text}
                    </button>
                  ))}
                </div>
                {answer.verdict === "bug" && (
                  <label>
                    버그의 원인
                    <select
                      value={answer.cause}
                      disabled={answer.solved}
                      onChange={(event) =>
                        update({ cause: event.target.value })
                      }
                    >
                      <option value="">원인을 골라 주세요</option>
                      {bugCauses.map((cause) => (
                        <option key={cause.id} value={cause.id}>
                          {cause.text}
                        </option>
                      ))}
                    </select>
                  </label>
                )}
                {!answer.solved && (
                  <button
                    className="btn primary"
                    style={{ marginTop: 16 }}
                    disabled={
                      !answer.verdict ||
                      (answer.verdict === "bug" && !answer.cause)
                    }
                    onClick={() => {
                      const correct = item.correct
                        ? answer.verdict === "right"
                        : answer.verdict === "bug" &&
                          answer.cause === item.cause;
                      if (correct) {
                        update({ solved: true });
                        reward(`c6-bug-${item.id}`, 10, 6);
                      }
                      setMessages((previous) => ({
                        ...previous,
                        [item.id]: correct
                          ? item.explanation
                          : "다시 생각해 봐요. 단위·나누는 순서·반올림할 자리를 확인해요.",
                      }));
                    }}
                  >
                    판정과 원인 확인하기
                  </button>
                )}
                {(answer.solved || messages[item.id]) && (
                  <p
                    role="status"
                    className={answer.solved ? s.success : s.feedback}
                  >
                    {answer.solved ? item.explanation : messages[item.id]}
                  </p>
                )}
                {state.mode !== "teacher" &&
                  answer.solved &&
                  index < bugCases.length - 1 && (
                    <button
                      className="btn primary"
                      onClick={() => setBugIndex(index + 1)}
                    >
                      다음 터널 기록
                    </button>
                  )}
                <Hint
                  task={`c6-bug-${item.id}`}
                  hints={[
                    "먼저 500mL를 L로 바꾼 뒤, 가격을 양으로 나누었는지 살펴봐요.",
                    "A는 2,480 ÷ 1.5, B는 1,200 ÷ 0.5예요. 이번에는 일의 자리까지 반올림해요.",
                    <>
                      {item.correct ? "맞는 답이에요." : "버그예요."}{" "}
                      {item.explanation}
                    </>,
                  ]}
                />
              </article>
            );
          })}
        </div>
      </section>
      <section className={s.card}>
        <h2>미션 3 · 내 손계산과 대조하기</h2>
        <p>
          위 덜어내기 그림의 상품을 공책에서 계산한 뒤 반올림하여 일의 자리까지
          적어요.
        </p>
        <div className={s.grid}>
          {(["A", "B"] as const).map((key, i) => (
            <label key={key}>
              상품 {key} 손계산 (원)
              <input
                inputMode="decimal"
                maxLength={64}
                value={note.hand[i]}
                onChange={(event) =>
                  patch({
                    hand: note.hand.map((value, index) =>
                      index === i ? event.target.value : value,
                    ) as [string, string],
                    handVerified: false,
                  })
                }
              />
            </label>
          ))}
        </div>
        <button
          className="btn primary"
          style={{ marginTop: 18 }}
          disabled={!!error || note.hand.some((value) => !value.trim())}
          onClick={handCheck}
        >
          손계산 대조하기
        </button>
        <p role="status" className={note.handVerified ? s.success : ""}>
          {handMessage ||
            (note.handVerified ? "손계산과 탐정기 값이 같아요." : "")}
        </p>
      </section>
      <PromptCard text={studentPrompts.debug} />
    </MissionTrail>
  );
}

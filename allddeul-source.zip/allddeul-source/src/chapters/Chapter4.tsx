import { MissionTrail } from "../components/game/MissionTrail";
import { useState } from "react";
import { useLearning } from "../app/useLearning";
import { featureChoices, flowOrder, productCases } from "../data/cases";
import {
  correctFlow,
  pairPrices,
  pairWinner,
  ruleFeedback,
} from "../lib/learning";
import { formatWon } from "../lib/math";
import { Hint } from "../components/game/Shared";
import { PourDiagram } from "../components/math/PourDiagram";
import s from "../components/game/Lesson.module.css";

export function Chapter4() {
  const { note, patch, reward } = useLearning();
  const o = note.outline;
  const [message, setMessage] = useState("");
  const [ruleMessage, setRuleMessage] = useState("");
  const [storyMessage, setStoryMessage] = useState("");
  const update = (part: Partial<typeof o>) =>
    patch({ outline: { ...o, ...part } });
  const move = (from: number, to: number) => {
    if (from < 0 || from > 3 || to < 0 || to > 3) return;
    const order = [...o.order];
    const [item] = order.splice(from, 1);
    order.splice(to, 0, item);
    update({ order, flowVerified: false, flowStep: -1 });
  };
  const pair =
    productCases.find((item) => item.id === note.selectedCase) ??
    productCases[0];
  const prices = pairPrices(pair);
  const descriptions = [
    `A ${pair.A.name} ${Number(pair.A.price).toLocaleString("ko-KR")}원 ${pair.A.amount}${pair.A.unit}, B ${pair.B.name} ${Number(pair.B.price).toLocaleString("ko-KR")}원 ${pair.B.amount}${pair.B.unit}`,
    `단위를 L로 맞추고 가격 ÷ 양. A ${formatWon(prices.A)}, B ${formatWon(prices.B)}`,
    `어림하기 전 몫을 비교하면 ${pairWinner(pair) === "same" ? "두 상품이 같아요" : pairWinner(pair) + "가 알뜰 선택이에요"}`,
    "1L 기준선을 놓고 상품 한 개의 양만큼 칸을 채워요",
  ];
  return (
    <MissionTrail chapter={4}>
      <section className={s.card}>
        <h2>퍼즐 1 · 탐정기의 흐름을 설계해요</h2>
        <p>카드를 끌어 순서를 바꾸거나 위·아래 버튼을 눌러요.</p>
        <div className={s.flowList}>
          {o.order.map((item, i) => (
            <div
              className={s.flowItem}
              key={item}
              draggable
              onDragStart={(event) =>
                event.dataTransfer.setData("text/plain", String(i))
              }
              onDragOver={(event) => event.preventDefault()}
              onDrop={(event) => {
                event.preventDefault();
                const from = Number(event.dataTransfer.getData("text/plain"));
                if (Number.isInteger(from)) move(from, i);
              }}
            >
              <span>{i + 1}</span>
              <strong>{item}</strong>
              <button
                disabled={i === 0}
                aria-label={`${item} 위로`}
                onClick={() => move(i, i - 1)}
              >
                ↑
              </button>
              <button
                disabled={i === 3}
                aria-label={`${item} 아래로`}
                onClick={() => move(i, i + 1)}
              >
                ↓
              </button>
            </div>
          ))}
        </div>
        <button
          className="btn primary"
          onClick={() => {
            const correct = correctFlow(o.order);
            update({ flowVerified: correct, flowStep: correct ? 0 : -1 });
            if (correct) reward("c4-flow", 10, 4);
            setMessage(
              correct
                ? "올바른 흐름이에요! 실제 상품 값으로 따라가 봐요."
                : "다시 생각해 봐요. 무엇을 먼저 알아야 계산할 수 있을까요?",
            );
          }}
        >
          흐름 확인하기
        </button>
        <p role="status">{message}</p>
        {o.flowVerified && (
          <>
            <div className={s.flowList}>
              {flowOrder.map((item, i) => (
                <div
                  className={`${s.flowItem} ${o.flowStep === i ? s.flowActive : ""}`}
                  key={item}
                >
                  <strong>{item}</strong>
                  {i <= o.flowStep && <span>{descriptions[i]}</span>}
                </div>
              ))}
            </div>
            <button
              className="btn secondary"
              onClick={() => update({ flowStep: (o.flowStep + 1) % 4 })}
            >
              다음 흐름 따라가기
            </button>
            {o.flowStep === 3 && (
              <div className={s.grid}>
                <PourDiagram product={pair.A} label="A" />
                <PourDiagram product={pair.B} label="B" />
              </div>
            )}
          </>
        )}
        <Hint
          task="c4-flow"
          hints={[
            "계산하려면 먼저 상품 정보가 있어야 해요.",
            "입력 → 계산 → 그다음에는 어떤 상품을 고를지 정해요.",
            "입력 → 계산 → 판단 → 시각화 순서예요.",
          ]}
        />
      </section>
      <section className={s.card}>
        <h2>퍼즐 2 · 판단 규칙 블록</h2>
        <p>
          더 작은 1L당 가격을 찾는 규칙을 만들어요. &lt;는 ‘더 작다’, &gt;는 ‘더
          크다’를 뜻해요.
        </p>
        <div className={s.rule}>
          만약
          <select
            aria-label="규칙 왼쪽 상품"
            value={o.rule.left}
            onChange={(event) =>
              update({
                rule: { ...o.rule, left: event.target.value as "A" | "B" },
                ruleVerified: false,
              })
            }
          >
            {["A", "B"].map((key) => (
              <option key={key} value={key}>
                {key}의 1L당 가격
              </option>
            ))}
          </select>
          <select
            aria-label="규칙 비교 기호"
            value={o.rule.operator}
            onChange={(event) =>
              update({
                rule: {
                  ...o.rule,
                  operator: event.target.value as "<" | ">" | "=",
                },
                ruleVerified: false,
              })
            }
          >
            <option value="&lt;">&lt;</option>
            <option value="&gt;">&gt;</option>
            <option value="=">=</option>
          </select>
          <select
            aria-label="규칙 오른쪽 상품"
            value={o.rule.right}
            onChange={(event) =>
              update({
                rule: { ...o.rule, right: event.target.value as "A" | "B" },
                ruleVerified: false,
              })
            }
          >
            {["A", "B"].map((key) => (
              <option key={key} value={key}>
                {key}의 1L당 가격
              </option>
            ))}
          </select>
          이면
          <select
            aria-label="알뜰 선택 표시 대상"
            value={o.rule.target}
            onChange={(event) =>
              update({
                rule: { ...o.rule, target: event.target.value as "A" | "B" },
                ruleVerified: false,
              })
            }
          >
            {["A", "B"].map((key) => (
              <option key={key}>{key}</option>
            ))}
          </select>
          에 ‘알뜰 선택’을 표시해요.
        </div>
        <button
          className="btn primary"
          onClick={() => {
            const result = ruleFeedback(o.rule);
            update({ ruleVerified: result.correct });
            setRuleMessage(result.message);
            if (result.correct) reward("c4-rule", 10, 4);
          }}
        >
          판단 규칙 확인하기
        </button>
        <p role="status">{ruleMessage}</p>
        <Hint
          task="c4-rule"
          hints={[
            "알뜰 선택은 1L당 가격이 더 낮은 상품이에요.",
            "A가 B보다 작으면 A에 표시해요. A가 더 크면 어느 쪽일까요?",
            "A < B → A, A > B → B, B < A → B, B > A → A가 모두 올바른 규칙이에요.",
          ]}
        />
      </section>
      <section className={s.card}>
        <h2>미션 3 · 나의 탐정기 스토리보드</h2>
        <p>넣고 싶은 기능을 두 가지 이상 고르고, 프롬프트를 완성해요.</p>
        <div className={s.checkList}>
          {featureChoices.map((feature) => (
            <label className={s.checkLabel} key={feature}>
              <input
                type="checkbox"
                checked={o.features.includes(feature)}
                onChange={(event) =>
                  update({
                    features: event.target.checked
                      ? [...o.features, feature]
                      : o.features.filter((x) => x !== feature),
                    storyVerified: false,
                  })
                }
              />
              {feature}
            </label>
          ))}
        </div>
        <div className={s.stack}>
          {[
            {
              label: "mL를 L로 바꾸려면",
              options: [
                ["divide1000", "1000으로 나누어 줘"],
                ["times1000", "1000을 곱해 줘"],
              ],
            },
            {
              label: "1L당 가격은",
              options: [
                ["price/amount", "가격 ÷ 양(L)으로 구해 줘"],
                ["amount/price", "양(L) ÷ 가격으로 구해 줘"],
              ],
            },
            {
              label: "알뜰 선택은",
              options: [
                ["lower", "어림하기 전 단위가격이 더 낮은 상품에 표시해 줘"],
                ["higher", "단위가격이 더 높은 상품에 표시해 줘"],
              ],
            },
          ].map((item, i) => (
            <label key={item.label}>
              {item.label}
              <select
                aria-label={item.label}
                value={o.blanks[i]}
                onChange={(event) =>
                  update({
                    blanks: o.blanks.map((v, index) =>
                      index === i ? event.target.value : v,
                    ),
                    storyVerified: false,
                  })
                }
              >
                <option value="">문장을 골라 주세요</option>
                {item.options.map(([value, label]) => (
                  <option key={value} value={value}>
                    {label}
                  </option>
                ))}
              </select>
            </label>
          ))}
        </div>
        <button
          className="btn primary"
          style={{ marginTop: 20 }}
          onClick={() => {
            const correct =
              o.features.length >= 2 &&
              o.blanks.join("|") === "divide1000|price/amount|lower";
            update({ storyVerified: correct });
            if (correct) reward("c4-story", 10, 4);
            setStoryMessage(
              correct
                ? "탐정기의 설계도가 완성됐어요!"
                : "기능 두 가지와 단위 변환·계산·판단 문장을 다시 살펴봐요.",
            );
          }}
        >
          설계도 완성하기
        </button>
        <p role="status">{storyMessage}</p>
        <Hint
          task="c4-story"
          hints={[
            "단위와 나누는 순서가 탐정기의 핵심이에요.",
            "mL ÷ 1000 = L, 가격 ÷ 양(L)이에요.",
            "기능을 두 가지 이상 고르고, 1000으로 나누기 / 가격 ÷ 양(L) / 어림하기 전 낮은 상품을 선택해요.",
          ]}
        />
      </section>
    </MissionTrail>
  );
}

import {
  createContext,
  useContext,
  useEffect,
  useReducer,
  useState,
  type Dispatch,
  type ReactNode,
} from "react";
import { loadState, saveState, type StorageStatus } from "../lib/storage";
import type { AppState } from "../types";
import { reducer, type Action } from "./reducer";

const Context = createContext<{
  state: AppState;
  dispatch: Dispatch<Action>;
  storageStatus: StorageStatus;
} | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [loaded] = useState(loadState);
  const [state, dispatch] = useReducer(reducer, loaded.state);
  const [storageStatus, setStorageStatus] = useState(loaded.status);

  useEffect(() => {
    const saved = saveState(state);
    setStorageStatus((previous) =>
      saved
        ? previous === "recovered"
          ? "recovered"
          : "available"
        : "unavailable",
    );
  }, [state]);

  useEffect(() => {
    document.documentElement.dataset.theme = state.settings.theme;
  }, [state.settings.theme]);

  return (
    <Context.Provider value={{ state, dispatch, storageStatus }}>
      {children}
    </Context.Provider>
  );
}

export function useApp() {
  const value = useContext(Context);
  if (!value) throw new Error("AppProvider가 필요합니다.");
  return value;
}

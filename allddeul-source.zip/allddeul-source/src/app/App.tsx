import { useCallback, useEffect, useRef, useState } from "react";
import { useApp } from "./AppProvider";
import { StartScreen } from "../screens/StartScreen";
import { CaseMapScreen } from "../screens/CaseMapScreen";
import { TeacherScreen } from "../screens/TeacherScreen";
import { ChapterScreen } from "../screens/ChapterScreen";
import { ChapterNav } from "../components/layout/ChapterNav";
import { ConfirmDialog } from "../components/ui/ConfirmDialog";
import { Icon } from "../components/ui/Icon";
import { RewardBurst } from "../components/game/RewardBurst";
import { clearState } from "../lib/storage";
import { rankFor, scoreFor } from "../lib/scoring";
import { canOpenChapter } from "../lib/progression";
import type { ChapterId, Theme } from "../types";
import styles from "./App.module.css";

type View = "start" | "map" | "teacher" | "chapter";

export function App() {
  const { state, dispatch, storageStatus } = useApp();
  const [view, setView] = useState<View>(
    state.mode === "teacher" ? "teacher" : state.mode ? "map" : "start",
  );
  const [confirmReset, setConfirmReset] = useState(false);
  const [editingGroups, setEditingGroups] = useState(false);
  const [announcement, setAnnouncement] = useState("");
  const [announcementVisible, setAnnouncementVisible] = useState(false);
  const [reward, setReward] = useState<{
    key: string;
    points: number;
    badge: boolean;
  }>();
  const headingRef = useRef<HTMLElement>(null);
  const actorId =
    state.mode === "solo"
      ? "solo"
      : state.mode === "teacher"
        ? state.teacher.selectedGroupId
        : state.activeGroupId;
  const actorName =
    actorId === "solo"
      ? state.nickname
      : (state.groups.find((group) => group.id === actorId)?.name ?? "탐정");
  const score = scoreFor(state, actorId);
  const rank = rankFor(score);
  const latestScore = state.scores.at(-1);
  const badgeCount = state.progress[actorId]?.badges.length ?? 0;
  const previousFeedback = useRef({
    actorId,
    threshold: rank.threshold,
    scoreId: latestScore?.id,
    badgeCount,
  });

  useEffect(() => {
    const previous = previousFeedback.current;
    if (previous.actorId !== actorId) setReward(undefined);
    if (
      previous.actorId === actorId &&
      latestScore &&
      previous.scoreId !== latestScore.id &&
      latestScore.participantId === actorId &&
      latestScore.delta > 0
    ) {
      const badge = badgeCount > previous.badgeCount;
      setAnnouncementVisible(previous.threshold < rank.threshold);
      setReward({ key: latestScore.id, points: latestScore.delta, badge });
      setAnnouncement(
        previous.threshold < rank.threshold
          ? `${actorName}, ${rank.name}으로 승급했어요!`
          : badge
            ? `${actorName}, 사건을 해결하고 새 배지를 받았어요!`
            : `${actorName}, 단서 ${latestScore.delta}점을 얻었어요!`,
      );
    }
    previousFeedback.current = {
      actorId,
      threshold: rank.threshold,
      scoreId: latestScore?.id,
      badgeCount,
    };
  }, [actorId, actorName, rank.threshold, rank.name, latestScore, badgeCount]);

  useEffect(() => {
    if (!reward) return;
    const timer = window.setTimeout(() => setReward(undefined), 3000);
    return () => window.clearTimeout(timer);
  }, [reward]);

  useEffect(() => {
    if (!announcement) return;
    const timer = window.setTimeout(() => setAnnouncement(""), 4200);
    return () => window.clearTimeout(timer);
  }, [announcement]);

  useEffect(() => {
    headingRef.current?.focus({ preventScroll: true });
    window.scrollTo({ top: 0, behavior: "instant" });
  }, [view, state.currentChapter]);

  useEffect(() => {
    if (view === "chapter" && !canOpenChapter(state, state.currentChapter))
      setView("map");
  }, [actorId, view, state.currentChapter, state.progress, state.mode]);

  const openChapter = (id: ChapterId) => {
    if (!canOpenChapter(state, id)) return;
    dispatch({ type: "chapter", id });
    setView("chapter");
  };
  const cancelReset = useCallback(() => setConfirmReset(false), []);
  const doReset = () => {
    clearState();
    dispatch({ type: "reset" });
    setEditingGroups(false);
    setConfirmReset(false);
    setView("start");
    setAnnouncement("기록을 지웠어요. 새로운 탐정을 맞이할 준비가 됐어요.");
    setAnnouncementVisible(true);
  };

  return (
    <div
      inert={confirmReset}
      data-view={view}
      className={`${styles.app} ${state.settings.projection && state.mode === "teacher" ? styles.projection : ""}`}
    >
      <a className="skip-link" href="#main">
        본문으로 바로 가기
      </a>
      <header className={styles.header}>
        <div className={`${styles.headerInner} container`}>
          <button
            className={styles.brand}
            onClick={() => setView(state.mode ? "map" : "start")}
            aria-label="알뜰 소비 탐정단 사건 지도"
          >
            <span className={styles.brandMark}>
              <Icon name="search" size={29} />
            </span>
            <span>
              <span className={styles.brandEyebrow}>반짝마트 사건 기록실</span>
              <strong>
                알뜰 소비 <span>탐정단</span>
              </strong>
            </span>
          </button>
          <div className={styles.headerActions}>
            {state.mode && (
              <span className={styles.modeLabel}>
                {state.mode === "teacher"
                  ? "교사 모드"
                  : state.mode === "group"
                    ? "모둠 모드"
                    : "혼자 하기"}
              </span>
            )}
            <label className={styles.themeControl}>
              <Icon name={state.settings.theme === "dark" ? "moon" : "sun"} />
              <span className="sr-only">화면 색</span>
              <select
                aria-label="화면 색"
                value={state.settings.theme}
                onChange={(event) =>
                  dispatch({
                    type: "settings",
                    patch: { theme: event.target.value as Theme },
                  })
                }
              >
                <option value="system">기기 설정</option>
                <option value="light">밝게</option>
                <option value="dark">어둡게</option>
              </select>
            </label>
            <button
              className={styles.iconButton}
              aria-label={`효과음 ${state.settings.sound ? "끄기" : "켜기"}`}
              aria-pressed={state.settings.sound}
              onClick={() =>
                dispatch({
                  type: "settings",
                  patch: { sound: !state.settings.sound },
                })
              }
              title={`효과음 ${state.settings.sound ? "켜짐" : "꺼짐"}`}
            >
              <Icon name={state.settings.sound ? "sound" : "muted"} />
            </button>
          </div>
        </div>
      </header>

      {state.mode && view !== "start" && (
        <div className={styles.workspaceBar}>
          <div className={`container ${styles.workspaceInner}`}>
            <div className={styles.workspaceLinks}>
              <button
                className={view === "map" ? styles.currentLink : ""}
                onClick={() => setView("map")}
              >
                <Icon name="grid" size={18} />
                사건 지도
              </button>
              {state.mode === "teacher" && (
                <button
                  className={view === "teacher" ? styles.currentLink : ""}
                  onClick={() => setView("teacher")}
                >
                  <Icon name="teacher" size={18} />
                  교사실
                </button>
              )}
              <button
                onClick={() => {
                  setEditingGroups(false);
                  setView("start");
                }}
              >
                모드 바꾸기
              </button>
            </div>
            <div className={styles.statusBar}>
              {state.mode !== "solo" ? (
                <select
                  aria-label={
                    state.mode === "teacher" ? "진행할 모둠" : "활동할 모둠"
                  }
                  value={
                    state.mode === "teacher"
                      ? state.teacher.selectedGroupId
                      : state.activeGroupId
                  }
                  onChange={(event) =>
                    dispatch({
                      type: state.mode === "teacher" ? "teacherGroup" : "group",
                      id: event.target.value,
                    })
                  }
                >
                  {state.groups.map((group) => (
                    <option value={group.id} key={group.id}>
                      {group.name}
                    </option>
                  ))}
                </select>
              ) : (
                <span>{actorName}</span>
              )}
              <span className={styles.score}>
                <Icon name="search" size={16} />
                <strong>{score.toLocaleString("ko-KR")}</strong> 단서
              </span>
              <span className={styles.rank}>
                <Icon name="badge" size={16} />
                {rank.name}
              </span>
            </div>
          </div>
        </div>
      )}

      <div className="container">
        {storageStatus !== "available" && (
          <div role="status" className="storage-notice">
            <Icon name="info" />
            <span>
              {storageStatus === "unavailable"
                ? "이 브라우저에서는 기록을 저장할 수 없어요. 지금은 활동할 수 있지만, 새로고침하면 기록이 사라질 수 있어요."
                : "저장된 기록을 읽을 수 없어 새 수첩을 펼쳤어요. 모둠과 교사 설정을 다시 확인해 주세요."}
            </span>
          </div>
        )}
        {state.mode && view !== "start" && (
          <ChapterNav
            active={view === "chapter" ? state.currentChapter : undefined}
            onOpen={openChapter}
          />
        )}
      </div>

      <main
        id="main"
        className={`container ${styles.main}`}
        tabIndex={-1}
        ref={headingRef}
      >
        {view === "start" && (
          <StartScreen
            key={editingGroups ? "edit-groups" : "start"}
            editingGroups={editingGroups}
            onStarted={(mode) => {
              setEditingGroups(false);
              setView(mode === "teacher" ? "teacher" : "map");
            }}
            onResume={
              state.mode
                ? () => {
                    setEditingGroups(false);
                    setView(state.mode === "teacher" ? "teacher" : "map");
                  }
                : undefined
            }
          />
        )}
        {view === "map" && <CaseMapScreen onOpen={openChapter} />}
        {view === "teacher" && state.mode === "teacher" && (
          <TeacherScreen
            onOpen={openChapter}
            onReset={() => setConfirmReset(true)}
            onConfigure={() => {
              setEditingGroups(true);
              setView("start");
            }}
          />
        )}
        {view === "chapter" && canOpenChapter(state, state.currentChapter) && (
          <ChapterScreen
            key={`${state.currentChapter}-${actorId}`}
            onMap={() => setView("map")}
            onOpen={openChapter}
          />
        )}
      </main>

      <footer className={`container ${styles.footer}`}>
        <span>
          알뜰 탐정 사무소 <span aria-hidden="true">/</span> 계산으로 찾고,
          이유로 선택해요.
        </span>
        <span>기록은 이 브라우저에만 남아요</span>
      </footer>
      <div
        role="status"
        aria-live="polite"
        className={
          announcement && announcementVisible ? styles.toast : "sr-only"
        }
      >
        {announcement && (
          <>
            <Icon name="badge" />
            {announcement}
          </>
        )}
      </div>
      {confirmReset && (
        <ConfirmDialog onCancel={cancelReset} onConfirm={doReset} />
      )}
      {reward && (
        <RewardBurst
          key={reward.key}
          points={reward.points}
          badge={reward.badge}
        />
      )}
    </div>
  );
}

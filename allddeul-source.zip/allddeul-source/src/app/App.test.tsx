import { render, screen, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it, vi } from "vitest";
import { AppProvider } from "./AppProvider";
import { App } from "./App";
import { initialState, saveState, STORAGE_KEY } from "../lib/storage";

const renderApp = () =>
  render(
    <AppProvider>
      <App />
    </AppProvider>,
  );
async function teacher(user: ReturnType<typeof userEvent.setup>) {
  await user.click(
    screen.getByRole("button", { name: "게임 안내" }),
  );
  await user.click(screen.getByText("선택: 교사용 수업 도구"));
  await user.click(screen.getByRole("button", { name: "교사실 열기" }));
}

describe("1단계 수업 준비 흐름", () => {
  it("모둠 수·이름을 설정하고 모둠을 바꾸며 새로고침 후에도 유지한다", async () => {
    const user = userEvent.setup();
    const app = renderApp();
    await user.click(screen.getByRole("button", { name: /모둠 모드/ }));
    await user.selectOptions(screen.getByLabelText("모둠 수"), "6");
    const groupName = screen.getByLabelText("1모둠 이름");
    await user.clear(groupName);
    await user.type(groupName, "돋보기 모둠");
    await user.click(screen.getByRole("button", { name: /탐정 수첩 펼치기/ }));
    expect(
      screen.getByRole("heading", { name: /돋보기 모둠/ }),
    ).toBeInTheDocument();
    await user.selectOptions(screen.getByLabelText("활동할 모둠"), "g6");
    expect(screen.getByRole("heading", { name: /6모둠/ })).toBeInTheDocument();
    app.unmount();
    renderApp();
    expect(screen.getByLabelText("활동할 모둠")).toHaveValue("g6");
    expect(
      screen.getByRole("option", { name: "돋보기 모둠" }),
    ).toBeInTheDocument();
  });
  it("혼자 하기는 별명으로 시작한다", async () => {
    const user = userEvent.setup();
    renderApp();
    await user.click(screen.getByRole("button", { name: /혼자 하기/ }));
    await user.type(screen.getByLabelText("탐정 별명"), "반짝 탐정");
    await user.click(screen.getByRole("button", { name: /탐정 수첩 펼치기/ }));
    expect(
      screen.getByRole("heading", { name: /반짝 탐정/ }),
    ).toBeInTheDocument();
    expect(screen.queryByLabelText("활동할 모둠")).not.toBeInTheDocument();
  });
  it("시작 버튼의 직접 검증과 입력 칸의 Enter 시작이 동작한다", async () => {
    const user = userEvent.setup();
    renderApp();
    await user.click(screen.getByRole("button", { name: /혼자 하기/ }));
    await user.click(screen.getByRole("button", { name: /탐정 수첩 펼치기/ }));
    expect(screen.getByRole("alert")).toHaveTextContent(
      "사용할 별명을 적어 주세요.",
    );
    await user.type(screen.getByLabelText("탐정 별명"), "용감한 탐정{Enter}");
    expect(
      screen.getByRole("heading", { name: /용감한 탐정/ }),
    ).toBeInTheDocument();
  });
  it("교사실에서 모둠 설정을 수정하고 교사실로 돌아온다", async () => {
    const user = userEvent.setup();
    renderApp();
    await teacher(user);
    await user.click(
      screen.getByRole("button", { name: "모둠 이름·수 바꾸기" }),
    );
    const input = screen.getByLabelText("1모둠 이름");
    await user.clear(input);
    await user.type(input, "용감한 탐정");
    await user.click(
      screen.getByRole("button", { name: "모둠 설정 저장하기" }),
    );
    expect(
      screen.getByRole("heading", { name: "오늘의 탐정 수업을 준비해요" }),
    ).toBeInTheDocument();
    expect(
      screen.getByRole("button", { name: "용감한 탐정 점수 1점 더하기" }),
    ).toBeInTheDocument();
  });
  it("교사 도구에서 장을 열어도 학생은 자기 수첩의 모험 순서로 진행한다", async () => {
    const user = userEvent.setup();
    renderApp();
    await teacher(user);
    await user.click(
      screen.getByRole("button", { name: "2장 나눴는데 왜 커졌지? 열기" }),
    );
    await user.click(screen.getByRole("button", { name: "모드 바꾸기" }));
    await user.click(screen.getByRole("button", { name: /함께하는 탐정/ }));
    await user.click(screen.getByRole("button", { name: /탐정 수첩 펼치기/ }));
    const nav = screen.getByRole("navigation", {
      name: "사건 파일 1장부터 8장",
    });
    expect(
      within(nav).getByRole("button", {
        name: "2장 나눴는데 왜 커졌지? · 잠김",
      }),
    ).toBeDisabled();
    expect(
      within(nav).getByRole("button", { name: "3장 1L로 맞춰라! · 잠김" }),
    ).toBeDisabled();
    await user.click(
      within(nav).getByRole("button", { name: "1장 수상한 가격표" }),
    );
    expect(
      screen.getByRole("heading", { name: /양이 다른 두 음료/ }),
    ).toBeInTheDocument();
    const stored = JSON.parse(localStorage.getItem(STORAGE_KEY)!);
    expect(stored.progress).toEqual({});
    expect(stored.scores).toEqual([]);
  });
  it("점수·모둠 입력 대상·교사 설정이 복원된다", async () => {
    const user = userEvent.setup();
    const app = renderApp();
    await teacher(user);
    await user.click(
      screen.getByRole("button", { name: "1모둠 점수 1점 더하기" }),
    );
    await user.click(
      screen.getByRole("button", { name: "1모둠 점수 1점 더하기" }),
    );
    await user.click(
      screen.getByRole("button", { name: "1모둠 점수 1점 빼기" }),
    );
    expect(screen.getByLabelText("1모둠 점수")).toHaveTextContent("1");
    await user.click(screen.getByRole("button", { name: /7장 동료 평가/ }));
    await user.click(
      within(screen.getByRole("group", { name: "입력받을 모둠" })).getByRole(
        "button",
        { name: /3모둠/ },
      ),
    );
    await user.click(screen.getByRole("switch", { name: /교사용 정답 보기/ }));
    app.unmount();
    renderApp();
    expect(screen.getByLabelText("1모둠 점수")).toHaveTextContent("1");
    expect(
      screen.getByRole("heading", { name: "3모둠 · 7장 동료 평가" }),
    ).toBeInTheDocument();
    expect(
      screen.getByRole("switch", { name: /교사용 정답 보기/ }),
    ).toBeChecked();
  });
  it("투사 모드에서 화살표는 장 안의 소개 단계만 넘긴다", async () => {
    const user = userEvent.setup();
    renderApp();
    await teacher(user);
    await user.click(screen.getByRole("switch", { name: /투사 모드/ }));
    await user.click(
      screen.getByRole("button", { name: "1장 수상한 가격표 미리보기" }),
    );
    await user.keyboard("{ArrowRight}");
    expect(
      screen.getByRole("heading", { name: "미션을 해결하고 단서를 모아 봐요" }),
    ).toBeInTheDocument();
    await user.keyboard("{ArrowLeft}");
    expect(
      screen.getByRole("heading", { name: /양이 다른 두 음료/ }),
    ).toBeInTheDocument();
    expect(JSON.parse(localStorage.getItem(STORAGE_KEY)!).currentChapter).toBe(
      1,
    );
  });
  it("초기화는 앱 안에서 취소하거나 확인하며 다른 앱의 데이터는 지우지 않는다", async () => {
    const user = userEvent.setup();
    renderApp();
    localStorage.setItem("other-app", "keep");
    await teacher(user);
    await user.click(
      screen.getByRole("button", { name: "2모둠 점수 1점 더하기" }),
    );
    await user.click(screen.getByRole("button", { name: "데이터 초기화" }));
    expect(screen.getByRole("alertdialog")).toBeInTheDocument();
    expect(
      screen.getByRole("button", { name: "기록 남겨 두기" }),
    ).toHaveFocus();
    await user.keyboard("{Escape}");
    expect(screen.queryByRole("alertdialog")).not.toBeInTheDocument();
    expect(screen.getByLabelText("2모둠 점수")).toHaveTextContent("1");
    await user.click(screen.getByRole("button", { name: "데이터 초기화" }));
    await user.click(screen.getByRole("button", { name: "모든 기록 지우기" }));
    expect(
      screen.getByRole("heading", { name: "어떻게 수사를 시작할까요?" }),
    ).toBeInTheDocument();
    expect(JSON.parse(localStorage.getItem(STORAGE_KEY)!)).toEqual(
      initialState(),
    );
    expect(localStorage.getItem("other-app")).toBe("keep");
  });
  it("저장이 차단되어도 활동하고 경고를 안내한다", async () => {
    vi.spyOn(Storage.prototype, "getItem").mockImplementation(() => {
      throw new DOMException("Blocked", "SecurityError");
    });
    vi.spyOn(Storage.prototype, "setItem").mockImplementation(() => {
      throw new DOMException("Blocked", "SecurityError");
    });
    const user = userEvent.setup();
    renderApp();
    expect(
      screen.getByText(/이 브라우저에서는 기록을 저장할 수 없어요/),
    ).toBeInTheDocument();
    await teacher(user);
    await user.click(
      screen.getByRole("button", { name: "1모둠 점수 1점 더하기" }),
    );
    expect(screen.getByLabelText("1모둠 점수")).toHaveTextContent("1");
  });
  it("교사 도구에서 모두 잠가도 학생의 첫 사건은 바로 시작할 수 있다", async () => {
    const state = initialState();
    state.mode = "group";
    state.openChapters = [];
    saveState(state);
    renderApp();
    const nav = screen.getByRole("navigation", {
      name: "사건 파일 1장부터 8장",
    });
    expect(within(nav).getAllByRole("button")).toHaveLength(8);
    within(nav)
      .getAllByRole("button")
      .slice(1)
      .forEach((button) => expect(button).toBeDisabled());
    expect(
      within(nav).getByRole("button", { name: "1장 수상한 가격표" }),
    ).toBeEnabled();
  });
});

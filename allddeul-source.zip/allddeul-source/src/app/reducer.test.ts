import { describe, expect, it, vi } from "vitest";
import { initialState } from "../lib/storage";
import { reducer } from "./reducer";
import { rankFor, scoreFor, newScoreEventId } from "../lib/scoring";

describe("교사 권한과 기록의 일관성", () => {
  it("일반 HTTP에서 UUID API가 없어도 서로 다른 점수 기록을 만든다", () => {
    vi.stubGlobal("crypto", {});
    try {
      const first = newScoreEventId();
      const second = newScoreEventId();
      expect(first).not.toBe(second);
      expect(first).toMatch(/^teacher-/);
    } finally {
      vi.unstubAllGlobals();
    }
  });
  it("학생 모드에서는 잠금·점수를 변경할 수 없다", () => {
    const state = { ...initialState(), mode: "group" as const };
    expect(reducer(state, { type: "toggleChapter", id: 2 })).toEqual(state);
    expect(reducer(state, { type: "allChapters", open: true })).toEqual(state);
    expect(
      reducer(state, { type: "score", id: "a", participantId: "g1", delta: 1 }),
    ).toEqual(state);
    expect(reducer(state, { type: "chapter", id: 2 })).toEqual(state);
  });
  it("같은 점수 기록을 두 번 적용하지 않는다", () => {
    const state = { ...initialState(), mode: "teacher" as const };
    const action = {
      type: "score" as const,
      id: "same-event",
      participantId: "g1",
      delta: 1 as const,
    };
    const once = reducer(state, action);
    expect(scoreFor(reducer(once, action), "g1")).toBe(1);
  });
  it("점수는 음수가 되지 않고 다른 모둠에 영향을 주지 않는다", () => {
    const state = { ...initialState(), mode: "teacher" as const };
    expect(
      reducer(state, {
        type: "score",
        id: "a",
        participantId: "g1",
        delta: -1,
      }),
    ).toEqual(state);
    const next = reducer(state, {
      type: "score",
      id: "b",
      participantId: "g2",
      delta: 1,
    });
    expect(scoreFor(next, "g1")).toBe(0);
    expect(scoreFor(next, "g2")).toBe(1);
  });
  it("모둠 수를 줄였다 늘려도 기존 기록을 지우지 않는다", () => {
    const state = { ...initialState(), mode: "teacher" as const };
    const scored = reducer(state, {
      type: "score",
      id: "a",
      participantId: "g5",
      delta: 1,
    });
    const fewer = reducer(scored, {
      type: "start",
      mode: "group",
      groups: state.groups.slice(0, 2),
    });
    const restored = reducer(fewer, {
      type: "start",
      mode: "group",
      groups: state.groups,
    });
    expect(scoreFor(restored, "g5")).toBe(1);
  });
  it("등급 경계에서 승급한다", () => {
    expect(rankFor(0).name).toBe("견습 탐정");
    expect(rankFor(59).name).toBe("견습 탐정");
    expect(rankFor(60).name).toBe("탐정");
    expect(rankFor(140).name).toBe("선임 탐정");
    expect(rankFor(240).name).toBe("수석 탐정");
  });
});

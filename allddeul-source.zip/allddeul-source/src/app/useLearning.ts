import { useApp } from "./AppProvider";
import { actorId, actorName, emptyNotebook } from "../lib/learning";
import type { ChapterId, Notebook } from "../types";
import { playClueSound } from "../lib/sound";

export function useLearning(participantId?: string) {
  const { state, dispatch } = useApp();
  const id = participantId ?? actorId(state);
  const note = state.learning[id] ?? emptyNotebook();
  const patch = (patch: Partial<Notebook>) =>
    dispatch({ type: "learn", participantId: id, patch });
  const reward = (key: string, points: number, chapter: ChapterId) => {
    if (
      !state.scores.some((e) => e.id === `${id}:${key}`) &&
      state.settings.sound
    )
      playClueSound();
    dispatch({ type: "reward", participantId: id, key, points, chapter });
  };
  return {
    state,
    dispatch,
    id,
    name: actorName(state, id),
    note,
    patch,
    reward,
  };
}

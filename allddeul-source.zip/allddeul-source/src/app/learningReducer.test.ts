import { describe, expect, it } from "vitest";
import { reducer } from "./reducer";
import {
  initialState,
  loadState,
  saveState,
  STORAGE_KEY,
} from "../lib/storage";
import { emptyNotebook, makeReport } from "../lib/learning";
import { scoreFor } from "../lib/scoring";
import { validNotebook } from "../lib/validateNotebook";
import type { AppState } from "../types";

const classroom = (): AppState => ({ ...initialState(), mode: "teacher" });
describe("봉인 봉투와 점수의 원자적 처리", () => {
  it("예측은 한 번 봉인하고 수정·중복 점수를 막는다", () => {
    const first = reducer(classroom(), {
      type: "predict",
      participantId: "g1",
      choice: "A",
      reason: "같은 양으로 생각했어요",
    });
    const second = reducer(first, {
      type: "predict",
      participantId: "g1",
      choice: "B",
      reason: "바꾸기",
    });
    expect(second.learning.g1.prediction?.choice).toBe("A");
    expect(scoreFor(second, "g1")).toBe(10);
  });
  it("계산 전에는 개봉하지 않고 계산 뒤 맞힌 모둠에 한 번 보너스를 준다", () => {
    let state = reducer(classroom(), {
      type: "predict",
      participantId: "g1",
      choice: "A",
      reason: "",
    });
    state.learning.g2 = {
      ...emptyNotebook(),
      prediction: { choice: "B", reason: "", eligible: true },
    };
    expect(
      reducer(state, { type: "reveal", participantId: "g1" }).envelopeRevealed,
    ).toBe(false);
    state.learning.g1.calculations.drink = {
      stage: 4,
      place: 1,
      entries: [[], [], [], []],
    };
    const revealed = reducer(state, { type: "reveal", participantId: "g1" });
    expect(revealed.envelopeRevealed).toBe(true);
    expect(scoreFor(revealed, "g1")).toBe(15);
    expect(scoreFor(revealed, "g2")).toBe(0);
    expect(
      reducer(revealed, { type: "reveal", participantId: "g1" }).scores,
    ).toEqual(revealed.scores);
  });
  it("개봉 후 새로 한 예측에는 보너스를 주지 않는다", () => {
    let state = reducer(
      { ...classroom(), envelopeRevealed: true },
      { type: "predict", participantId: "g1", choice: "A", reason: "" },
    );
    state.learning.g1.calculations.drink = {
      stage: 4,
      place: 1,
      entries: [[], [], [], []],
    };
    state = reducer(state, { type: "reveal", participantId: "g1" });
    expect(state.learning.g1.prediction?.eligible).toBe(false);
    expect(scoreFor(state, "g1")).toBe(10);
  });
  it("힌트 세 단계는 보상을 줄이고 재방문은 중복 보상을 주지 않는다", () => {
    let state = classroom();
    for (let i = 0; i < 5; i++)
      state = reducer(state, {
        type: "hint",
        participantId: "g1",
        key: "c4-flow",
      });
    state = reducer(state, {
      type: "reward",
      participantId: "g1",
      key: "c4-flow",
      points: 10,
      chapter: 4,
    });
    expect(state.learning.g1.hints["c4-flow"]).toBe(3);
    expect(scoreFor(state, "g1")).toBe(4);
    expect(
      reducer(state, {
        type: "reward",
        participantId: "g1",
        key: "c4-flow",
        points: 50,
        chapter: 4,
      }).scores,
    ).toEqual(state.scores);
  });
  it("미완료 장에는 배지를 주지 않고 완료 기록과 보상은 한 번만 반영한다", () => {
    let state = classroom();
    expect(
      reducer(state, { type: "complete", participantId: "g1", chapter: 1 })
        .progress,
    ).toEqual({});
    state = reducer(state, {
      type: "predict",
      participantId: "g1",
      choice: "B",
      reason: "",
    });
    state = reducer(state, {
      type: "learn",
      participantId: "g1",
      patch: { contexts: ["우유 200mL와 1L"], ownContext: "물감 두 통" },
    });
    const done = reducer(state, {
      type: "complete",
      participantId: "g1",
      chapter: 1,
    });
    expect(done.progress.g1.completedChapters).toEqual([1]);
    expect(done.progress.g1.badges).toHaveLength(1);
    expect(scoreFor(done, "g1")).toBe(30);
    expect(
      reducer(done, { type: "complete", participantId: "g1", chapter: 1 }),
    ).toEqual(done);
  });
  it("가족 선택은 어느 상품이든 유효한 이유를 고르면 점수를 준다", () => {
    const first = reducer(classroom(), {
      type: "family",
      participantId: "g1",
      scenario: "grandmother",
      answer: { choice: "A", reason: "보관 공간" },
    });
    const changed = reducer(first, {
      type: "family",
      participantId: "g1",
      scenario: "grandmother",
      answer: { choice: "B", reason: "유통기한" },
    });
    expect(changed.learning.g1.families.grandmother.choice).toBe("B");
    expect(scoreFor(changed, "g1")).toBe(10);
    expect(
      reducer(changed, {
        type: "family",
        participantId: "g1",
        scenario: "grandmother",
        answer: { choice: "A", reason: "" },
      }),
    ).toEqual(changed);
  });
  it("다른 모둠의 기록을 학생이 덮어쓰지 않는다", () => {
    const state = { ...classroom(), mode: "group" as const };
    expect(
      reducer(state, {
        type: "learn",
        participantId: "g2",
        patch: { pledge: "덮어쓰기" },
      }),
    ).toEqual(state);
    expect(
      reducer(state, {
        type: "reward",
        participantId: "g2",
        key: "fake",
        points: 50,
        chapter: 8,
      }),
    ).toEqual(state);
  });
});

describe("동료 평가", () => {
  it("받은 모둠에 교사가 한 번만 반영하며 반영 후 수정하지 않는다", () => {
    let state = reducer(classroom(), {
      type: "review",
      review: {
        id: "ignored",
        from: "g1",
        to: "g2",
        stars: [2, 3, 3],
        praise: "좋아요",
        wish: "글자를 크게",
      },
    });
    const before = scoreFor(state, "g2");
    expect(
      reducer({ ...state, mode: "group" }, { type: "applyReview", id: "g1:g2" })
        .reviews[0].applied,
    ).toBe(false);
    state = reducer(state, { type: "applyReview", id: "g1:g2" });
    expect(scoreFor(state, "g2")).toBe(before + 8);
    expect(reducer(state, { type: "applyReview", id: "g1:g2" })).toEqual(state);
    const edited = reducer(state, {
      type: "review",
      review: {
        id: "g1:g2",
        from: "g1",
        to: "g2",
        stars: [1, 1, 1],
        praise: "수정",
        wish: "수정",
      },
    });
    expect(edited).toEqual(state);
  });
  it("자기 자신을 평가할 수 없다", () => {
    expect(
      reducer(classroom(), {
        type: "review",
        review: {
          id: "self",
          from: "g1",
          to: "g1",
          stars: [3, 3, 3],
          praise: "",
          wish: "",
        },
      }).reviews,
    ).toEqual([]);
  });
});

describe("새 저장 구조와 기존 수첩 호환", () => {
  it("1단계 모둠·점수를 지우지 않고 활동 공간을 추가한다", () => {
    const { learning, reviews, envelopeRevealed, ...legacy } = classroom();
    const { speedLimit, ...settings } = legacy.settings;
    localStorage.setItem(
      STORAGE_KEY,
      JSON.stringify({
        ...legacy,
        settings,
        scores: [
          { id: "old", participantId: "g2", delta: 1, source: "teacher" },
        ],
      }),
    );
    const loaded = loadState();
    expect(loaded.status).toBe("available");
    expect(loaded.state.groups).toEqual(legacy.groups);
    expect(scoreFor(loaded.state, "g2")).toBe(1);
    expect(loaded.state.learning).toEqual({});
    expect(loaded.state.settings.speedLimit).toBe(false);
  });
  it("장별 데이터와 보고서·평가·보상을 새로고침 후 복원한다", () => {
    let state = classroom();
    const note = emptyNotebook();
    note.scoops["partial-cup"] = {
      prediction: "2 2/3",
      locked: true,
      scoops: 3,
      done: true,
    };
    note.report = makeReport(note.toolPair, "tool");
    note.reportSaved = true;
    state = reducer(state, { type: "learn", participantId: "g1", patch: note });
    state = reducer(state, {
      type: "reward",
      participantId: "g1",
      key: "c7-report",
      points: 10,
      chapter: 7,
    });
    expect(saveState(state)).toBe(true);
    expect(loadState()).toEqual({ state, status: "available" });
  });
  it("손상된 중첩 데이터는 안전하게 복구한다", () => {
    expect(validNotebook(emptyNotebook())).toBe(true);
    expect(validNotebook({ ...emptyNotebook(), outline: null })).toBe(false);
    expect(validNotebook({ ...emptyNotebook(), milkAmount: "0" })).toBe(false);
    const state = {
      ...classroom(),
      learning: { g1: { ...emptyNotebook(), hand: null } },
    };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    expect(loadState().status).toBe("recovered");
  });
});

import type {
  AppState,
  ChapterId,
  CollectionKind,
  Group,
  Mode,
  Notebook,
  PeerReview,
  Choice,
  FamilyAnswer,
} from "../types";
import { initialState } from "../lib/storage";
import { scoreFor } from "../lib/scoring";
import { canOpenChapter } from "../lib/progression";
import {
  actorId,
  chapterReady,
  completionBadge,
  emptyNotebook,
  knownFamily,
  pairWinner,
} from "../lib/learning";
import { productCases } from "../data/cases";

export type Action =
  | { type: "start"; mode: Mode; groups?: Group[]; nickname?: string }
  | { type: "settings"; patch: Partial<AppState["settings"]> }
  | { type: "group"; id: string }
  | { type: "selectCollection"; kind: CollectionKind }
  | { type: "teacherGroup"; id: string }
  | { type: "chapter"; id: ChapterId }
  | { type: "toggleChapter"; id: ChapterId }
  | { type: "allChapters"; open: boolean }
  | { type: "score"; id: string; participantId: string; delta: 1 | -1 }
  | { type: "learn"; participantId: string; patch: Partial<Notebook> }
  | { type: "hint"; participantId: string; key: string }
  | {
      type: "reward";
      participantId: string;
      key: string;
      points: number;
      chapter: ChapterId;
    }
  | { type: "complete"; participantId: string; chapter: ChapterId }
  | { type: "predict"; participantId: string; choice: Choice; reason: string }
  | { type: "reveal"; participantId: string }
  | {
      type: "family";
      participantId: string;
      scenario: string;
      answer: FamilyAnswer;
    }
  | { type: "review"; review: Omit<PeerReview, "applied"> }
  | { type: "applyReview"; id: string }
  | { type: "reset" };

function canWrite(state: AppState, id: string) {
  return (
    id === actorId(state) &&
    (id === "solo" || state.groups.some((group) => group.id === id))
  );
}
function award(
  state: AppState,
  id: string,
  key: string,
  points: number,
  chapter: ChapterId,
  source: "mission" | "peer" = "mission",
): AppState {
  const eventId = `${id}:${key}`;
  if (state.scores.some((e) => e.id === eventId)) return state;
  return {
    ...state,
    scores: [
      ...state.scores,
      {
        id: eventId,
        participantId: id,
        delta: Math.max(1, Math.min(50, points)),
        source,
        chapter,
      },
    ],
  };
}

export function reducer(state: AppState, action: Action): AppState {
  switch (action.type) {
    case "start": {
      const groups = action.groups ?? state.groups;
      return {
        ...state,
        mode: action.mode,
        groups,
        nickname: action.nickname?.trim() || state.nickname,
        activeGroupId: groups.some((group) => group.id === state.activeGroupId)
          ? state.activeGroupId
          : groups[0].id,
        teacher: {
          ...state.teacher,
          selectedGroupId: groups.some(
            (group) => group.id === state.teacher.selectedGroupId,
          )
            ? state.teacher.selectedGroupId
            : groups[0].id,
        },
      };
    }
    case "settings":
      return { ...state, settings: { ...state.settings, ...action.patch } };
    case "group":
      return state.groups.some((group) => group.id === action.id)
        ? { ...state, activeGroupId: action.id }
        : state;
    case "teacherGroup":
      return state.groups.some((group) => group.id === action.id)
        ? {
            ...state,
            teacher: { ...state.teacher, selectedGroupId: action.id },
          }
        : state;
    case "selectCollection":
      return {
        ...state,
        teacher: { ...state.teacher, collectionKind: action.kind },
      };
    case "chapter":
      return canOpenChapter(state, action.id)
        ? { ...state, currentChapter: action.id }
        : state;
    case "toggleChapter":
      if (state.mode !== "teacher") return state;
      return {
        ...state,
        openChapters: state.openChapters.includes(action.id)
          ? state.openChapters.filter((id) => id !== action.id)
          : [...state.openChapters, action.id].sort(),
      };
    case "allChapters":
      return state.mode === "teacher"
        ? {
            ...state,
            openChapters: action.open ? [1, 2, 3, 4, 5, 6, 7, 8] : [],
          }
        : state;
    case "score":
      if (
        state.mode !== "teacher" ||
        (!state.groups.some((group) => group.id === action.participantId) &&
          action.participantId !== "solo")
      )
        return state;
      if (
        state.scores.some((entry) => entry.id === action.id) ||
        scoreFor(state, action.participantId) + action.delta < 0
      )
        return state;
      return {
        ...state,
        scores: [
          ...state.scores,
          {
            id: action.id,
            participantId: action.participantId,
            delta: action.delta,
            source: "teacher",
          },
        ],
      };
    case "learn": {
      if (!canWrite(state, action.participantId)) return state;
      return {
        ...state,
        learning: {
          ...state.learning,
          [action.participantId]: {
            ...(state.learning[action.participantId] ?? emptyNotebook()),
            ...action.patch,
          },
        },
      };
    }
    case "hint": {
      if (!canWrite(state, action.participantId)) return state;
      const note = state.learning[action.participantId] ?? emptyNotebook();
      return {
        ...state,
        learning: {
          ...state.learning,
          [action.participantId]: {
            ...note,
            hints: {
              ...note.hints,
              [action.key]: Math.min(3, (note.hints[action.key] ?? 0) + 1),
            },
          },
        },
      };
    }
    case "reward": {
      if (!canWrite(state, action.participantId)) return state;
      const hints =
        state.learning[action.participantId]?.hints[action.key] ?? 0;
      return award(
        state,
        action.participantId,
        action.key,
        action.points - hints * 2,
        action.chapter,
      );
    }
    case "complete": {
      if (
        !canWrite(state, action.participantId) ||
        !canOpenChapter(state, action.chapter) ||
        !chapterReady(state, action.participantId, action.chapter)
      )
        return state;
      const previous = state.progress[action.participantId] ?? {
        completedChapters: [],
        badges: [],
      };
      if (previous.completedChapters.includes(action.chapter)) return state;
      const next = {
        ...state,
        progress: {
          ...state.progress,
          [action.participantId]: {
            completedChapters: [
              ...previous.completedChapters,
              action.chapter,
            ].sort(),
            badges: [...previous.badges, completionBadge(action.chapter)],
          },
        },
      };
      return award(
        next,
        action.participantId,
        `complete-${action.chapter}`,
        20,
        action.chapter,
      );
    }
    case "predict": {
      if (!canWrite(state, action.participantId)) return state;
      const note = state.learning[action.participantId] ?? emptyNotebook();
      if (note.prediction) return state;
      const next = {
        ...state,
        learning: {
          ...state.learning,
          [action.participantId]: {
            ...note,
            prediction: {
              choice: action.choice,
              reason: action.reason.trim(),
              eligible: !state.envelopeRevealed,
            },
          },
        },
      };
      return award(next, action.participantId, "c1-prediction", 10, 1);
    }
    case "reveal": {
      if (
        !canWrite(state, action.participantId) ||
        state.learning[action.participantId]?.calculations.drink?.stage !== 4
      )
        return state;
      let next = { ...state, envelopeRevealed: true };
      for (const [id, note] of Object.entries(state.learning)) {
        if (
          note.prediction?.eligible &&
          note.prediction.choice === pairWinner(productCases[0])
        )
          next = award(next, id, "prediction-bonus", 5, 3);
      }
      return next;
    }
    case "family": {
      if (
        !canWrite(state, action.participantId) ||
        !knownFamily(action.scenario, action.answer.reason)
      )
        return state;
      const note = state.learning[action.participantId] ?? emptyNotebook();
      const next = {
        ...state,
        learning: {
          ...state.learning,
          [action.participantId]: {
            ...note,
            families: { ...note.families, [action.scenario]: action.answer },
          },
        },
      };
      return award(
        next,
        action.participantId,
        `family-${action.scenario}`,
        10,
        8,
      );
    }
    case "review": {
      if (
        !canWrite(state, action.review.from) ||
        action.review.from === action.review.to ||
        !state.groups.some((g) => g.id === action.review.to) ||
        !action.review.stars.every(
          (n) => Number.isInteger(n) && n >= 1 && n <= 3,
        )
      )
        return state;
      const review = {
        ...action.review,
        id: `${action.review.from}:${action.review.to}`,
        applied: false,
      };
      if (state.reviews.some((r) => r.id === review.id && r.applied))
        return state;
      const next = {
        ...state,
        reviews: [...state.reviews.filter((r) => r.id !== review.id), review],
      };
      return award(next, review.from, "c7-review", 10, 7);
    }
    case "applyReview": {
      const review = state.reviews.find((r) => r.id === action.id);
      if (state.mode !== "teacher" || !review || review.applied) return state;
      const next = {
        ...state,
        reviews: state.reviews.map((r) =>
          r.id === review.id ? { ...r, applied: true } : r,
        ),
      };
      return award(
        next,
        review.to,
        `peer-${review.id}`,
        review.stars.reduce((a, b) => a + b, 0),
        7,
        "peer",
      );
    }
    case "reset":
      return initialState();
  }
}

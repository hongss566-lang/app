import { useCallback, useId, useState, type SyntheticEvent } from "react";
import { useApp } from "../app/AppProvider";
import { Presentation } from "../components/game/Presentation";
import { Icon, type IconName } from "../components/ui/Icon";
import type { Group, Mode } from "../types";
import styles from "./Adventure.module.css";
import { characters } from "../data/adventure";
import { CharacterPortrait } from "../components/game/StoryScene";

const modes: {
  id: Mode | "guide";
  title: string;
  subtitle: string;
  icon: IconName;
  tag: string;
}[] = [
  {
    id: "guide",
    title: "탐정단 소개",
    subtitle: "네 친구와 함께 축제를 구해요",
    icon: "info",
    tag: "올리의 모험 안내",
  },
  {
    id: "group",
    title: "모둠 모드",
    subtitle: "친구들과 힘을 모아 해결해요",
    icon: "users",
    tag: "함께하는 탐정",
  },
  {
    id: "solo",
    title: "혼자 하기",
    subtitle: "내 속도로 단서를 찾아가요",
    icon: "person",
    tag: "나만의 탐정 수첩",
  },
];

export function StartScreen({
  onStarted,
  onResume,
  editingGroups = false,
}: {
  onStarted: (mode: Mode) => void;
  onResume?: () => void;
  editingGroups?: boolean;
}) {
  const { state, dispatch } = useApp();
  const [mode, setMode] = useState<Mode>(
    editingGroups || state.mode === "teacher"
      ? "group"
      : (state.mode ?? "solo"),
  );
  const [groups, setGroups] = useState<Group[]>(state.groups);
  const [nickname, setNickname] = useState(state.mode ? state.nickname : "");
  const [error, setError] = useState("");
  const [showGuide, setShowGuide] = useState(false);
  const closeGuide = useCallback(() => setShowGuide(false), []);
  const errorId = useId();

  function start(event: SyntheticEvent) {
    event.preventDefault();
    if (mode === "group" && groups.some((group) => !group.name.trim())) {
      setError("모든 모둠의 이름을 적어 주세요.");
      return;
    }
    if (
      mode === "group" &&
      new Set(groups.map((group) => group.name.trim())).size !== groups.length
    ) {
      setError("모둠 이름을 서로 다르게 적어 주세요.");
      return;
    }
    if (mode === "solo" && !nickname.trim()) {
      setError("사용할 별명을 적어 주세요.");
      return;
    }
    const nextMode = editingGroups ? "teacher" : mode;
    dispatch({
      type: "start",
      mode: nextMode,
      ...(mode === "group"
        ? {
            groups: groups.map((group) => ({
              ...group,
              name: group.name.trim(),
            })),
          }
        : {}),
      ...(mode === "solo" ? { nickname: nickname.trim() } : {}),
    });
    onStarted(nextMode);
  }

  return (
    <div className={styles.lobby}>
      <section className={styles.startHero}>
        <span className={styles.heroRibbon}>
          네 친구와 함께, 반짝마을 축제를 구하라!
        </span>
        <div className={styles.titleSign}>
          <Icon name="search" size={52} />
          <h1>
            알뜰 소비 <em>탐정단</em>
          </h1>
        </div>
        <p>분수와 소수의 나눗셈으로, 가격표 뒤에 숨은 진짜 단서를 찾아라!</p>
        <div className={styles.heroFacts}>
          <span>
            <Icon name="file" size={16} />
            8개의 사건
          </span>
          <span>
            <Icon name="badge" size={16} />
            8개의 탐정 배지
          </span>
          <span>6학년 수학</span>
        </div>
      </section>
      <section className={styles.startPanel} aria-labelledby="start-title">
        <div className={styles.sectionTitle}>
          <div>
            <span className="eyebrow">
              {editingGroups ? "교사실 · 모둠 설정" : "탐정 사무소 입장"}
            </span>
            <h2 id="start-title">
              {editingGroups
                ? "모둠 이름과 수를 정해요"
                : "어떻게 수사를 시작할까요?"}
            </h2>
          </div>
          {onResume && (
            <button className="text-button" onClick={onResume}>
              {editingGroups ? "교사실로 돌아가기" : "기존 기록 이어보기"}
              <Icon name="arrow" size={17} />
            </button>
          )}
        </div>
        {!editingGroups && (
          <div
            className={styles.modeGrid}
            role="group"
            aria-label="활동 모드 선택"
          >
            {modes.map((item) => (
              <button
                key={item.id}
                type="button"
                className={`${styles.modeCard} ${mode === item.id ? styles.selectedMode : ""}`}
                data-mode={item.id === "guide" ? "teacher" : item.id}
                aria-pressed={
                  item.id === "guide" ? undefined : mode === item.id
                }
                onClick={() => {
                  if (item.id === "guide") {
                    setShowGuide(true);
                    return;
                  }
                  setMode(item.id);
                  setError("");
                }}
              >
                <span className={styles.modeArtwork} aria-hidden="true" />
                <span className={styles.modeTag}>
                  <Icon name={item.icon} size={16} />
                  {item.tag}
                </span>
                <span className={styles.modeCaption}>
                  <strong>{item.title}</strong>
                  <span>{item.subtitle}</span>
                </span>
                {mode === item.id && (
                  <span className={styles.selectionDot}>
                    <Icon name="check" size={19} />
                    선택 완료
                  </span>
                )}
              </button>
            ))}
          </div>
        )}
        <form
          onSubmit={start}
          className={styles.setupForm}
          onKeyDown={(event) => {
            // allow-forms가 없는 미리보기 프레임에서도 키보드로 시작할 수 있다.
            if (
              event.key === "Enter" &&
              event.target instanceof HTMLInputElement &&
              !event.nativeEvent.isComposing
            )
              start(event);
          }}
        >
          {mode === "group" && (
            <>
              <div className={styles.setupHeading}>
                <div>
                  <h3>우리 모둠의 이름을 알려 주세요</h3>
                  <p>한 기기에서 모둠을 바꿔 가며 활동할 수 있어요.</p>
                </div>
                <label className={styles.countLabel}>
                  모둠 수
                  <select
                    value={groups.length}
                    onChange={(event) => {
                      const count = Number(event.target.value);
                      setGroups((current) =>
                        Array.from(
                          { length: count },
                          (_, index) =>
                            current[index] ??
                            state.groups[index] ?? {
                              id: `g${index + 1}`,
                              name: `${index + 1}모둠`,
                            },
                        ),
                      );
                      setError("");
                    }}
                  >
                    {[2, 3, 4, 5, 6].map((count) => (
                      <option value={count} key={count}>
                        {count}개
                      </option>
                    ))}
                  </select>
                </label>
              </div>
              <div className={styles.groupInputs}>
                {groups.map((group, index) => (
                  <label key={group.id}>
                    <span>{index + 1}모둠 이름</span>
                    <input
                      value={group.name}
                      maxLength={20}
                      required
                      aria-describedby={error ? errorId : undefined}
                      onChange={(event) => {
                        setGroups((current) =>
                          current.map((item) =>
                            item.id === group.id
                              ? { ...item, name: event.target.value }
                              : item,
                          ),
                        );
                        setError("");
                      }}
                    />
                  </label>
                ))}
              </div>
            </>
          )}
          {mode === "solo" && (
            <div className={styles.soloSetup}>
              <label htmlFor="nickname">
                탐정 별명
                <input
                  id="nickname"
                  value={nickname}
                  maxLength={20}
                  required
                  placeholder="예: 반짝 탐정"
                  aria-describedby="nickname-help"
                  onChange={(event) => {
                    setNickname(event.target.value);
                    setError("");
                  }}
                />
              </label>
              <p id="nickname-help">
                실명 대신 좋아하는 별명을 써 주세요. 사진이나 개인정보는 받지
                않아요.
              </p>
            </div>
          )}
          {mode === "teacher" && (
            <div className={styles.teacherIntro}>
              <span className={styles.softIcon}>
                <Icon name="teacher" size={27} />
              </span>
              <div>
                <h3>오늘의 수업, 여기서 준비해요</h3>
                <p>
                  장 열기·잠그기, 모둠 점수 조정, 투사 모드를 사용할 수 있어요.
                  <br />
                  모둠 이름은 ‘모둠 모드’에서 설정할 수 있어요.
                </p>
              </div>
            </div>
          )}
          {error && (
            <p id={errorId} role="alert" className="form-error">
              {error}
            </p>
          )}
          <div className={styles.setupFooter}>
            <span>
              <Icon name="lock" size={16} />
              로그인 없이, 이 브라우저에만 저장해요
            </span>
            <button type="button" onClick={start} className={styles.playButton}>
              <span className={styles.playTriangle} aria-hidden="true" />
              {editingGroups
                ? "모둠 설정 저장하기"
                : mode === "teacher"
                  ? "교사실 열기"
                  : "탐정 수첩 펼치기"}
              <Icon name="arrow" size={24} />
            </button>
          </div>
        </form>
      </section>
      <div className={styles.startNote}>
        <span>
          <Icon name="leaf" size={19} />
          계산으로 찾고, 이유로 선택해요.
        </span>
        <button
          className={styles.guideButton}
          onClick={() => setShowGuide(true)}
        >
          <Icon name="info" size={21} />
          게임 안내
        </button>
      </div>
      {showGuide && (
        <Presentation
          title="탐정단 게임 안내"
          onClose={closeGuide}
          closeLabel="안내 닫기 (Esc)"
        >
          <section className={styles.guide}>
            <span className="eyebrow">교사 설정 없이, 바로 모험 시작!</span>
            <h2>반짝마트 수사는 이렇게!</h2>
            <div className={styles.characterRoster}>
              {Object.entries(characters).map(([key, character]) => (
                <div key={key}>
                  <CharacterPortrait who={key as keyof typeof characters} />
                  <strong>
                    {character.name} · {character.animal}
                  </strong>
                  <p>{character.role}</p>
                </div>
              ))}
            </div>
            <ol>
              <li>
                <strong>탐정단을 골라요</strong>
                <p>모둠 이름이나 나만의 별명을 정하고 수사를 시작해요.</p>
              </li>
              <li>
                <strong>사건 지도를 탐험해요</strong>
                <p>
                  1장부터 ‘사건 소개 → 수사하기 → 사건 해결’ 순서로 진행해요.
                  배지를 받으면 다음 사건이 자동으로 열려요.
                </p>
              </li>
              <li>
                <strong>단서와 배지를 모아요</strong>
                <p>
                  계산하고, 실험하고, 이유를 설명해요. 틀려도 감점은 없고,
                  힌트는 한 단계에 보상 2점씩 줄어요.
                </p>
              </li>
              <li>
                <strong>8개 사건을 해결해요</strong>
                <p>
                  배지를 모두 모으면 알뜰 소비 탐정 수료증을 받을 수 있어요.
                  기록은 이 브라우저에 자동으로 남아요.
                </p>
              </li>
            </ol>
            <button className="btn primary" onClick={closeGuide}>
              좋아, 준비됐어!
            </button>
            <details className={styles.optionalTools}>
              <summary>선택: 교사용 수업 도구</summary>
              <p>
                학생의 모험에는 필요하지 않아요. 한 기기의 모둠 집계나 발표
                도구를 사용할 때만 열어요.
              </p>
              <button
                className="btn secondary"
                onClick={() => {
                  dispatch({ type: "start", mode: "teacher" });
                  onStarted("teacher");
                }}
              >
                교사실 열기
              </button>
            </details>
          </section>
        </Presentation>
      )}
    </div>
  );
}

import { useApp } from "../app/AppProvider";
import { chapters } from "../data/cases";
import { Icon, type IconName } from "../components/ui/Icon";
import { scoreFor, rankFor, newScoreEventId } from "../lib/scoring";
import { playClueSound } from "../lib/sound";
import type { ChapterId, CollectionKind } from "../types";
import styles from "./Screens.module.css";
import { TeacherCollection } from "../components/game/CollectionForms";

const collections: {
  id: CollectionKind;
  label: string;
  icon: IconName;
  description: string;
}[] = [
  {
    id: "prediction",
    label: "1장 예측",
    icon: "envelope",
    description: "A / B / 똑같다 예측과 이유",
  },
  {
    id: "peerReview",
    label: "7장 동료 평가",
    icon: "star",
    description: "평가할 모둠, 별점과 친구에게 전할 말",
  },
  {
    id: "familyChoice",
    label: "8장 가족 선택",
    icon: "users",
    description: "가족 상황에 맞는 상품 선택과 이유",
  },
];

export function TeacherScreen({
  onOpen,
  onReset,
  onConfigure,
}: {
  onOpen: (id: ChapterId) => void;
  onReset: () => void;
  onConfigure: () => void;
}) {
  const { state, dispatch } = useApp();
  const collection = collections.find(
    (item) => item.id === state.teacher.collectionKind,
  )!;
  const selected = state.groups.find(
    (group) => group.id === state.teacher.selectedGroupId,
  )!;
  const selectedIndex = state.groups.findIndex(
    (group) => group.id === selected.id,
  );
  const allOpen = state.openChapters.length === 8;
  const totalScore = state.groups.reduce(
    (sum, group) => sum + scoreFor(state, group.id),
    0,
  );

  function adjustScore(participantId: string, delta: 1 | -1) {
    dispatch({ type: "score", id: newScoreEventId(), participantId, delta });
    if (delta === 1 && state.settings.sound) playClueSound();
  }

  return (
    <>
      <div className={styles.teacherHeading}>
        <div>
          <span className="eyebrow">수업 안내자를 위한 공간</span>
          <h1>오늘의 탐정 수업을 준비해요</h1>
          <p>
            학생은 교사 설정 없이 모험할 수 있어요. 함께 발표하거나 한 기기에서
            모둠을 살필 때 쓰는 선택 도구예요.
          </p>
        </div>
        <span className={styles.teacherStamp}>
          <Icon name="teacher" size={28} />
          교사실
        </span>
      </div>
      <div className={styles.teacherSettings}>
        <label className={styles.toggleCard}>
          <Icon name="screen" size={25} />
          <span>
            <strong>투사 모드</strong>
            <small>글자와 버튼을 크게, 장식은 간결하게</small>
          </span>
          <input
            type="checkbox"
            checked={state.settings.projection}
            onChange={(event) =>
              dispatch({
                type: "settings",
                patch: { projection: event.target.checked },
              })
            }
            role="switch"
          />
          <span className={styles.switch} aria-hidden="true" />
        </label>
        <label className={styles.toggleCard}>
          <Icon name="eye" size={25} />
          <span>
            <strong>교사용 정답 보기</strong>
            <small>장별 활동의 풀이를 볼 때 사용해요</small>
          </span>
          <input
            type="checkbox"
            checked={state.settings.showAnswers}
            onChange={(event) =>
              dispatch({
                type: "settings",
                patch: { showAnswers: event.target.checked },
              })
            }
            role="switch"
          />
          <span className={styles.switch} aria-hidden="true" />
        </label>
        <label className={styles.toggleCard}>
          <Icon name="screen" size={25} />
          <span>
            <strong>스피드 라운드 시간 제한</strong>
            <small>켜면 다섯 문제를 150초 안에 도전해요</small>
          </span>
          <input
            type="checkbox"
            checked={state.settings.speedLimit}
            onChange={(event) =>
              dispatch({
                type: "settings",
                patch: { speedLimit: event.target.checked },
              })
            }
            role="switch"
          />
          <span className={styles.switch} aria-hidden="true" />
        </label>
      </div>

      <section
        className={styles.panel}
        aria-labelledby="chapter-settings-title"
      >
        <div className={styles.sectionTitle}>
          <div>
            <span className="eyebrow">수업 진행</span>
            <h2 id="chapter-settings-title">오늘은 어떤 사건을 열까요?</h2>
          </div>
          <div className={styles.inlineActions}>
            <button
              className="text-button"
              onClick={() => dispatch({ type: "allChapters", open: true })}
              disabled={allOpen}
            >
              모두 열기
            </button>
            <button
              className="text-button"
              onClick={() => dispatch({ type: "allChapters", open: false })}
              disabled={state.openChapters.length === 0}
            >
              모두 잠그기
            </button>
          </div>
        </div>
        <p className={styles.panelHelp}>
          오늘 함께 살펴볼 사건을 표시해요. 이 표시는 학생의 모험 순서에 영향을
          주지 않아요. 학생은 자기 수첩에서 앞 사건을 해결하면 다음 장이 열리고,
          교사는 모든 장을 미리 볼 수 있어요.
        </p>
        <div className={styles.chapterSettings}>
          {chapters.map((chapter) => {
            const open = state.openChapters.includes(chapter.id);
            return (
              <div
                key={chapter.id}
                className={`${styles.chapterSetting} stage-${chapter.color}`}
              >
                <span className={styles.chapterSettingNumber}>
                  {chapter.id}
                </span>
                <div>
                  <span>
                    {chapter.stage} · {chapter.stageLabel}
                  </span>
                  <strong>{chapter.title}</strong>
                </div>
                <button
                  className={open ? styles.openLock : styles.closedLock}
                  aria-label={`${chapter.id}장 ${chapter.title} ${open ? "잠그기" : "열기"}`}
                  aria-pressed={open}
                  onClick={() =>
                    dispatch({ type: "toggleChapter", id: chapter.id })
                  }
                >
                  <Icon name={open ? "unlock" : "lock"} size={17} />
                  {open ? "열림" : "잠김"}
                </button>
                <button
                  className={styles.previewButton}
                  aria-label={`${chapter.id}장 ${chapter.title} 미리보기`}
                  onClick={() => onOpen(chapter.id)}
                >
                  소개 보기
                  <Icon name="arrow" size={16} />
                </button>
              </div>
            );
          })}
        </div>
      </section>

      <section className={styles.panel} aria-labelledby="group-entry-title">
        <div className={styles.sectionTitle}>
          <div>
            <span className="eyebrow">한 기기로 돌아가며</span>
            <h2 id="group-entry-title">모둠별로 입력받기</h2>
          </div>
          <span className={styles.smallPill}>입력하면 바로 집계</span>
        </div>
        <p className={styles.panelHelp}>
          활동과 모둠을 고르고 기록 버튼을 누르세요. 다음 모둠으로 넘어가면 같은
          자리에서 차례로 입력받을 수 있어요.
        </p>
        <div
          className={styles.collectionTabs}
          role="group"
          aria-label="모둠 입력 활동"
        >
          {collections.map((item) => (
            <button
              key={item.id}
              aria-pressed={collection.id === item.id}
              onClick={() =>
                dispatch({ type: "selectCollection", kind: item.id })
              }
            >
              <Icon name={item.icon} size={18} />
              {item.label}
            </button>
          ))}
        </div>
        <div
          className={styles.groupButtons}
          role="group"
          aria-label="입력받을 모둠"
        >
          {state.groups.map((group, index) => (
            <button
              key={group.id}
              aria-pressed={selected.id === group.id}
              onClick={() => dispatch({ type: "teacherGroup", id: group.id })}
            >
              <span>{String(index + 1).padStart(2, "0")}</span>
              {group.name}
            </button>
          ))}
        </div>
        <div className={styles.collectionBody}>
          <div>
            <span className="eyebrow">현재 선택한 모둠</span>
            <h3>
              {selected.name} · {collection.label}
            </h3>
            <p>{collection.description}</p>
          </div>
          <button
            className="btn secondary"
            onClick={() =>
              dispatch({
                type: "teacherGroup",
                id: state.groups[(selectedIndex + 1) % state.groups.length].id,
              })
            }
          >
            {selectedIndex === state.groups.length - 1
              ? "첫 모둠으로"
              : "다음 모둠"}
            <Icon name="arrow" size={18} />
          </button>
        </div>
        <TeacherCollection
          key={`${selected.id}-${collection.id}`}
          kind={collection.id}
          participantId={selected.id}
        />
      </section>

      <section className={styles.panel} aria-labelledby="scoreboard-title">
        <div className={styles.sectionTitle}>
          <div>
            <span className="eyebrow">함께 모은 단서</span>
            <h2 id="scoreboard-title">모둠 점수판</h2>
          </div>
          <span className={styles.classScore}>
            학급 합계 <strong>{totalScore.toLocaleString("ko-KR")}</strong>점
          </span>
        </div>
        <div className={styles.scoreboard}>
          {state.groups.map((group, index) => {
            const score = scoreFor(state, group.id);
            return (
              <div className={styles.scoreRow} key={group.id}>
                <span className={styles.scoreIndex}>
                  {String(index + 1).padStart(2, "0")}
                </span>
                <div className={styles.scoreName}>
                  <strong>{group.name}</strong>
                  <span>{rankFor(score).name}</span>
                </div>
                <div className={styles.scoreAdjust}>
                  <button
                    aria-label={`${group.name} 점수 1점 빼기`}
                    disabled={score === 0}
                    onClick={() => adjustScore(group.id, -1)}
                  >
                    −
                  </button>
                  <output aria-label={`${group.name} 점수`} aria-live="polite">
                    {score}
                  </output>
                  <button
                    aria-label={`${group.name} 점수 1점 더하기`}
                    onClick={() => adjustScore(group.id, 1)}
                  >
                    +
                  </button>
                </div>
              </div>
            );
          })}
        </div>
        <div className={styles.scoreboardFoot}>
          <p>
            점수는 0점 아래로 내려가지 않아요. 같은 기기에 모둠별로 저장돼요.
          </p>
          <button className="text-button" onClick={onConfigure}>
            모둠 이름·수 바꾸기
            <Icon name="arrow" size={16} />
          </button>
        </div>
      </section>
      <section className={styles.resetPanel} aria-labelledby="reset-title">
        <div>
          <h2 id="reset-title">새 수업을 시작할 때</h2>
          <p>모든 모둠과 개인의 기록을 지우고 처음으로 돌아가요.</p>
        </div>
        <button className="btn danger-outline" onClick={onReset}>
          <Icon name="reset" size={18} />
          데이터 초기화
        </button>
      </section>
    </>
  );
}

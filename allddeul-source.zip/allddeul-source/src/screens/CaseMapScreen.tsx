import { useApp } from "../app/AppProvider";
import { chapters } from "../data/cases";
import { Icon } from "../components/ui/Icon";
import { ChapterEmblem } from "../components/game/ChapterEmblem";
import { rankFor, scoreFor } from "../lib/scoring";
import type { ChapterId } from "../types";
import styles from "./Adventure.module.css";
import { badgeNames } from "../data/cases";
import { canOpenChapter } from "../lib/progression";
import { adventure } from "../data/adventure";

export function CaseMapScreen({ onOpen }: { onOpen: (id: ChapterId) => void }) {
  const { state } = useApp();
  const id =
    state.mode === "solo"
      ? "solo"
      : state.mode === "teacher"
        ? state.teacher.selectedGroupId
        : state.activeGroupId;
  const name =
    id === "solo"
      ? state.nickname
      : state.groups.find((group) => group.id === id)?.name;
  const progress = state.progress[id];
  const total = scoreFor(state, id);
  const solved = progress?.completedChapters.length ?? 0;
  const nextCase = chapters.find(
    (chapter) =>
      !progress?.completedChapters.includes(chapter.id) &&
      canOpenChapter(state, chapter.id),
  );
  return (
    <div className={styles.adventureMap}>
      <section className={styles.mapHero}>
        <div>
          <span className={styles.mapRibbon}>반짝마트 탐험 지도</span>
          <h1>{name}, 수사를 시작하자!</h1>
          <p>
            루미·모아·두리·올리와 8개의 사건을 해결하고 반짝마을 축제를
            완성해요.
          </p>
          {nextCase && (
            <button
              className={styles.continueButton}
              onClick={() => onOpen(nextCase.id)}
            >
              다음 수사 · {nextCase.id}장 {nextCase.title}
              <Icon name="arrow" size={20} />
            </button>
          )}
        </div>
        <div className={styles.mapProgress}>
          <Icon name="badge" size={36} />
          <strong>
            {solved}
            <small> / 8</small>
          </strong>
          <span>해결한 사건</span>
          <div
            className={styles.progressTrack}
            role="progressbar"
            aria-label="전체 사건 해결"
            aria-valuemin={0}
            aria-valuemax={8}
            aria-valuenow={solved}
          >
            <span style={{ width: `${(solved / 8) * 100}%` }} />
          </div>
        </div>
      </section>
      <div className={styles.statsGrid}>
        <div>
          <span className={styles.statIcon}>
            <Icon name="search" size={24} />
          </span>
          <div>
            <span>모은 단서</span>
            <strong>
              {total.toLocaleString("ko-KR")}
              <small>점</small>
            </strong>
          </div>
        </div>
        <div>
          <span className={styles.statIcon}>
            <Icon name="file" size={24} />
          </span>
          <div>
            <span>해결한 사건</span>
            <strong>
              {progress?.completedChapters.length ?? 0}
              <small>/ 8장</small>
            </strong>
          </div>
        </div>
        <div>
          <span className={styles.statIcon}>
            <Icon name="badge" size={24} />
          </span>
          <div>
            <span>현재 탐정 등급</span>
            <strong className={styles.rankText}>{rankFor(total).name}</strong>
          </div>
        </div>
      </div>
      <section className={styles.mapBoard} aria-labelledby="case-list-title">
        <div className={styles.sectionTitle}>
          <div>
            <span className="eyebrow">반짝마을 축제를 향한 모험</span>
            <h2 id="case-list-title">도전할 사건을 골라요</h2>
          </div>
          <span className={styles.sectionHelp}>
            <Icon name="info" size={16} />
            사건을 해결하면 다음 길이 열려요
          </span>
        </div>
        <div className={styles.caseGrid}>
          <svg
            className={styles.mapPath}
            viewBox="0 0 100 100"
            preserveAspectRatio="none"
            aria-hidden="true"
          >
            <path className={styles.desktopPath} d="M12.5 25H87.5V75H12.5" />
            <path
              className={styles.tabletPath}
              d="M25 12.5H75V37.5H25V62.5H75V87.5H25"
            />
          </svg>
          {chapters.map((chapter) => {
            const locked = !canOpenChapter(state, chapter.id);
            const disabled = locked;
            const completed = progress?.completedChapters.includes(chapter.id);
            return (
              <button
                key={chapter.id}
                className={`${styles.caseCard} stage-${chapter.color} ${disabled ? styles.lockedCard : ""} ${completed ? styles.completedCard : ""} ${nextCase?.id === chapter.id ? styles.nextCase : ""}`}
                disabled={disabled}
                aria-label={`${chapter.id}장 ${chapter.title}${disabled ? " · 잠김" : " · 사건 소개 보기"}`}
                onClick={() => onOpen(chapter.id)}
              >
                <span className={styles.folderTab}>
                  {completed ? <Icon name="check" size={17} /> : chapter.id}
                </span>
                <span className={styles.caseTop}>
                  <span className={styles.stageTag}>
                    {chapter.stage} · {chapter.stageLabel}
                  </span>
                  <Icon
                    name={completed ? "check" : locked ? "lock" : "file"}
                    size={19}
                  />
                </span>
                <ChapterEmblem
                  chapter={chapter.id}
                  className={styles.caseEmblem}
                />
                <h3>{chapter.title}</h3>
                <p>{adventure[chapter.id].place}</p>
                <span className={styles.caseBottom}>
                  <span>
                    {completed
                      ? "사건 해결"
                      : disabled
                        ? "앞 사건을 해결해 주세요"
                        : "수사 시작!"}
                  </span>
                  {!disabled && <Icon name="arrow" size={18} />}
                </span>
              </button>
            );
          })}
        </div>
        <div className={styles.preparationNote}>
          <Icon name="file" size={19} />
          <span>
            각 사건의 수사하기에서 미션을 해결하고, 사건 해결 단계에서 배지를
            받아요. 앞 사건을 해결하면 다음 장이 자동으로 열려요. 교사 설정은
            필요 없어요.
          </span>
        </div>
      </section>
      <section className={styles.badgeShelf} aria-label="나의 배지함">
        <div className={styles.shelfHeading}>
          <div>
            <Icon name="badge" size={28} />
            <div>
              <h2>나의 탐정 배지함</h2>
              <p>사건을 해결하면 이곳에 배지가 모여요.</p>
            </div>
          </div>
          <span>{progress?.badges.length ?? 0} / 8</span>
        </div>
        <div className={styles.badgeGrid}>
          {badgeNames.map((badge, index) => (
            <span
              key={badge}
              className={`${styles.badge} ${progress?.badges.includes(badge) ? styles.earnedBadge : ""}`}
            >
              <span className={styles.badgeMedal}>
                <Icon
                  name={progress?.badges.includes(badge) ? "badge" : "lock"}
                  size={30}
                />
              </span>
              <strong>{badge}</strong>
              <small>
                {progress?.badges.includes(badge)
                  ? "획득 완료"
                  : `${index + 1}장 해결 보상`}
              </small>
            </span>
          ))}
        </div>
      </section>
    </div>
  );
}

import { useEffect } from "react";
import { useLearning } from "../app/useLearning";
import { badgeNames, chapters, principles } from "../data/cases";
import { chapterReady, chapterTasks } from "../lib/learning";
import { Icon } from "../components/ui/Icon";
import { ChapterEmblem } from "../components/game/ChapterEmblem";
import { Chapter1 } from "../chapters/Chapter1";
import { Chapter2 } from "../chapters/Chapter2";
import { Chapter3 } from "../chapters/Chapter3";
import { Chapter4 } from "../chapters/Chapter4";
import { Chapter5 } from "../chapters/Chapter5";
import { Chapter6 } from "../chapters/Chapter6";
import { Chapter7 } from "../chapters/Chapter7";
import { Chapter8, Certificate } from "../chapters/Chapter8";
import type { ChapterId } from "../types";
import styles from "./Screens.module.css";
import s from "../components/game/Lesson.module.css";
import { ChapterFinish } from "../components/game/MissionTrail";
import { CharacterSprite } from "../components/game/CharacterSprite";
import { StoryScene } from "../components/game/StoryScene";
import { canOpenChapter } from "../lib/progression";

const steps = ["사건 소개", "수사하기", "사건 해결"];
export function ChapterScreen({
  onMap,
  onOpen,
  onAdventure,
}: {
  onMap: () => void;
  onOpen?: (id: ChapterId) => void;
  onAdventure?: () => void;
}) {
  const { state, note, patch, dispatch, id } = useLearning();
  const chapter = chapters.find((item) => item.id === state.currentChapter)!;
  const step = note.steps[chapter.id] ?? 0;
  const setStep = (next: number) => {
    patch({
      steps: { ...note.steps, [chapter.id]: Math.max(0, Math.min(2, next)) },
    });
    window.scrollTo({ top: 0, behavior: "instant" });
  };
  const tasks = chapterTasks(state, id, chapter.id);
  const ready = chapterReady(state, id, chapter.id);
  const completed = state.progress[id]?.completedChapters.includes(chapter.id);
  const next = chapter.id < 8 ? ((chapter.id + 1) as ChapterId) : undefined;
  useEffect(() => {
    if (!state.settings.projection || state.mode !== "teacher") return;
    function handleKey(event: KeyboardEvent) {
      const target = event.target as HTMLElement;
      if (
        target.closest(
          'input, select, textarea, [contenteditable="true"], [role="slider"], [data-calculation-notes]',
        ) ||
        event.altKey ||
        event.ctrlKey ||
        event.metaKey ||
        document.querySelector('[role="alertdialog"], [role="dialog"]')
      )
        return;
      if (event.key === "ArrowLeft" || event.key === "ArrowRight") {
        event.preventDefault();
        setStep(step + (event.key === "ArrowRight" ? 1 : -1));
      }
    }
    document.addEventListener("keydown", handleKey);
    return () => document.removeEventListener("keydown", handleKey);
  }, [state.settings.projection, state.mode, step, chapter.id, note.steps]);
  return (
    <section
      className={`${styles.chapterScreen} stage-${chapter.color}`}
      data-student={state.mode !== "teacher" || undefined}
    >
      {state.mode === "teacher" && (
        <button className="text-button" onClick={onMap}>
          <Icon name="grid" size={17} />
          사건 지도로 돌아가기
        </button>
      )}
      <div className={styles.chapterBanner}>
        <span className={styles.bigStage}>
          <small>MISSION</small>
          {String(chapter.id).padStart(2, "0")}
        </span>
        <div>
          <span className="eyebrow">
            사건 파일 {String(chapter.id).padStart(2, "0")} ·{" "}
            {chapter.stageLabel}
          </span>
          <h1>{chapter.title}</h1>
          <p>{chapter.subtitle}</p>
        </div>
        <ChapterEmblem chapter={chapter.id} className={styles.bannerEmblem} />
      </div>
      <nav className={styles.introSteps} aria-label="사건 진행 단계">
        {steps.map((label, index) => (
          <button
            key={label}
            onClick={() => setStep(index)}
            aria-current={step === index ? "step" : undefined}
          >
            <span>{index + 1}</span>
            {label}
          </button>
        ))}
      </nav>
      {step === 0 && (
        <>
          <StoryScene
            key={chapter.id}
            chapter={chapter.id}
            onStart={() => setStep(1)}
          />
          <div className={styles.briefing}>
            <span className="eyebrow">사건 브리핑 · 핵심 질문</span>
            <h2>{chapter.question}</h2>
            <ol className={styles.missionList}>
              {chapter.missions.map((mission, i) => (
                <li key={mission}>
                  <span>{String(i + 1).padStart(2, "0")}</span>
                  {mission}
                </li>
              ))}
            </ol>
            <div className={styles.briefingStamp}>수사 준비</div>
          </div>
        </>
      )}
      {step === 1 && (
        <ChapterFinish.Provider value={() => setStep(2)}>
          {(ready || state.mode === "teacher") && (
            <div className={styles.missionHud}>
              <span className={styles.guidePortrait} aria-hidden="true" />
              <div>
                <span className="eyebrow">
                  {ready
                    ? "미션 완료 · 배지를 받을 준비가 됐어!"
                    : "탐정단, 출동!"}
                </span>
                <h2>
                  {ready
                    ? "사건 해결 단계에서 배지를 받아요"
                    : "미션을 해결하고 단서를 모아 봐요"}
                </h2>
              </div>
              {ready && (
                <button className="btn primary" onClick={() => setStep(2)}>
                  배지 받으러 가기
                  <Icon name="badge" size={20} />
                </button>
              )}
            </div>
          )}
          {chapter.id === 1 ? (
            <Chapter1 />
          ) : chapter.id === 2 ? (
            <Chapter2 />
          ) : chapter.id === 3 ? (
            <Chapter3 />
          ) : chapter.id === 4 ? (
            <Chapter4 />
          ) : chapter.id === 5 ? (
            <Chapter5 />
          ) : chapter.id === 6 ? (
            <Chapter6 />
          ) : chapter.id === 7 ? (
            <Chapter7 />
          ) : (
            <Chapter8 />
          )}
        </ChapterFinish.Provider>
      )}
      {step === 2 && (
        <div className={s.stack}>
          {completed ? (
            <div className={s.solved}>
              <span className={s.clearBanner} aria-hidden="true">
                CASE CLEAR
              </span>
              <Icon name="badge" size={65} />
              <h2>사건 해결!</h2>
              <h3>{badgeNames[chapter.id - 1]} 배지를 받았어요</h3>
              <p>
                이 장에서 모은 단서:{" "}
                {state.scores
                  .filter(
                    (entry) =>
                      entry.participantId === id &&
                      entry.chapter === chapter.id,
                  )
                  .reduce((sum, entry) => sum + entry.delta, 0)}
                점
              </p>
              <p>{principles[chapter.id - 1]}</p>
              <span className={s.stamp}>알뜰 탐정 사무소 · 해결 확인</span>
            </div>
          ) : (
            <section className={s.card}>
              <h2>사건 해결 기록을 남겨요</h2>
              <p>
                {ready
                  ? "미션을 모두 확인했어요. 배지와 사건 해결 단서 20점을 받아요."
                  : "아래에 남은 필수 활동이 보여요. 활동 버튼을 누르면 이어서 할 곳으로 바로 이동해요. 선택 미션은 하지 않아도 돼요."}
              </p>
              <ul className={s.taskList}>
                {tasks.map((task, index) => (
                  <li key={task.label}>
                    {task.done ? (
                      <span>✓ 완료 · {task.label}</span>
                    ) : (
                      <button
                        className="btn secondary"
                        onClick={() => {
                          const fractionIndex =
                            chapter.id === 2 && index > 0
                              ? index - 1
                              : note.fractionIndex;
                          // 음료 금고가 먼저 열려야 다른 상품을 계산할 수 있어요.
                          const selectedCase =
                            task.caseId &&
                            (task.caseId === "drink" ||
                              note.calculations.drink?.stage === 4)
                              ? task.caseId
                              : note.selectedCase;
                          patch({
                            steps: { ...note.steps, [chapter.id]: 1 },
                            missionPages: {
                              ...note.missionPages,
                              [chapter.id]: task.mission,
                            },
                            selectedCase,
                            fractionIndex,
                          });
                          window.scrollTo({ top: 0, behavior: "instant" });
                        }}
                      >
                        미완료 · {task.label} <Icon name="arrow" size={18} />
                      </button>
                    )}
                  </li>
                ))}
              </ul>
              <button
                className="btn primary"
                disabled={!ready}
                onClick={() =>
                  dispatch({
                    type: "complete",
                    participantId: id,
                    chapter: chapter.id,
                  })
                }
              >
                사건 해결하고 배지 받기
              </button>
            </section>
          )}
          {next && (
            <button
              className="btn primary"
              disabled={!canOpenChapter(state, next)}
              onClick={() => onOpen?.(next)}
            >
              다음 사건 · {next}장<Icon name="arrow" size={18} />
            </button>
          )}
        </div>
      )}
      {step === 2 && completed && <StoryScene chapter={chapter.id} ending />}
      {step === 2 && chapter.id === 8 && completed && (
        <>
          <Certificate />
          <section className={s.adventureLaunch} aria-label="마지막 모험 출발">
            <div aria-hidden="true">
              <CharacterSprite who="fox" />
              <CharacterSprite who="raccoon" />
            </div>
            <div>
              <span className="eyebrow">여덟 사건을 마친 탐정에게 온 초대</span>
              <h2>반짝시장 대모험</h2>
              <p>
                새로운 시장으로 출발해 친구들의 의뢰를 풀고, 사라진 축제
                초대장을 찾아요.
              </p>
              <button className="btn primary" onClick={onAdventure}>
                마지막 모험 시작하기 <Icon name="arrow" size={18} />
              </button>
            </div>
          </section>
        </>
      )}
      {(step === 0 || (step === 1 && state.mode === "teacher")) && (
        <div className={styles.introPager}>
          <button
            className="btn secondary"
            disabled={step === 0}
            onClick={() => setStep(step - 1)}
          >
            이전 단계
          </button>
          <span>
            {step + 1} / {steps.length}
          </span>
          <button className="btn primary" onClick={() => setStep(step + 1)}>
            {step === 0 ? "수사하기로 이동" : "사건 해결로 이동"}
            <Icon name="arrow" size={18} />
          </button>
        </div>
      )}
      {state.mode === "teacher" && state.settings.projection && (
        <p className={styles.keyboardHelp}>
          키보드 ← →로 장 안의 단계를 넘길 수 있어요.
        </p>
      )}
    </section>
  );
}

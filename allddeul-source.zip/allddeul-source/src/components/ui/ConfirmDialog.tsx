import { useEffect, useId, useRef } from "react";
import { createPortal } from "react-dom";
import { Icon } from "./Icon";

export function ConfirmDialog({
  onCancel,
  onConfirm,
}: {
  onCancel: () => void;
  onConfirm: () => void;
}) {
  const titleId = useId();
  const descriptionId = useId();
  const dialogRef = useRef<HTMLDivElement>(null);
  const cancelRef = useRef<HTMLButtonElement>(null);
  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null;
    const overflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    cancelRef.current?.focus();
    function handleKey(event: KeyboardEvent) {
      if (event.key === "Escape") {
        event.preventDefault();
        onCancel();
      }
      if (event.key !== "Tab") return;
      const buttons = dialogRef.current?.querySelectorAll<HTMLButtonElement>(
        "button:not(:disabled)",
      );
      if (!buttons?.length) return;
      const first = buttons[0];
      const last = buttons[buttons.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    }
    document.addEventListener("keydown", handleKey);
    return () => {
      document.body.style.overflow = overflow;
      document.removeEventListener("keydown", handleKey);
      previous?.focus();
    };
  }, [onCancel]);

  return createPortal(
    <div
      className="dialog-backdrop"
      onMouseDown={(event) => {
        if (event.target === event.currentTarget) onCancel();
      }}
    >
      <div
        role="alertdialog"
        aria-modal="true"
        aria-labelledby={titleId}
        aria-describedby={descriptionId}
        className="dialog"
        ref={dialogRef}
      >
        <span className="dialog-symbol">
          <Icon name="reset" size={28} />
        </span>
        <h2 id={titleId}>탐정 수첩을 새로 펼칠까요?</h2>
        <p id={descriptionId}>
          이 브라우저에 저장한 모둠 이름, 점수, 배지, 진행 기록과 교사 설정을
          모두 지워요. 지운 기록은 되돌릴 수 없어요.
        </p>
        <div className="dialog-actions">
          <button className="btn secondary" ref={cancelRef} onClick={onCancel}>
            기록 남겨 두기
          </button>
          <button className="btn danger" onClick={onConfirm}>
            모든 기록 지우기
          </button>
        </div>
      </div>
    </div>,
    document.body,
  );
}

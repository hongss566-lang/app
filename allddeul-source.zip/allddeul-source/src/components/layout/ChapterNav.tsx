import { chapters } from "../../data/cases";
import { useApp } from "../../app/AppProvider";
import type { ChapterId } from "../../types";
import { Icon } from "../ui/Icon";
import styles from "../../app/App.module.css";
import { actorId } from "../../lib/learning";
import { canOpenChapter } from "../../lib/progression";

export function ChapterNav({
  active,
  onOpen,
}: {
  active?: ChapterId;
  onOpen: (id: ChapterId) => void;
}) {
  const { state } = useApp();
  return (
    <nav className={styles.chapterNav} aria-label="사건 파일 1장부터 8장">
      {chapters.map((chapter) => {
        const locked = !canOpenChapter(state, chapter.id);
        const done = state.progress[actorId(state)]?.completedChapters.includes(
          chapter.id,
        );
        return (
          <button
            key={chapter.id}
            className={`${styles.navChapter} stage-${chapter.color}`}
            disabled={locked}
            aria-current={active === chapter.id ? "step" : undefined}
            aria-label={`${chapter.id}장 ${chapter.title}${locked ? " · 잠김" : ""}`}
            onClick={() => onOpen(chapter.id)}
          >
            <span className={styles.navNumber}>
              {locked ? (
                <Icon name="lock" size={14} />
              ) : done ? (
                <Icon name="check" size={14} />
              ) : (
                chapter.id
              )}
            </span>
            <span>{chapter.stage}</span>
            <span className={styles.navStage}>{chapter.stageLabel}</span>
          </button>
        );
      })}
    </nav>
  );
}

import { useState } from "react";
import { useLearning } from "../../app/useLearning";
import { briefingQuestions } from "../../lib/briefing";
import { characters } from "../../data/adventure";
import { CharacterDialogue } from "./StoryScene";
import { Products } from "./Shared";
import { Icon } from "../ui/Icon";
import s from "./Lesson.module.css";
import story from "./Story.module.css";

export function CharacterJury() {
  const { note, patch, reward } = useLearning();
  const [feedback, setFeedback] = useState("");
  if (!note.reportSaved || !note.report)
    return (
      <p className={s.notice}>
        먼저 ‘증거 보고서’ 미션에서 보고서를 봉인해 줘. 그러면 탐정단 친구들이
        네 상품에 맞는 질문을 할 거야!
      </p>
    );
  const questions = briefingQuestions(note.report.pair);
  const unanswered = questions.find(
    (question) => note.briefingAnswers?.[question.id] !== question.correct,
  );
  return (
    <div className={story.jury}>
      <Products pair={note.report.pair} />
      <div className={s.grid}>
        <p className={s.notice}>{note.report.evidenceA}</p>
        <p className={s.notice}>{note.report.evidenceB}</p>
      </div>
      <div className={story.juryProgress} aria-label="탐정단 질문 통과 현황">
        {questions.map((question) => (
          <span
            key={question.id}
            data-done={note.briefingAnswers?.[question.id] === question.correct}
          >
            <Icon
              name={
                note.briefingAnswers?.[question.id] === question.correct
                  ? "check"
                  : "search"
              }
              size={15}
            />
            {characters[question.who].name}의 질문
          </span>
        ))}
      </div>
      {unanswered ? (
        <>
          <CharacterDialogue
            line={{ who: unanswered.who, text: unanswered.question }}
          />
          <div
            className={s.choices}
            role="group"
            aria-label="탐정단 질문에 답하기"
          >
            {unanswered.options.map((option) => (
              <button
                key={option.id}
                onClick={() => {
                  if (option.id === unanswered.correct) {
                    patch({
                      briefingAnswers: {
                        ...note.briefingAnswers,
                        [unanswered.id]: option.id,
                      },
                    });
                    reward(`c7-jury-${unanswered.id}`, 5, 7);
                    setFeedback(
                      `${characters[unanswered.who].name}: 맞았어! ${unanswered.explanation}`,
                    );
                  } else
                    setFeedback(
                      `${characters[unanswered.who].name}: 다시 생각해 보자. ${unanswered.id === "decision" ? "보고서의 상품 가격을 양(L)으로 나누어 비교해 봐." : unanswered.explanation}`,
                    );
                }}
              >
                {option.label}
              </button>
            ))}
          </div>
        </>
      ) : (
        <div className={s.success}>
          <CharacterDialogue
            line={{
              who: "fox",
              text: "세 질문 모두 통과! 네 계산과 선택의 이유가 잘 전해졌어. ‘사건 해결’에서 일곱 번째 배지를 받아 줘!",
            }}
          />
        </div>
      )}
      <p role="status">{feedback}</p>
    </div>
  );
}

import { useId } from "react";
export function MarketScenery() {
  const uid = useId().replace(/:/g, "");
  const Shop = ({
    x,
    y,
    color,
    title,
  }: {
    x: number;
    y: number;
    color: string;
    title: string;
  }) => (
    <g transform={`translate(${x} ${y})`}>
      <ellipse cx="0" cy="108" rx="88" ry="13" fill="#24473420" />
      <rect
        x="-65"
        y="13"
        width="130"
        height="87"
        rx="9"
        fill="#f5dcb0"
        stroke="#65543a"
        strokeWidth="3"
      />
      <path
        d="M-77 16L-61 -18H60L78 16Z"
        fill={color}
        stroke="#65543a"
        strokeWidth="3"
      />
      <path
        d="M-74 18V36Q-60 47 -48 36Q-35 47 -22 36Q-9 47 4 36Q17 47 30 36Q43 47 56 36Q68 47 76 36V18Z"
        fill="#fff0c9"
        stroke="#65543a"
        strokeWidth="2"
      />
      <path
        d="M-60 17V36M-34 17V36M-8 17V36M18 17V36M44 17V36M69 17V36"
        stroke={color}
        strokeWidth="11"
      />
      <rect
        x="-52"
        y="50"
        width="38"
        height="31"
        rx="5"
        fill="#aecfd0"
        stroke="#65543a"
        strokeWidth="2"
      />
      <path d="M-33 50V81M-52 66H-14" stroke="#fff9e2" strokeWidth="3" />
      <rect
        x="10"
        y="46"
        width="42"
        height="54"
        rx="8"
        fill="#b78955"
        stroke="#65543a"
        strokeWidth="2"
      />
      <rect
        x="-66"
        y="-31"
        width="133"
        height="25"
        rx="9"
        fill="#fff4d6"
        stroke="#65543a"
        strokeWidth="2"
      />
      <text
        x="0"
        y="-13"
        textAnchor="middle"
        fill="#3b5146"
        fontSize="15"
        fontWeight="bold"
      >
        {title}
      </text>
      <circle cx="43" cy="76" r="3" fill="#f4ce71" />
    </g>
  );
  return (
    <svg
      viewBox="0 0 900 700"
      preserveAspectRatio="xMidYMid meet"
      aria-hidden="true"
    >
      <defs>
        <pattern
          id={`${uid}grass`}
          width="50"
          height="50"
          patternUnits="userSpaceOnUse"
        >
          <rect width="50" height="50" fill="#b7d59c" />
          <path
            d="M8 25L10 19L13 25M32 44L35 38L37 44"
            fill="none"
            stroke="#92b97d"
            strokeWidth="2"
          />
          <circle cx="40" cy="10" r="2" fill="#dcebba" />
        </pattern>
        <linearGradient id={`${uid}road`} x2="1" y2="1">
          <stop stopColor="#ffedc4" />
          <stop offset="1" stopColor="#e9cd96" />
        </linearGradient>
      </defs>
      <rect width="900" height="700" rx="35" fill={`url(#${uid}grass)`} />
      <path
        d="M450 150V550"
        stroke="#9e9e6a"
        strokeWidth="290"
        strokeLinecap="round"
        fill="none"
      />
      <path
        d="M450 150V550"
        stroke={`url(#${uid}road)`}
        strokeWidth="280"
        strokeLinecap="round"
        fill="none"
      />
      <path
        d="M150 150H750M150 350H750M150 550H750"
        stroke="#9e9e6a"
        strokeWidth="89"
        strokeLinecap="round"
        fill="none"
      />
      <path
        d="M150 150H750M150 350H750M150 550H750"
        stroke={`url(#${uid}road)`}
        strokeWidth="80"
        strokeLinecap="round"
        fill="none"
      />
      <path
        d="M350 550H550"
        stroke="#fff3ce"
        strokeWidth="8"
        strokeDasharray="4 14"
        strokeLinecap="round"
      />
      <path d="M450 540V505" stroke="#ad9369" strokeWidth="3" />
      <text
        x="450"
        y="588"
        textAnchor="middle"
        fill="#675b3c"
        fontSize="19"
        fontWeight="bold"
      >
        출발 광장
      </text>
      <g transform="translate(450 95)">
        <ellipse cx="0" cy="67" rx="75" ry="15" fill="#31593d20" />
        <rect
          x="-66"
          y="-43"
          width="20"
          height="115"
          rx="6"
          fill="#9d764a"
          stroke="#65543a"
          strokeWidth="3"
        />
        <rect
          x="46"
          y="-43"
          width="20"
          height="115"
          rx="6"
          fill="#9d764a"
          stroke="#65543a"
          strokeWidth="3"
        />
        <path
          d="M-85 -35Q0 -89 85 -35L70 -10Q0 -47 -70 -10Z"
          fill="#e5b957"
          stroke="#65543a"
          strokeWidth="3"
        />
        <text
          x="0"
          y="-29"
          textAnchor="middle"
          fill="#344c37"
          fontSize="22"
          fontWeight="bold"
        >
          반짝 축제
        </text>
        <path
          d="M-46 -6L-22 8L0 -12L23 8L46 -6"
          fill="none"
          stroke="#b76c4c"
          strokeWidth="4"
        />
        <path
          d="M-46 -2L-29 2L-41 14M-18 -1L0 -9L-3 10M9 -5L24 7L10 12M31 4L46 -2L42 15"
          fill="#d88059"
        />
      </g>
      <Shop x={150} y={48} color="#598c91" title="모아의 분수 샘터" />
      <Shop x={750} y={48} color="#8c9e65" title="올리의 단위 가게" />
      <Shop x={150} y={248} color="#cc805a" title="루미의 주스 가게" />
      <Shop x={750} y={248} color="#c4a557" title="두리의 장바구니" />
      <g transform="translate(250 450)">
        <ellipse cy="16" rx="51" ry="30" fill="#8d9d7b" />
        <ellipse
          cy="8"
          rx="47"
          ry="27"
          fill="#e9e2c0"
          stroke="#6d8f89"
          strokeWidth="3"
        />
        <ellipse cy="4" rx="36" ry="18" fill="#91c8cf" />
        <path
          d="M0 2V-34M-24 -8Q-9 -49 0 -23Q11 -49 25 -8"
          fill="none"
          stroke="#d5f1e8"
          strokeWidth="5"
          strokeLinecap="round"
        />
        <circle cy="-37" r="7" fill="#c0e9df" />
      </g>
      <g transform="translate(650 450)">
        <ellipse cy="19" rx="51" ry="26" fill="#85a966" />
        <path
          d="M-42 3H43M-38 -9H39"
          stroke="#a67c4b"
          strokeWidth="10"
          strokeLinecap="round"
        />
        <path d="M-29 6V26M29 6V26" stroke="#5f6748" strokeWidth="6" />
      </g>
      {[...Array(9)].map((_, i) => (
        <g key={`t${i}`} transform={`translate(${50 + i * 100} 652)`}>
          <ellipse cy="15" rx="33" ry="10" fill="#3e623f22" />
          <path d="M0 -30V15" stroke="#856947" strokeWidth="9" />
          <circle cy="-31" r="32" fill={i % 2 ? "#6d9e65" : "#578a61"} />
          <circle cx="-9" cy="-40" r="17" fill="#91b87a" />
        </g>
      ))}
      {[50, 850].flatMap((x) =>
        [120, 230, 430, 540].map((y) => (
          <g key={`${x},${y}`} transform={`translate(${x} ${y})`}>
            <ellipse cy="16" rx="25" ry="7" fill="#48694420" />
            <rect x="-4" y="-14" width="8" height="35" fill="#997449" />
            <circle cy="-20" r="26" fill="#6b9f68" />
            <circle cx="-8" cy="-29" r="16" fill="#9fbe7a" />
          </g>
        )),
      )}
      {[250, 650].map((x) => (
        <g key={x} transform={`translate(${x} 250)`}>
          <circle r="35" fill="#7ba368" />
          <circle cx="-9" cy="-12" r="21" fill="#a9c789" />
          <circle cx="12" cy="5" r="17" fill="#92b777" />
        </g>
      ))}
      {[100, 200, 600, 700].map((x, i) => (
        <g key={x} transform={`translate(${x} ${i % 2 ? 470 : 610})`}>
          <circle r="5" fill="#e5a269" />
          <circle cx="-6" r="5" fill="#f7d78c" />
          <circle cy="-6" r="5" fill="#fff6b9" />
          <path d="M0 6V18" stroke="#4c9056" strokeWidth="3" />
        </g>
      ))}
    </svg>
  );
}

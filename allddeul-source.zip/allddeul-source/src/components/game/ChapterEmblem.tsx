import { useId } from "react";
import type { ChapterId } from "../../types";

// 장마다 다른 수사 도구. 숫자·계산식은 실제 활동 화면에서만 표시한다.
export function ChapterEmblem({
  chapter,
  className,
}: {
  chapter: ChapterId;
  className?: string;
}) {
  const id = useId().replace(/:/g, "");
  return (
    <svg viewBox="0 0 180 150" className={className} aria-hidden="true">
      <defs>
        <linearGradient id={`${id}-gold`} x2="0.3" y2="1">
          <stop stopColor="#ffe58c" />
          <stop offset="1" stopColor="#e9a637" />
        </linearGradient>
        <linearGradient id={`${id}-blue`} x2="0.4" y2="1">
          <stop stopColor="#79e7e2" />
          <stop offset="1" stopColor="#21999f" />
        </linearGradient>
        <linearGradient id={`${id}-paper`} x2="0.2" y2="1">
          <stop stopColor="#fffef3" />
          <stop offset="1" stopColor="#f0d8a5" />
        </linearGradient>
      </defs>
      <ellipse cx="90" cy="130" rx="62" ry="9" fill="#163d4320" />
      <g
        stroke="#214957"
        strokeWidth="3.5"
        strokeLinejoin="round"
        strokeLinecap="round"
      >
        {chapter === 1 && (
          <>
            <path
              d="M35 50h28v12l11 14v46H25V76l10-14Z"
              fill={`url(#${id}-blue)`}
            />
            <rect x="33" y="42" width="33" height="13" rx="4" fill="#315774" />
            <rect x="28" y="86" width="43" height="24" rx="3" fill="#fff8db" />
            <path
              d="m100 57 42-7 18 23-31 39-34-29Z"
              fill={`url(#${id}-gold)`}
            />
            <circle cx="111" cy="69" r="4" fill="#fff" />
            <path d="m114 61-1-24-30 1" fill="none" />
            <path d="m117 80 13 10m-18-3 13 10" stroke="#9c6a25" />
            <circle
              cx="75"
              cy="45"
              r="22"
              fill="#d8ffff99"
              stroke="#e1a738"
              strokeWidth="8"
            />
            <path d="m60 61-18 19" stroke="#315774" strokeWidth="12" />
            <path d="m68 36 6-4" stroke="#fff" />
          </>
        )}
        {chapter === 2 && (
          <>
            <path d="m27 49 9 77h57l9-77" fill="#d9f9fa" />
            <path
              d="m32 78 6 45h52l6-45Z"
              fill={`url(#${id}-blue)`}
              stroke="none"
            />
            <path
              d="M100 64h19c17 0 17 28-3 28h-13"
              fill="none"
              strokeWidth="7"
            />
            <path d="M29 49h71M44 62v45" stroke="#fff" />
            <path d="m124 37 6 16m7-21 7 16" stroke="#3aa9b0" />
            <path d="m117 105 5 23h30l4-23Z" fill={`url(#${id}-gold)`} />
            <path
              d="m57 20 5 9 10 2-8 7 1 10-9-5-9 4 2-10-7-7 10-1Z"
              fill="#ffd65e"
              stroke="none"
            />
          </>
        )}
        {chapter === 3 && (
          <>
            <path d="M42 49h65v77H42Z" fill={`url(#${id}-paper)`} />
            <path d="m42 49 15-22h36l14 22Z" fill="#50bdb8" />
            <path d="M74 49v77M57 27l17 22 19-22" fill="none" />
            <path d="M48 72h19v30H48" fill="#afe4d4" stroke="none" />
            <rect
              x="104"
              y="65"
              width="48"
              height="65"
              rx="8"
              fill="#315774"
              transform="rotate(8 128 97)"
            />
            <path d="m115 78 24 3-1 13-24-3Z" fill="#c4efd7" />
            <path
              d="m114 103 3 1m10 0 3 1m10 0 3 1m-31 8 3 1m10 0 3 1m10 0 3 1"
              stroke="#ffdd6b"
              strokeWidth="5"
            />
          </>
        )}
        {chapter === 4 && (
          <>
            <path d="M29 32h118v96H29Z" fill="#367d9b" />
            <path
              d="M45 48h22v19H45Zm53 0h27v19H98ZM70 91h29v21H70Z"
              fill="#bde9e8"
            />
            <path d="M68 57h28M112 68v16H86v7" fill="none" stroke="#fff5c9" />
            <path
              d="m131 26 13 6-42 79-17 11 1-20Z"
              fill={`url(#${id}-gold)`}
            />
            <path d="m85 122 4-17 11 6" fill="#fff8dd" />
            <path
              d="M28 24v113m-7-104h14m-14 15h9m-9 15h14m-14 15h9m-9 15h14m-14 15h9m-9 15h14"
              stroke="#f1c467"
            />
          </>
        )}
        {chapter === 5 && (
          <>
            <rect
              x="40"
              y="45"
              width="99"
              height="83"
              rx="15"
              fill={`url(#${id}-blue)`}
            />
            <rect x="50" y="58" width="79" height="33" rx="6" fill="#1e4a58" />
            <path d="M63 73v8m16-8v8" stroke="#c5f5d3" strokeWidth="8" />
            <path d="m99 74 6 6 12-14" fill="none" stroke="#ffe269" />
            <circle cx="67" cy="108" r="6" fill="#fff5d4" />
            <circle cx="91" cy="108" r="6" fill="#fff5d4" />
            <path
              d="M108 108h14M89 45V31m-61 39H17v33h23m99-33h20v33h-20"
              fill="none"
              strokeWidth="6"
            />
            <circle cx="89" cy="24" r="9" fill={`url(#${id}-gold)`} />
          </>
        )}
        {chapter === 6 && (
          <>
            <path d="m102 89 36 37" stroke="#315774" strokeWidth="18" />
            <circle
              cx="77"
              cy="64"
              r="45"
              fill="#c7eeee"
              stroke="#edb74f"
              strokeWidth="10"
            />
            <ellipse cx="77" cy="70" rx="18" ry="23" fill="#ed8258" />
            <path
              d="M77 50v41m-26-35 9 6m-11 9h9m-7 14 9-6m34-23-9 6m11 9h-9m7 14-9-6M67 46l-5-8m25 8 5-8"
              fill="none"
            />
            <path d="M48 44q7-12 17-12" stroke="#fff" strokeWidth="7" />
            <circle cx="71" cy="55" r="2" fill="#214957" stroke="none" />
            <circle cx="82" cy="55" r="2" fill="#214957" stroke="none" />
          </>
        )}
        {chapter === 7 && (
          <>
            <rect
              x="33"
              y="25"
              width="82"
              height="87"
              rx="7"
              fill={`url(#${id}-paper)`}
            />
            <rect x="56" y="19" width="37" height="14" rx="5" fill="#f1b64a" />
            <path
              d="M48 50h48M48 63h35M48 78h13v20H48m22-30h13v30H70m22-16h12v16H92"
              fill="#76c7be"
            />
            <path
              d="m120 57 27-14v56l-27-13h-14V57Z"
              fill={`url(#${id}-gold)`}
            />
            <path
              d="m118 88 5 22h13l-10-22m25-32 10-8m-8 27h10m-12 14 10 8"
              fill="none"
            />
            <path d="M58 126h53" strokeWidth="7" />
          </>
        )}
        {chapter === 8 && (
          <>
            <path d="m47 65 10 64h73l11-64Z" fill={`url(#${id}-gold)`} />
            <path
              d="m65 67 13-32m44 32-13-32M67 83l5 30m20-30v30m20-30-4 30"
              fill="none"
              stroke="#a97029"
              strokeWidth="6"
            />
            <path
              d="M93 62C61 34 91 13 115 17c5 29-2 44-22 45Z"
              fill="#57b484"
            />
            <path d="m93 62 14-32" fill="none" />
            <circle
              cx="137"
              cy="105"
              r="23"
              fill="#258d8b"
              stroke="#ffe88e"
              strokeWidth="5"
            />
            <path
              d="m128 105 7 7 12-15"
              stroke="#fff4c0"
              fill="none"
              strokeWidth="5"
            />
          </>
        )}
        <path
          d="m150 26 2-8 3 8 8 3-8 3-3 8-2-8-8-3Z"
          fill="#ffdc70"
          stroke="none"
        />
      </g>
    </svg>
  );
}

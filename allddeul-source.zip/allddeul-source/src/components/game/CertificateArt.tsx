import { badgeNames } from "../../data/cases";
import { Icon, type IconName } from "../ui/Icon";
import { CharacterSprite } from "./CharacterSprite";
import s from "./CertificateArt.module.css";
const emblems: IconName[] = [
  "search",
  "grid",
  "leaf",
  "file",
  "star",
  "eye",
  "screen",
  "badge",
];
export function CertificateArt({
  name,
  score,
  rank,
  pledge,
}: {
  name: string;
  score: number;
  rank: string;
  pledge: string;
}) {
  return (
    <article className={s.certificate} aria-label="탐정 사무소 정식 수료증">
      <div className={s.cornerA} aria-hidden="true">
        ✦
      </div>
      <div className={s.cornerB} aria-hidden="true">
        ✦
      </div>
      <div className={s.emblem}>
        <Icon name="search" size={42} />
        <span>반짝마을 탐정 사무소</span>
      </div>
      <p className={s.serial}>여덟 사건의 증거를 모은 탐정에게</p>
      <h2>수석 탐정 수료증</h2>
      <span className={s.ribbon}>ALDDEUL DETECTIVE ACADEMY</span>
      <h3>{name}</h3>
      <p className={s.body}>
        위 탐정은 여덟 사건을 끝까지 탐구하고
        <br />
        계산과 증거로 합리적인 선택을 하는 힘을 길렀기에
        <br />
        알뜰 소비 탐정단의 수료증을 드립니다.
      </p>
      <div className={s.badges}>
        {badgeNames.map((name, i) => (
          <div
            key={name}
            className={s.badge}
            style={{ "--badge-hue": `${i * 32 + 25}` } as React.CSSProperties}
          >
            <span>
              <Icon name={emblems[i]} size={27} />
            </span>
            <strong>{name}</strong>
          </div>
        ))}
      </div>
      <p className={s.total}>
        총 단서 <strong>{score.toLocaleString("ko-KR")}점</strong> · {rank}
      </p>
      <blockquote>
        <span>나의 소비 약속</span>
        {pledge}
      </blockquote>
      <div className={s.sign}>
        <span>
          알뜰 탐정 사무소장 <strong>올리</strong>
        </span>
        <div className={s.seal}>
          <Icon name="check" size={30} />
          <span>수료 확인</span>
        </div>
      </div>
      <div className={s.friends} aria-hidden="true">
        <CharacterSprite who="fox" />
        <CharacterSprite who="raccoon" />
        <span>여덟 사건 해결을 축하해!</span>
        <CharacterSprite who="bear" />
        <CharacterSprite who="owl" />
      </div>
    </article>
  );
}

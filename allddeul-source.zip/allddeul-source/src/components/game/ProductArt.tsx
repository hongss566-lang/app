import { useId } from "react";
import type { Product } from "../../types";

/** 수업용 가상 패키지. 수치·색은 상품 정보와 소비 비율에서 읽는다. */
export function ProductArt({
  product,
  label = "A",
  consumed,
}: {
  product: Product;
  label?: "A" | "B";
  consumed?: number;
}) {
  const id = useId().replace(/:/g, "");
  const milk = product.name.includes("우유");
  const carton = milk && (product.unit === "mL" || Number(product.amount) <= 1);
  const accent = label === "A" ? "#24786c" : "#a54e39";
  const ratio =
    consumed === undefined ? undefined : Math.max(0, Math.min(1, consumed));
  return (
    <svg
      viewBox="0 0 180 230"
      role="img"
      aria-label={`${product.name} ${product.amount}${product.unit} 가상 포장 그림`}
    >
      <defs>
        <linearGradient id={`${id}body`}>
          <stop stopColor="#fffdf0" />
          <stop offset=".7" stopColor="#f7efd7" />
          <stop offset="1" stopColor="#d8d1bb" />
        </linearGradient>
        <pattern
          id={`${id}waste`}
          width="9"
          height="9"
          patternUnits="userSpaceOnUse"
          patternTransform="rotate(40)"
        >
          <rect width="9" height="9" fill="#ffddd1" />
          <path d="M0 0V9" stroke="#bd6347" strokeWidth="3" />
        </pattern>
        <clipPath id={`${id}clip`}>
          <rect x="45" y="71" width="90" height="122" rx="12" />
        </clipPath>
      </defs>
      <ellipse cx="92" cy="214" rx="63" ry="10" fill="#173a3320" />
      {carton ? (
        <>
          <path
            d="M37 67L65 24H118L145 66V199Q145 208 135 208H46Q37 208 37 199Z"
            fill={`url(#${id}body)`}
            stroke="#315957"
            strokeWidth="3"
          />
          <path
            d="M65 24H118L103 65H37Z"
            fill="#d7e8e0"
            stroke="#315957"
            strokeWidth="3"
          />
          <path
            d="M118 24L145 66V199Q145 208 135 208H117V65L103 65Z"
            fill="#a6c8bb"
          />
          <path
            d="M65 24V14H118V24"
            fill="#f9efd9"
            stroke="#315957"
            strokeWidth="3"
          />
          <path d="M40 75H116V116H40Z" fill={accent} />
          <text
            x="78"
            y="100"
            textAnchor="middle"
            fill="#fff"
            fontSize="17"
            fontWeight="bold"
          >
            반짝우유
          </text>
          <ellipse
            cx="79"
            cy="146"
            rx="25"
            ry="22"
            fill="#fff"
            stroke="#315957"
            strokeWidth="2"
          />
          <path
            d="M61 130L53 121L51 137M96 130L106 121L109 136"
            fill="#315957"
          />
          <circle cx="70" cy="143" r="3" fill="#315957" />
          <circle cx="88" cy="143" r="3" fill="#315957" />
          <ellipse cx="79" cy="155" rx="13" ry="8" fill="#edba9c" />
          <text
            x="78"
            y="191"
            textAnchor="middle"
            fill="#264c47"
            fontSize="14"
            fontWeight="bold"
          >
            {product.amount}
            {product.unit}
          </text>
        </>
      ) : (
        <>
          <path
            d="M67 25H113V52L130 64Q141 74 141 91V193Q141 208 126 208H54Q39 208 39 193V91Q39 74 50 64L67 52Z"
            fill={`url(#${id}body)`}
            stroke="#315957"
            strokeWidth="3"
          />
          <rect
            x="64"
            y="12"
            width="52"
            height="22"
            rx="5"
            fill={accent}
            stroke="#244c44"
            strokeWidth="3"
          />
          <path
            d="M74 17V29M84 17V29M96 17V29M106 17V29"
            stroke="#ffffff70"
            strokeWidth="2"
          />
          {ratio === undefined && (
            <>
              <rect
                x="43"
                y="103"
                width="94"
                height="78"
                rx="4"
                fill={accent}
              />
              <circle cx="90" cy="127" r="15" fill="#f7cf67" />
              <path
                d="M86 112Q91 100 102 105"
                fill="none"
                stroke="#d1e4ab"
                strokeWidth="4"
              />
              <text
                x="90"
                y="158"
                textAnchor="middle"
                fill="#fff"
                fontWeight="bold"
                fontSize="15"
              >
                {milk ? "반짝목장" : "반짝마을"}
              </text>
              <text
                x="90"
                y="196"
                textAnchor="middle"
                fill="#264c47"
                fontWeight="bold"
                fontSize="14"
              >
                {product.amount}
                {product.unit}
              </text>
            </>
          )}
          <path
            d="M51 86V99M51 190V198"
            stroke="#fff"
            strokeWidth="5"
            strokeLinecap="round"
          />
        </>
      )}
      {ratio !== undefined && (
        <g clipPath={`url(#${id}clip)`}>
          <rect
            x="45"
            y="71"
            width="90"
            height="122"
            fill={`url(#${id}waste)`}
          />
          <rect
            x="45"
            y={71 + (1 - ratio) * 122}
            width="90"
            height={ratio * 122}
            fill="#83c8e2"
            fillOpacity="1"
          />
          <path
            d={`M45 ${71 + (1 - ratio) * 122}Q65 ${63 + (1 - ratio) * 122} 90 ${71 + (1 - ratio) * 122}T135 ${71 + (1 - ratio) * 122}`}
            fill="none"
            stroke="#276a82"
            strokeWidth="3"
          />
          <text
            x="90"
            y="178"
            textAnchor="middle"
            fill="#173f53"
            fontWeight="bold"
            fontSize="16"
          >
            마신 양
          </text>
        </g>
      )}
    </svg>
  );
}

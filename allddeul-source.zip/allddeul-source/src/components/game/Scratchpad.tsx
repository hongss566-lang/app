import { useEffect, useRef, useState, type PointerEvent } from "react";
import { useLearning } from "../../app/useLearning";
import type { InkStroke } from "../../types";
import s from "./Scratchpad.module.css";

export function Scratchpad({ embedded = false }: { embedded?: boolean }) {
  const { note, patch, state, id } = useLearning();
  const chapter = state.currentChapter;
  const [open, setOpen] = useState(false);
  const [tool, setTool] = useState<"pen" | "eraser">("pen");
  const [color, setColor] = useState("#253f49");
  const [redo, setRedo] = useState<InkStroke[]>([]);
  const cleared = useRef<InkStroke[] | null>(null);
  const canvas = useRef<HTMLCanvasElement>(null);
  const active = useRef<InkStroke | null>(null);
  const current = useRef(note.scratch?.[chapter] ?? { strokes: [], text: "" });
  current.current = note.scratch?.[chapter] ?? { strokes: [], text: "" };
  const page = current.current;
  const save = (strokes: InkStroke[], text = current.current.text) =>
    patch({ scratch: { ...note.scratch, [chapter]: { strokes, text } } });
  const draw = () => {
    const el = canvas.current,
      context = el?.getContext("2d");
    if (!el || !context) return;
    const w = el.clientWidth,
      h = el.clientHeight,
      dpr = window.devicePixelRatio || 1;
    if (el.width !== Math.round(w * dpr) || el.height !== Math.round(h * dpr)) {
      el.width = Math.round(w * dpr);
      el.height = Math.round(h * dpr);
    }
    context.setTransform(dpr, 0, 0, dpr, 0, 0);
    context.clearRect(0, 0, w, h);
    for (const stroke of [
      ...current.current.strokes,
      ...(active.current ? [active.current] : []),
    ]) {
      context.globalCompositeOperation = stroke.erase
        ? "destination-out"
        : "source-over";
      context.strokeStyle = stroke.color;
      context.fillStyle = stroke.color;
      context.lineWidth = stroke.width * w;
      context.lineCap = "round";
      context.lineJoin = "round";
      context.beginPath();
      stroke.points.forEach(([x, y], i) =>
        i ? context.lineTo(x * w, y * h) : context.moveTo(x * w, y * h),
      );
      if (stroke.points.length === 1) {
        const [x, y] = stroke.points[0];
        context.arc(x * w, y * h, (stroke.width * w) / 2, 0, Math.PI * 2);
        context.fill();
      } else context.stroke();
    }
    context.globalCompositeOperation = "source-over";
  };
  useEffect(() => {
    if (!open) return;
    const observer = new ResizeObserver(draw);
    if (canvas.current) observer.observe(canvas.current);
    draw();
    return () => observer.disconnect();
  }, [open]);
  useEffect(draw, [page]);
  useEffect(() => {
    if (embedded) return;
    document.body.dataset.noteOpen = String(open);
    return () => {
      delete document.body.dataset.noteOpen;
    };
  }, [open, embedded]);
  useEffect(() => {
    setRedo([]);
    cleared.current = null;
    active.current = null;
  }, [id, chapter]);
  const point = (event: PointerEvent<HTMLCanvasElement>): [number, number] => {
    const rect = event.currentTarget.getBoundingClientRect();
    return [
      Number(
        Math.max(
          0,
          Math.min(1, (event.clientX - rect.left) / rect.width),
        ).toFixed(4),
      ),
      Number(
        Math.max(
          0,
          Math.min(1, (event.clientY - rect.top) / rect.height),
        ).toFixed(4),
      ),
    ];
  };
  const finish = () => {
    if (!active.current) return;
    save([...current.current.strokes, active.current]);
    active.current = null;
    setRedo([]);
    cleared.current = null;
  };
  const undo = () => {
    if (cleared.current) {
      save(cleared.current);
      cleared.current = null;
      return;
    }
    const strokes = [...page.strokes],
      last = strokes.pop();
    if (last) {
      setRedo([...redo, last]);
      save(strokes);
    }
  };
  return (
    <div
      className={embedded ? s.embedded : s.global}
      data-note-embedded={embedded || undefined}
      data-calculation-notes="true"
    >
      {!open && (
        <button
          className={embedded ? "btn secondary" : s.launcher}
          onClick={() => setOpen(true)}
          aria-expanded={false}
          aria-label="계산 노트 열기"
        >
          <span aria-hidden="true">✎</span> 노트
        </button>
      )}
      {open && (
        <aside className={s.panel} aria-label={`${chapter}장 계산 노트`}>
          <header>
            <div>
              <small>탐정의 계산 수첩</small>
              <h2>{chapter}장 노트</h2>
            </div>
            <button
              className="btn secondary"
              onClick={() => {
                finish();
                setOpen(false);
              }}
              aria-label="계산 노트 닫기"
            >
              닫기 ×
            </button>
          </header>
          <div className={s.tools} role="toolbar" aria-label="노트 도구">
            <button
              aria-pressed={tool === "pen"}
              onClick={() => setTool("pen")}
            >
              펜
            </button>
            <button
              aria-pressed={tool === "eraser"}
              onClick={() => setTool("eraser")}
            >
              지우개
            </button>
            <button
              disabled={!page.strokes.length && !cleared.current}
              onClick={undo}
            >
              실행 취소
            </button>
            <button
              disabled={!redo.length}
              onClick={() => {
                const next = [...redo],
                  last = next.pop();
                if (last) {
                  save([...page.strokes, last]);
                  setRedo(next);
                }
              }}
            >
              다시 실행
            </button>
            <button
              disabled={!page.strokes.length}
              onClick={() => {
                cleared.current = page.strokes;
                save([]);
                setRedo([]);
              }}
            >
              전체 지우기
            </button>
          </div>
          <div className={s.colors} role="group" aria-label="펜 색 고르기">
            {[
              ["#253f49", "검정"],
              ["#235db0", "파랑"],
              ["#af433a", "빨강"],
            ].map(([value, label]) => (
              <button
                key={value}
                aria-label={`${label} 펜`}
                aria-pressed={color === value}
                onClick={() => {
                  setColor(value);
                  setTool("pen");
                }}
                style={{ color: value }}
              >
                ●
              </button>
            ))}
          </div>
          <p className={s.help}>
            손가락·펜·마우스로 계산해요. 지우개로 문지르면 지워져요.
          </p>
          <canvas
            ref={canvas}
            className={s.canvas}
            aria-label="자유롭게 계산하는 필기 공간"
            onPointerDown={(event) => {
              if (event.button !== 0 || !event.isPrimary) return;
              event.preventDefault();
              event.currentTarget.setPointerCapture(event.pointerId);
              active.current = {
                color,
                erase: tool === "eraser",
                width: tool === "eraser" ? 0.055 : 0.007,
                points: [point(event)],
              };
              draw();
            }}
            onPointerMove={(event) => {
              if (!active.current || !event.isPrimary) return;
              const events = event.nativeEvent.getCoalescedEvents?.() ?? [];
              for (const sample of events.length ? events : [event]) {
                const rect = event.currentTarget.getBoundingClientRect();
                active.current.points.push([
                  Number(
                    Math.max(
                      0,
                      Math.min(1, (sample.clientX - rect.left) / rect.width),
                    ).toFixed(4),
                  ),
                  Number(
                    Math.max(
                      0,
                      Math.min(1, (sample.clientY - rect.top) / rect.height),
                    ).toFixed(4),
                  ),
                ]);
              }
              draw();
            }}
            onPointerUp={finish}
            onPointerCancel={finish}
            onLostPointerCapture={finish}
          />
          <details>
            <summary>글자로 메모하기</summary>
            <label>
              계산 메모
              <textarea
                value={page.text}
                maxLength={4000}
                onChange={(e) => save(page.strokes, e.target.value)}
              />
            </label>
          </details>
          <p className={s.help}>
            이 수첩의 {chapter}장에 자동 저장돼요. 닫아도 필기는 남아요.
          </p>
        </aside>
      )}
    </div>
  );
}

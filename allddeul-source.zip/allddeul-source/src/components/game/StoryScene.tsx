import { useState, type CSSProperties } from "react";
import {
  adventure,
  characters,
  type CharacterId,
  type Dialogue,
} from "../../data/adventure";
import type { ChapterId } from "../../types";
import { Icon } from "../ui/Icon";
import s from "./Story.module.css";

export function CharacterPortrait({ who }: { who: CharacterId }) {
  return (
    <span className={s.portrait} data-character={who} aria-hidden="true" />
  );
}
export function CharacterDialogue({ line }: { line: Dialogue }) {
  const character = characters[line.who];
  return (
    <div className={s.dialogue}>
      <CharacterPortrait who={line.who} />
      <div>
        <strong>
          {character.name}
          <span>
            {character.animal} · {character.role}
          </span>
        </strong>
        <p>{line.text}</p>
      </div>
    </div>
  );
}
export function StoryScene({
  chapter,
  onStart,
  ending = false,
  line,
}: {
  chapter: ChapterId;
  onStart?: () => void;
  ending?: boolean;
  line?: Dialogue;
}) {
  const story = adventure[chapter];
  const [beat, setBeat] = useState(0);
  const dialogue = line ?? (ending ? story.ending : story.intro[beat]);
  const position = {
    "--scene-x": `${((chapter - 1) % 2) * 100}%`,
    "--scene-y": `${(Math.floor((chapter - 1) / 2) / 3) * 100}%`,
  } as CSSProperties;
  return (
    <section
      className={`${s.scene} ${line ? s.compactScene : ""}`}
      aria-label={`${story.place} 이야기`}
    >
      <div
        className={s.scenery}
        style={position}
        role="img"
        aria-label={`${story.place}에서 사건을 조사하는 탐정 친구들`}
      >
        <span className={s.place}>
          <Icon name="search" size={15} />
          {story.place}
        </span>
        {!line && (
          <div className={s.sceneTitle}>
            <span>
              {ending
                ? "새로운 단서를 찾았어!"
                : `모험 ${chapter} · 탐정단 이야기`}
            </span>
            <h2>{story.title}</h2>
          </div>
        )}
      </div>
      <CharacterDialogue key={`${dialogue.who}-${beat}`} line={dialogue} />
      {onStart && (
        <div className={s.storyControls}>
          <span>
            {beat + 1} / {story.intro.length}
          </span>
          {beat > 0 && (
            <button className="text-button" onClick={() => setBeat(beat - 1)}>
              앞 이야기
            </button>
          )}
          {beat < story.intro.length - 1 ? (
            <>
              <button className="text-button" onClick={onStart}>
                바로 수사하기
              </button>
              <button className="btn primary" onClick={() => setBeat(beat + 1)}>
                다음 이야기
                <Icon name="arrow" size={18} />
              </button>
            </>
          ) : (
            <button className="btn primary" onClick={onStart}>
              수사 시작하기
              <Icon name="arrow" size={18} />
            </button>
          )}
        </div>
      )}
    </section>
  );
}

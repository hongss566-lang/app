import type { CSSProperties } from "react";
import { Icon } from "../ui/Icon";
import s from "./RewardBurst.module.css";

export function RewardBurst({
  points,
  badge,
}: {
  points: number;
  badge: boolean;
}) {
  return (
    <div
      className={`${s.reward} ${badge ? s.badgeReward : ""}`}
      aria-hidden="true"
    >
      {badge && (
        <div className={s.confetti}>
          {Array.from({ length: 20 }, (_, index) => (
            <i key={index} style={{ "--i": index } as CSSProperties} />
          ))}
        </div>
      )}
      <div className={s.popup}>
        <span className={s.medal}>
          <Icon name={badge ? "badge" : "search"} size={badge ? 48 : 28} />
        </span>
        <span>
          {badge ? "사건 해결! 배지 획득!" : "단서를 찾았어!"}
          <strong>+{points}점</strong>
        </span>
      </div>
    </div>
  );
}

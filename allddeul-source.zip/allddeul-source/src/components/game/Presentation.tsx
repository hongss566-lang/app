import { useEffect, useId, useRef, type ReactNode } from "react";
import { createPortal } from "react-dom";
import s from "./Lesson.module.css";

export function Presentation({
  title,
  children,
  onClose,
  closeLabel = "발표 화면 닫기 (Esc)",
  variant = "presentation",
}: {
  title: string;
  children: ReactNode;
  onClose: () => void;
  closeLabel?: string;
  variant?: "presentation" | "quiz";
}) {
  const id = useId();
  const root = useRef<HTMLDivElement>(null);
  const close = useRef<HTMLButtonElement>(null);
  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null;
    const overflow = document.body.style.overflow;
    const appRoot = document.getElementById("root");
    if (appRoot) appRoot.inert = true;
    document.body.style.overflow = "hidden";
    close.current?.focus();
    const key = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        event.preventDefault();
        onClose();
      }
      if (event.key !== "Tab") return;
      const buttons = root.current?.querySelectorAll<HTMLElement>(
        'button, [href], input, textarea, select, [tabindex="0"]',
      );
      if (!buttons?.length) return;
      const first = buttons[0],
        last = buttons[buttons.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    };
    document.addEventListener("keydown", key);
    return () => {
      if (appRoot) appRoot.inert = false;
      document.body.style.overflow = overflow;
      document.removeEventListener("keydown", key);
      previous?.focus();
    };
  }, [onClose]);
  return createPortal(
    <div
      className={`${s.overlay} ${variant === "quiz" ? s.quizOverlay : ""}`}
      role="dialog"
      aria-modal="true"
      aria-labelledby={id}
      ref={root}
    >
      <h1 id={id} className="sr-only">
        {title}
      </h1>
      <button ref={close} className="btn secondary" onClick={onClose}>
        {closeLabel}
      </button>
      <div className={s.overlayBody}>{children}</div>
    </div>,
    document.body,
  );
}

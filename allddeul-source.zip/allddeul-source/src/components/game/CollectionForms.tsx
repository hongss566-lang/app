import { useState } from "react";
import { useLearning } from "../../app/useLearning";
import { actorName } from "../../lib/learning";
import {
  familyCases,
  familyReasons,
  productCases,
  reviewCriteria,
} from "../../data/cases";
import type { Choice } from "../../types";
import { Products, ChoiceButtons } from "./Shared";
import { Icon } from "../ui/Icon";
import s from "./Lesson.module.css";

export function PredictionForm({ participantId }: { participantId?: string }) {
  const { state, note, dispatch, id } = useLearning(participantId);
  const [choice, setChoice] = useState<Choice>();
  const [reason, setReason] = useState("");
  if (note.prediction)
    return (
      <div className={s.envelope}>
        <Icon name="envelope" size={46} />
        <h3>예측 봉투를 봉인했어요</h3>
        <p>
          나의 예측:{" "}
          {note.prediction.choice === "same"
            ? "똑같다"
            : note.prediction.choice}
        </p>
        {note.prediction.reason && <p>생각한 이유: {note.prediction.reason}</p>}
        <p>3장에서 계산한 뒤 봉투를 열어요.</p>
      </div>
    );
  return (
    <div>
      <h3>어느 쪽이 더 저렴할까요?</h3>
      <ChoiceButtons
        value={choice}
        onChange={setChoice}
        label="예측 카드"
        labels={["A 큰 병", "B 작은 병", "똑같다"]}
      />
      <label>
        예측한 이유 (선택)
        <textarea
          value={reason}
          maxLength={500}
          onChange={(event) => setReason(event.target.value)}
          placeholder="내 생각을 짧게 적어 봐요."
        />
      </label>
      {state.envelopeRevealed && (
        <p className={s.notice}>
          이미 봉투를 개봉한 수업이에요. 생각은 기록할 수 있지만 새 예측
          보너스는 주지 않아요.
        </p>
      )}
      <button
        className="btn primary"
        style={{ marginTop: 16 }}
        disabled={!choice}
        onClick={() => {
          if (choice)
            dispatch({ type: "predict", participantId: id, choice, reason });
        }}
      >
        <Icon name="envelope" size={18} />
        예측 봉투 봉인하기
      </button>
    </div>
  );
}

export function PredictionSummary() {
  const { state } = useLearning();
  const ids =
    state.mode === "solo" ? ["solo"] : state.groups.map((group) => group.id);
  const count = (choice: Choice) =>
    ids.filter((id) => state.learning[id]?.prediction?.choice === choice)
      .length;
  return (
    <div aria-label="우리 반 예측 집계">
      <h3>우리 반 예측 집계</h3>
      <div className={s.stats}>
        {(["A", "B", "same"] as const).map((choice) => (
          <div className={s.stat} key={choice}>
            {choice === "same" ? "똑같다" : choice}
            <strong>{count(choice)}</strong>
            {state.mode === "solo" ? "명" : "모둠"}
          </div>
        ))}
      </div>
      <p>
        {ids.filter((id) => state.learning[id]?.prediction).length} /{" "}
        {ids.length} {state.mode === "solo" ? "명" : "모둠"} 기록
      </p>
    </div>
  );
}

export function FamilyForm({ participantId }: { participantId?: string }) {
  const { note, patch } = useLearning(participantId);
  return (
    <div>
      <label>
        가족 상황 고르기
        <select
          aria-label="가족 상황 고르기"
          value={note.familyIndex}
          onChange={(event) =>
            patch({ familyIndex: Number(event.target.value) })
          }
        >
          {familyCases.map((item, index) => (
            <option key={item.id} value={index}>
              {item.title}
            </option>
          ))}
        </select>
      </label>
      <FamilyEditor
        key={`${participantId}-${note.familyIndex}`}
        participantId={participantId}
      />
    </div>
  );
}
function FamilyEditor({ participantId }: { participantId?: string }) {
  const { state, note, id, dispatch } = useLearning(participantId);
  const scenario = familyCases[note.familyIndex];
  const saved = note.families[scenario.id];
  const [choice, setChoice] = useState<"A" | "B" | undefined>(saved?.choice);
  const [reason, setReason] = useState(saved?.reason ?? "");
  const [message, setMessage] = useState("");
  const selectRandom = () =>
    dispatch({
      type: "learn",
      participantId: id,
      patch: {
        familyIndex:
          (note.familyIndex +
            1 +
            Math.floor(Math.random() * (familyCases.length - 1))) %
          familyCases.length,
      },
    });
  return (
    <div>
      <div className={s.notice}>
        <h3>{scenario.title}</h3>
        <p>{scenario.text}</p>
        <button className="text-button" onClick={selectRandom}>
          다른 상황 뽑기
        </button>
      </div>
      <p>A는 작은 우유 900mL · 2,650원, B는 큰 우유 2.3L · 5,980원이에요.</p>
      <div className={s.choices} role="group" aria-label="가족에게 맞는 상품">
        {(["A", "B"] as const).map((key) => (
          <button
            key={key}
            aria-pressed={choice === key}
            onClick={() => setChoice(key)}
          >
            {key === "A"
              ? `A 작은 우유 ${productCases[1].A.amount}${productCases[1].A.unit}`
              : `B 큰 우유 ${productCases[1].B.amount}${productCases[1].B.unit}`}
          </button>
        ))}
      </div>
      <label>
        선택한 이유
        <select
          aria-label="선택한 이유"
          value={reason}
          onChange={(event) => setReason(event.target.value)}
        >
          <option value="">이유를 골라 주세요</option>
          {familyReasons.map((item) => (
            <option key={item}>{item}</option>
          ))}
        </select>
      </label>
      <p>정답이 하나는 아니에요. 가족의 상황에 맞는 이유를 골라 봐요.</p>
      <button
        className="btn primary"
        disabled={!choice || !reason}
        onClick={() => {
          if (choice) {
            dispatch({
              type: "family",
              participantId: id,
              scenario: scenario.id,
              answer: { choice, reason },
            });
            setMessage(`${actorName(state, id)}의 선택과 이유를 기록했어요.`);
          }
        }}
      >
        가족 선택 기록하기
      </button>
      <p role="status">{message}</p>
    </div>
  );
}
export function FamilySummary() {
  const { state } = useLearning();
  return (
    <div aria-label="가족 상황 선택 집계">
      <h3>가족 상황별 우리 반 선택</h3>
      {familyCases.map((item) => {
        const answers = state.groups
          .map((group) => state.learning[group.id]?.families[item.id])
          .filter(Boolean);
        return (
          <div key={item.id} className={s.reviewItem}>
            <strong>{item.title}</strong>
            <p>
              A 작은 우유 {answers.filter((a) => a.choice === "A").length}모둠 ·
              B 큰 우유 {answers.filter((a) => a.choice === "B").length}모둠
            </p>
            <p>
              {familyReasons
                .map(
                  (reason) =>
                    `${reason} ${answers.filter((a) => a.reason === reason).length}`,
                )
                .join(" / ")}
            </p>
          </div>
        );
      })}
    </div>
  );
}

export function PeerReviewForm({ participantId }: { participantId?: string }) {
  const { state, id } = useLearning(participantId);
  const groups = state.groups.filter((group) => group.id !== id);
  const [target, setTarget] = useState(groups[0]?.id ?? "");
  if (groups.length === 0) return <p>평가할 다른 모둠이 아직 없어요.</p>;
  return (
    <div>
      <label>
        평가받을 모둠
        <select
          aria-label="평가받을 모둠"
          value={target}
          onChange={(event) => setTarget(event.target.value)}
        >
          {groups.map((group) => (
            <option key={group.id} value={group.id}>
              {group.name}
            </option>
          ))}
        </select>
      </label>
      <ReviewEditor
        key={`${id}:${target}`}
        participantId={participantId}
        target={target}
      />
    </div>
  );
}
function ReviewEditor({
  participantId,
  target,
}: {
  participantId?: string;
  target: string;
}) {
  const { state, id, dispatch } = useLearning(participantId);
  const existing = state.reviews.find((r) => r.from === id && r.to === target);
  const [stars, setStars] = useState<[number, number, number]>(
    existing?.stars ?? [0, 0, 0],
  );
  const [praise, setPraise] = useState(existing?.praise ?? "");
  const [wish, setWish] = useState(existing?.wish ?? "");
  const [message, setMessage] = useState("");
  const applied = existing?.applied ?? false;
  return (
    <div>
      {reviewCriteria.map((criterion, index) => (
        <fieldset className={s.fieldset} key={criterion}>
          <legend>{criterion}</legend>
          <div className={s.stars} role="group" aria-label={criterion}>
            {[1, 2, 3].map((n) => (
              <button
                key={n}
                disabled={applied}
                aria-label={`${criterion} 별 ${n}개`}
                aria-pressed={stars[index] >= n}
                onClick={() =>
                  setStars(
                    (current) =>
                      current.map((v, i) => (i === index ? n : v)) as [
                        number,
                        number,
                        number,
                      ],
                  )
                }
              >
                <Icon name="star" size={26} />
              </button>
            ))}
          </div>
        </fieldset>
      ))}
      <div className={s.grid}>
        <label>
          칭찬 한마디
          <textarea
            aria-label="칭찬 한마디"
            value={praise}
            disabled={applied}
            maxLength={500}
            onChange={(event) => setPraise(event.target.value)}
          />
        </label>
        <label>
          바라는 점 한마디
          <textarea
            aria-label="바라는 점 한마디"
            value={wish}
            disabled={applied}
            maxLength={500}
            onChange={(event) => setWish(event.target.value)}
          />
        </label>
      </div>
      {applied ? (
        <p className={s.success}>
          교사가 점수를 반영한 평가예요. 기록을 보존하기 위해 수정할 수 없어요.
        </p>
      ) : (
        <button
          className="btn primary"
          style={{ marginTop: 18 }}
          disabled={
            stars.some((value) => value === 0) || !praise.trim() || !wish.trim()
          }
          onClick={() => {
            dispatch({
              type: "review",
              review: {
                id: `${id}:${target}`,
                from: id,
                to: target,
                stars,
                praise: praise.trim(),
                wish: wish.trim(),
              },
            });
            setMessage(
              "친구에게 전할 평가를 저장했어요. 교사가 받은 모둠의 점수에 반영할 수 있어요.",
            );
          }}
        >
          동료 평가 저장하기
        </button>
      )}
      <p role="status">{message}</p>
    </div>
  );
}
export function ReviewSummary({ teacher = false }: { teacher?: boolean }) {
  const { state, dispatch, id } = useLearning();
  const reviews = teacher
    ? state.reviews
    : state.reviews.filter((r) => r.to === id);
  return (
    <div aria-label="동료 평가 집계">
      <h3>
        {teacher ? "모둠별 동료 평가와 점수 반영" : "친구들에게 받은 평가"}
      </h3>
      {teacher && (
        <div className={s.stats}>
          {state.groups.map((group) => {
            const received = state.reviews.filter(
              (review) => review.to === group.id,
            );
            return (
              <div className={s.stat} key={group.id}>
                <span>{group.name}</span>
                <strong>
                  {received.reduce(
                    (sum, review) =>
                      sum + review.stars.reduce((a, b) => a + b, 0),
                    0,
                  )}
                  점
                </strong>
                <p>
                  받은 평가 {received.length}개<br />
                  교사 반영 {received.filter((review) => review.applied).length}
                  개
                </p>
              </div>
            );
          })}
        </div>
      )}
      {reviews.length === 0 && <p>아직 받은 평가가 없어요.</p>}
      {reviews.map((review) => (
        <div className={s.reviewItem} key={review.id}>
          <strong>
            {actorName(state, review.from)} → {actorName(state, review.to)}
          </strong>
          <p>
            {reviewCriteria
              .map((criterion, i) => `${criterion}: ${review.stars[i]}점`)
              .join(" / ")}
          </p>
          <p>칭찬: {review.praise}</p>
          <p>바라는 점: {review.wish}</p>
          {teacher && (
            <button
              className="btn secondary"
              disabled={review.applied}
              onClick={() => dispatch({ type: "applyReview", id: review.id })}
            >
              {review.applied
                ? "점수 반영 완료"
                : `${review.stars.reduce((a, b) => a + b, 0)}점 반영하기`}
            </button>
          )}
        </div>
      ))}
    </div>
  );
}

export function TeacherCollection({
  kind,
  participantId,
}: {
  kind: "prediction" | "peerReview" | "familyChoice";
  participantId: string;
}) {
  return (
    <div className={s.stack}>
      <div className={s.card}>
        {kind === "prediction" ? (
          <>
            <Products pair={productCases[0]} litresOnly />
            <PredictionForm participantId={participantId} />
          </>
        ) : kind === "peerReview" ? (
          <PeerReviewForm participantId={participantId} />
        ) : (
          <FamilyForm participantId={participantId} />
        )}
      </div>
      <div className={s.card}>
        {kind === "prediction" ? (
          <PredictionSummary />
        ) : kind === "peerReview" ? (
          <ReviewSummary teacher />
        ) : (
          <FamilySummary />
        )}
      </div>
    </div>
  );
}

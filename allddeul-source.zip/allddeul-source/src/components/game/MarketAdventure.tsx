import { useRef, useState, type KeyboardEvent } from "react";
import { useLearning } from "../../app/useLearning";
import { characters, type CharacterId } from "../../data/adventure";
import { marketMap, marketQuests } from "../../data/cases";
import {
  isMarketPath,
  marketComplete,
  marketGate,
  marketMove,
  marketStart,
} from "../../lib/marketGame";
import { CharacterPortrait } from "./StoryScene";
import { Icon } from "../ui/Icon";
import s from "./MarketAdventure.module.css";
import lesson from "./Lesson.module.css";

export function MarketAdventure() {
  const { note, patch, reward, state, id } = useLearning();
  const [started, setStarted] = useState(!!note.marketGame);
  const [active, setActive] = useState<string | null>(null);
  const [selection, setSelection] = useState<number | null>(null);
  const [feedback, setFeedback] = useState("");
  const [hint, setHint] = useState(false);
  const [movement, setMovement] = useState("");
  const board = useRef<HTMLDivElement>(null);
  const questionTitle = useRef<HTMLHeadingElement>(null);
  const saved = note.marketGame;
  const position =
    saved &&
    isMarketPath(saved.x, saved.y) &&
    !marketQuests.some((q) => q.x === saved.x && q.y === saved.y)
      ? { x: saved.x, y: saved.y }
      : marketStart;
  const game = {
    ...position,
    character: saved?.character ?? ("fox" as CharacterId),
    solved: saved?.solved ?? [],
    finished: saved?.finished ?? false,
  };
  const update = (next: Partial<typeof game>) =>
    patch({ marketGame: { ...game, ...next } });
  const near = marketQuests.find(
    (q) => Math.abs(q.x - game.x) + Math.abs(q.y - game.y) === 1,
  );
  const quest = marketQuests.find((q) => q.id === active);
  const atGate =
    Math.abs(game.x - marketGate.x) + Math.abs(game.y - marketGate.y) <= 1;
  const allClues = marketComplete(game.solved);
  const unlocked = state.progress[id]?.completedChapters.length === 8;
  const move = (dx: number, dy: number) => {
    const next = marketMove(game, dx, dy);
    if (next.x === game.x && next.y === game.y)
      setMovement("그쪽은 지나갈 수 없어요. 다른 길로 가 봐요.");
    else {
      update(next);
      setMovement(`현재 위치: 가로 ${next.x + 1}, 세로 ${next.y + 1}`);
    }
  };
  const interact = () => {
    if (!near) return;
    setActive(near.id);
    setSelection(null);
    setFeedback("");
    setHint(false);
    requestAnimationFrame(() => questionTitle.current?.focus());
  };
  const keys = (event: KeyboardEvent<HTMLDivElement>) => {
    const directions: Record<string, [number, number]> = {
      ArrowUp: [0, -1],
      ArrowDown: [0, 1],
      ArrowLeft: [-1, 0],
      ArrowRight: [1, 0],
      w: [0, -1],
      s: [0, 1],
      a: [-1, 0],
      d: [1, 0],
    };
    if (active || event.altKey || event.ctrlKey || event.metaKey) return;
    if (directions[event.key]) {
      event.preventDefault();
      move(...directions[event.key]);
    }
    if (event.key === "Enter" || event.key === " ") {
      event.preventDefault();
      interact();
    }
  };
  if (!unlocked) return null;
  return (
    <section className={s.adventure} aria-label="마지막 탐정 모험">
      <span className="eyebrow">PROMPT 여정 완료 · 마지막 복습 게임</span>
      <h2>반짝시장 대모험</h2>
      <p>
        축제의 마지막 초대장이 사라졌어! 탐정 친구들을 찾아 퀴즈를 풀고 네
        단서를 모아 줘. 위쪽 가운데 축제 문에서 마지막 사건을 해결하자.
      </p>
      {!started ? (
        <button
          className="btn primary"
          onClick={() => {
            setStarted(true);
            update({});
          }}
        >
          마지막 모험 시작하기 <Icon name="arrow" size={18} />
        </button>
      ) : (
        <>
          <div
            className={s.characterPicker}
            role="group"
            aria-label="움직일 탐정 고르기"
          >
            {(Object.keys(characters) as CharacterId[]).map((who) => (
              <button
                key={who}
                aria-pressed={game.character === who}
                onClick={() => update({ character: who })}
              >
                <CharacterPortrait who={who} />
                {characters[who].name}
              </button>
            ))}
          </div>
          <p id="market-controls">
            지도에 손을 대거나 Tab으로 지도를 고른 뒤 방향키로 이동해요.
            태블릿에서는 아래 방향 버튼을 눌러요. 친구 옆에서 ‘대화하기’를
            누르면 퀴즈가 열려요. 시간 제한은 없어요.
          </p>
          <div className={s.gameLayout}>
            <div>
              <div
                className={s.board}
                ref={board}
                tabIndex={0}
                onPointerDown={() => board.current?.focus()}
                onKeyDown={keys}
                role="group"
                aria-label={`반짝시장 지도, ${characters[game.character].name}의 위치 가로 ${game.x + 1}, 세로 ${game.y + 1}`}
                aria-describedby="market-controls"
              >
                {marketMap.flatMap((row, y) =>
                  row
                    .split("")
                    .map((tile, x) => (
                      <span
                        key={`${x}-${y}`}
                        className={tile === "#" ? s.hedge : s.path}
                        style={{ gridColumn: x + 1, gridRow: y + 1 }}
                        aria-hidden="true"
                      />
                    )),
                )}
                <span
                  className={s.gate}
                  style={{
                    gridColumn: marketGate.x + 1,
                    gridRow: marketGate.y + 1,
                  }}
                  aria-hidden="true"
                >
                  <Icon name="badge" size={25} />
                  <small>축제 문</small>
                </span>
                {marketQuests.map((q) => (
                  <span
                    className={`${s.npc} ${game.solved.includes(q.id) ? s.solved : ""}`}
                    key={q.id}
                    style={{ gridColumn: q.x + 1, gridRow: q.y + 1 }}
                    aria-hidden="true"
                  >
                    <CharacterPortrait who={q.who} />
                    <small>
                      {game.solved.includes(q.id) ? "✓ " : "? "}
                      {characters[q.who].name}
                    </small>
                  </span>
                ))}
                <span
                  className={s.player}
                  style={{ gridColumn: game.x + 1, gridRow: game.y + 1 }}
                  aria-hidden="true"
                >
                  <CharacterPortrait who={game.character} />
                  <small>나</small>
                </span>
              </div>
              <p className={s.mapLegend}>
                친구 위치: 모아 ↖ · 올리 ↗ · 루미 ← · 두리 → · 축제 문 ↑
              </p>
              <div className={s.pad} role="group" aria-label="탐정 이동 버튼">
                <button
                  aria-label="위로 이동"
                  disabled={!!active}
                  onClick={() => move(0, -1)}
                >
                  ↑
                </button>
                <button
                  aria-label="왼쪽으로 이동"
                  disabled={!!active}
                  onClick={() => move(-1, 0)}
                >
                  ←
                </button>
                <button
                  aria-label="아래로 이동"
                  disabled={!!active}
                  onClick={() => move(0, 1)}
                >
                  ↓
                </button>
                <button
                  aria-label="오른쪽으로 이동"
                  disabled={!!active}
                  onClick={() => move(1, 0)}
                >
                  →
                </button>
              </div>
              <p role="status" className={s.movement}>
                {movement || "위쪽과 양옆의 친구들을 찾아가 보세요."}
              </p>
              <button
                className="btn primary"
                disabled={!near || !!active}
                onClick={interact}
              >
                {near
                  ? `${characters[near.who].name}와 대화하기`
                  : "친구 옆으로 이동해 주세요"}
              </button>
              {atGate && (
                <button
                  className="btn primary"
                  style={{ marginTop: 12 }}
                  disabled={!allClues || game.finished}
                  onClick={() => {
                    update({ finished: true });
                    reward("market-finale", 20, 8);
                  }}
                >
                  {game.finished
                    ? "축제 문 열기 완료"
                    : allClues
                      ? "네 단서로 축제 문 열기"
                      : `단서를 더 모아 주세요 (${game.solved.length}/4)`}
                </button>
              )}
              {!active && (
                <button
                  className="btn secondary"
                  style={{ marginTop: 12 }}
                  onClick={() => {
                    update(marketStart);
                    setMovement(
                      "출발 광장으로 돌아왔어요. 모은 단서는 그대로예요.",
                    );
                    board.current?.focus();
                  }}
                >
                  출발 광장으로 돌아가기
                </button>
              )}
            </div>
            <aside className={s.clueBag} aria-label="모은 모험 단서">
              <h3>단서 주머니 · {game.solved.length}/4</h3>
              <ul>
                {marketQuests.map((q) => (
                  <li key={q.id}>
                    {game.solved.includes(q.id) ? "✓" : "○"} {q.clue}
                    <small>
                      {q.place} · {characters[q.who].name}
                    </small>
                  </li>
                ))}
              </ul>
              {allClues && !game.finished && (
                <p>
                  네 단서를 모았어요! 지도 위쪽 가운데 축제 문으로 가 보세요.
                </p>
              )}
            </aside>
          </div>
          {quest && (
            <section className={s.quiz} aria-label={`${quest.place} 퀴즈`}>
              <div className={s.quizHost}>
                <CharacterPortrait who={quest.who} />
                <h3 ref={questionTitle} tabIndex={-1}>
                  {characters[quest.who].name}의 퀴즈 · {quest.place}
                </h3>
              </div>
              <p>{quest.question}</p>
              {game.solved.includes(quest.id) ? (
                <p className={lesson.success}>
                  {quest.explanation} ‘{quest.clue}’는 단서 주머니에 담았어!
                </p>
              ) : (
                <>
                  <div
                    className={s.answers}
                    role="group"
                    aria-label="모험 퀴즈 답 고르기"
                  >
                    {quest.options.map((option, i) => (
                      <button
                        key={option}
                        aria-pressed={selection === i}
                        onClick={() => {
                          setSelection(i);
                          setFeedback("");
                        }}
                      >
                        {option}
                      </button>
                    ))}
                  </div>
                  <button
                    className="btn primary"
                    disabled={selection === null}
                    onClick={() => {
                      if (selection === quest.answer) {
                        update({ solved: [...game.solved, quest.id] });
                        reward(`market-${quest.id}`, 10, 8);
                        setFeedback("");
                      } else {
                        setFeedback(
                          "다시 생각해 봐요. 힌트를 보고 한 번 더 도전할 수 있어요.",
                        );
                        setHint(true);
                      }
                    }}
                  >
                    모험 퀴즈 확인하기
                  </button>
                  <button
                    className="btn secondary"
                    onClick={() => setHint(true)}
                  >
                    모험 힌트 보기
                  </button>
                  <p role="status">{feedback}</p>
                  {hint && <p className={lesson.notice}>{quest.hint}</p>}
                </>
              )}
              <button
                className="btn secondary"
                onClick={() => {
                  setActive(null);
                  board.current?.focus();
                }}
              >
                시장으로 돌아가기
              </button>
            </section>
          )}
          {game.finished && (
            <div className={s.victory} role="status">
              <Icon name="badge" size={64} />
              <h3>축제 수호 탐정 배지 획득!</h3>
              <p>
                루미: “계산으로 단서를 찾아냈어!” 모아: “분수 열쇠도 척척
                풀었네!”
              </p>
              <p>
                두리: “우리에게 필요한 양도 생각했어!” 올리: “이제 네 선택의
                이유를 설명할 수 있겠구나.”
              </p>
              <p>축제의 초대장을 찾았어요. 반짝마을의 마지막 사건 해결!</p>
            </div>
          )}
        </>
      )}
    </section>
  );
}

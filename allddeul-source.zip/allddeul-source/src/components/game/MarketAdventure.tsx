import { useCallback, useEffect, useRef, useState } from "react";
import { useLearning } from "../../app/useLearning";
import { characters, type CharacterId } from "../../data/adventure";
import { marketQuests, marketQuizPairs } from "../../data/cases";
import {
  isMarketPath,
  marketComplete,
  marketGate,
  marketMove,
  marketStart,
} from "../../lib/marketGame";
import { CharacterSprite, type WalkDirection } from "./CharacterSprite";
import { MarketScenery } from "./MarketScenery";
import { Scratchpad } from "./Scratchpad";
import { Presentation } from "./Presentation";
import { Products } from "./Shared";
import { ProductArt } from "./ProductArt";
import { Icon } from "../ui/Icon";
import s from "./MarketAdventure.module.css";
import lesson from "./Lesson.module.css";

const directions: Record<string, [number, number, WalkDirection]> = {
  ArrowUp: [0, -1, "up"],
  ArrowDown: [0, 1, "down"],
  ArrowLeft: [-1, 0, "left"],
  ArrowRight: [1, 0, "right"],
  w: [0, -1, "up"],
  s: [0, 1, "down"],
  a: [-1, 0, "left"],
  d: [1, 0, "right"],
};
export function MarketAdventure({ onBack }: { onBack: () => void }) {
  const { note, patch, reward, state, id } = useLearning();
  const [active, setActive] = useState<string | null>(null);
  const [selection, setSelection] = useState<number | null>(null);
  const [feedback, setFeedback] = useState("");
  const [hint, setHint] = useState(false);
  const [direction, setDirection] = useState<WalkDirection>("down");
  const [walking, setWalking] = useState(false);
  const [movement, setMovement] = useState("");
  const timer = useRef<ReturnType<typeof setInterval> | null>(null);
  const idle = useRef<ReturnType<typeof setTimeout> | null>(null);
  const board = useRef<HTMLDivElement>(null);
  const latest = useRef<(key: string) => void>(() => {});
  const saved = note.marketGame;
  const position =
    saved &&
    isMarketPath(saved.x, saved.y) &&
    !marketQuests.some((q) => q.x === saved.x && q.y === saved.y)
      ? { x: saved.x, y: saved.y }
      : marketStart;
  const game = {
    ...position,
    character: saved?.character ?? ("fox" as CharacterId),
    solved: saved?.solved ?? [],
    finished: saved?.finished ?? false,
  };
  const update = (next: Partial<typeof game>) =>
    patch({ marketGame: { ...game, ...next } });
  const near = marketQuests.find(
    (q) => Math.abs(q.x - game.x) + Math.abs(q.y - game.y) === 1,
  );
  const quest = marketQuests.find((q) => q.id === active);
  const atGate =
    Math.abs(game.x - marketGate.x) + Math.abs(game.y - marketGate.y) <= 1;
  const allClues = marketComplete(game.solved);
  const stop = useCallback(() => {
    if (timer.current) clearInterval(timer.current);
    timer.current = null;
  }, []);
  const closeQuiz = useCallback(() => {
    setActive(null);
    requestAnimationFrame(() => board.current?.focus());
  }, []);
  const interact = () => {
    if (!near || active) return;
    stop();
    setWalking(false);
    setSelection(null);
    setFeedback("");
    setHint(false);
    setActive(near.id);
  };
  latest.current = (key) => {
    if (active) {
      stop();
      return;
    }
    const vector = directions[key];
    if (!vector) return;
    const [dx, dy, dir] = vector;
    setDirection(dir);
    const next = marketMove(game, dx, dy);
    if (next.x === game.x && next.y === game.y) {
      setWalking(false);
      setMovement("그쪽은 지나갈 수 없어요. 길을 따라가 봐요.");
      return;
    }
    update(next);
    setWalking(true);
    if (idle.current) clearTimeout(idle.current);
    idle.current = setTimeout(() => setWalking(false), 210);
    setMovement(`현재 위치: 가로 ${next.x + 1}, 세로 ${next.y + 1}`);
  };
  const start = (key: string) => {
    stop();
    latest.current(key);
    timer.current = setInterval(() => latest.current(key), 180);
  };
  const interactRef = useRef(interact);
  interactRef.current = interact;
  useEffect(() => {
    const down = (event: KeyboardEvent) => {
      if (
        event.altKey ||
        event.ctrlKey ||
        event.metaKey ||
        (event.target as HTMLElement).closest(
          'input,textarea,select,[role="dialog"],canvas,[data-calculation-notes]',
        )
      )
        return;
      if (directions[event.key]) {
        event.preventDefault();
        if (!event.repeat) start(event.key);
      } else if (
        event.key === "Enter" &&
        document.activeElement === board.current
      ) {
        event.preventDefault();
        interactRef.current();
      }
    };
    const up = (event: KeyboardEvent) => {
      if (directions[event.key]) stop();
    };
    document.addEventListener("keydown", down);
    document.addEventListener("keyup", up);
    window.addEventListener("blur", stop);
    return () => {
      stop();
      if (idle.current) clearTimeout(idle.current);
      document.removeEventListener("keydown", down);
      document.removeEventListener("keyup", up);
      window.removeEventListener("blur", stop);
    };
  }, [stop]);
  useEffect(() => {
    if (active) stop();
  }, [active, stop]);
  if (state.progress[id]?.completedChapters.length !== 8) return null;
  return (
    <section className={s.adventure} aria-label="마지막 탐정 모험">
      <header className={s.hud}>
        <button className="btn secondary" onClick={onBack}>
          ← 수료증으로 돌아가기
        </button>
        <div>
          <small>축제의 초대장을 찾아라</small>
          <h1>반짝시장 대모험</h1>
        </div>
        <strong className={s.clueCount}>
          <Icon name="search" size={20} /> 단서 {game.solved.length}/4
        </strong>
      </header>
      <div className={s.layout}>
        <div className={s.stage}>
          <p id="market-controls" className={s.instructions}>
            방향키 또는 아래 방향 버튼을 꾹 눌러 이동해요. 친구 옆에서 대화하면
            문제 창이 열려요.
          </p>
          <div
            className={s.world}
            ref={board}
            tabIndex={0}
            role="group"
            aria-label={`반짝시장 지도, ${characters[game.character].name}의 위치 가로 ${game.x + 1}, 세로 ${game.y + 1}`}
            aria-describedby="market-controls"
            onPointerDown={() => board.current?.focus()}
          >
            <MarketScenery />
            {marketQuests.map((q) => (
              <div
                className={`${s.npc} ${game.solved.includes(q.id) ? s.solved : ""}`}
                key={q.id}
                style={{
                  left: `${((q.x + 0.5) / 9) * 100}%`,
                  top: `${((q.y + 0.5) / 7) * 100}%`,
                }}
                aria-hidden="true"
              >
                <CharacterSprite who={q.who} />
                <span>
                  {game.solved.includes(q.id) ? "✓" : "?"}{" "}
                  {characters[q.who].name}
                </span>
              </div>
            ))}
            <div
              className={s.player}
              data-walking={walking}
              data-direction={direction}
              style={{
                left: `${((game.x + 0.5) / 9) * 100}%`,
                top: `${((game.y + 0.5) / 7) * 100}%`,
              }}
              aria-hidden="true"
            >
              <CharacterSprite
                who={game.character}
                walking={walking}
                direction={direction}
              />
              <span>나 · {characters[game.character].name}</span>
            </div>
            {game.finished && (
              <span
                className={s.gateClear}
                style={{ left: "50%", top: "16%" }}
                aria-hidden="true"
              >
                축제 문 OPEN ✦
              </span>
            )}
          </div>
          <div className={s.controls}>
            <div className={s.pad} role="group" aria-label="탐정 이동 버튼">
              {[
                ["ArrowUp", "위로 이동", "↑"],
                ["ArrowLeft", "왼쪽으로 이동", "←"],
                ["ArrowDown", "아래로 이동", "↓"],
                ["ArrowRight", "오른쪽으로 이동", "→"],
              ].map(([key, label, arrow]) => (
                <button
                  key={key}
                  aria-label={label}
                  disabled={!!active}
                  onPointerDown={(e) => {
                    e.preventDefault();
                    e.currentTarget.setPointerCapture(e.pointerId);
                    start(key);
                  }}
                  onPointerUp={stop}
                  onPointerCancel={stop}
                  onLostPointerCapture={stop}
                  onClick={(e) => {
                    if (e.detail === 0) latest.current(key);
                  }}
                >
                  {arrow}
                </button>
              ))}
            </div>
            <div className={s.action}>
              <button
                className="btn primary"
                disabled={!near || !!active}
                onClick={interact}
              >
                {near
                  ? `${characters[near.who].name}와 대화하기`
                  : "친구 옆으로 이동해 주세요"}
              </button>
              {atGate && (
                <button
                  className="btn primary"
                  disabled={!allClues || game.finished}
                  onClick={() => {
                    update({ finished: true });
                    reward("market-finale", 20, 8);
                  }}
                >
                  {game.finished
                    ? "축제 문 열기 완료"
                    : allClues
                      ? "네 단서로 축제 문 열기"
                      : `단서를 더 모아 주세요 (${game.solved.length}/4)`}
                </button>
              )}
              <p role="status">
                {movement || "출발 광장에서 네 친구를 찾아가 보세요."}
              </p>
            </div>
          </div>
        </div>
        <aside className={s.sidebar}>
          <h2>함께 갈 탐정</h2>
          <div
            className={s.characterPicker}
            role="group"
            aria-label="움직일 탐정 고르기"
          >
            {(Object.keys(characters) as CharacterId[]).map((who) => (
              <button
                key={who}
                aria-pressed={game.character === who}
                onClick={() => update({ character: who })}
              >
                <CharacterSprite who={who} />
                <span>{characters[who].name}</span>
              </button>
            ))}
          </div>
          <h2>단서 주머니</h2>
          <ul className={s.clueBag} aria-label="모은 모험 단서">
            {marketQuests.map((q) => (
              <li key={q.id} data-done={game.solved.includes(q.id)}>
                <Icon
                  name={game.solved.includes(q.id) ? "check" : "lock"}
                  size={21}
                />
                <div>
                  <strong>{q.clue}</strong>
                  <small>
                    {q.place} · {characters[q.who].name}
                  </small>
                </div>
              </li>
            ))}
          </ul>
          <p>
            {allClues
              ? "단서를 모두 찾았어요! 위쪽 가운데 축제 문으로 가 보세요."
              : "네 곳을 탐험해 초대장을 찾을 단서를 모아요. 시간 제한은 없어요."}
          </p>
          <button
            className="btn secondary"
            onClick={() => {
              stop();
              update(marketStart);
              setMovement("출발 광장으로 돌아왔어요. 모은 단서는 그대로예요.");
              board.current?.focus();
            }}
          >
            출발 광장으로 돌아가기
          </button>
        </aside>
      </div>
      {quest && (
        <Presentation
          title={`${quest.place} 퀴즈`}
          variant="quiz"
          onClose={closeQuiz}
          closeLabel="시장으로 돌아가기"
        >
          <div className={s.quizCard}>
            <div className={s.quizHeading}>
              <CharacterSprite who={quest.who} />
              <div>
                <span>탐정 친구의 의뢰</span>
                <h2>
                  {characters[quest.who].name}의 퀴즈 · {quest.place}
                </h2>
              </div>
            </div>
            <Scratchpad embedded />
            <p className={s.question}>{quest.question}</p>
            {marketQuizPairs[quest.id] ? (
              <Products pair={marketQuizPairs[quest.id]} />
            ) : quest.id === "milk" ? (
              <div className={s.unitArt}>
                <ProductArt
                  product={{
                    name: "달빛 우유",
                    price: "0",
                    amount: "750",
                    unit: "mL",
                  }}
                />
                <strong>750mL = ? L</strong>
              </div>
            ) : (
              <div
                className={s.waterPuzzle}
                role="img"
                aria-label="전체 6L인 큰 물통에서 반 리터 컵으로 덜어내요"
              >
                <svg viewBox="0 0 420 155" aria-hidden="true">
                  <path
                    d="M20 25V126Q20 137 32 137H190Q202 137 202 126V25"
                    fill="#9ed7df"
                    stroke="#2c746d"
                    strokeWidth="4"
                  />
                  {[1, 2, 3, 4, 5].map((i) => (
                    <path
                      key={i}
                      d={`M${20 + (i * 182) / 6} 30V135`}
                      stroke="#f6fcf0"
                      strokeWidth="2"
                      strokeDasharray="5 5"
                    />
                  ))}
                  <text
                    x="111"
                    y="18"
                    textAnchor="middle"
                    fill="#2b514b"
                    fontSize="17"
                    fontWeight="bold"
                  >
                    큰 물통 · 전체 6L
                  </text>
                  <text
                    x="243"
                    y="96"
                    textAnchor="middle"
                    fill="#2b514b"
                    fontSize="26"
                  >
                    ÷
                  </text>
                  <path
                    d="M278 78L285 133H333L340 78Z"
                    fill="#9ed7df"
                    stroke="#2c746d"
                    strokeWidth="3"
                  />
                  <path
                    d="M340 83Q365 83 359 106Q355 119 336 117"
                    fill="none"
                    stroke="#2c746d"
                    strokeWidth="3"
                  />
                  <text
                    x="310"
                    y="62"
                    textAnchor="middle"
                    fill="#2b514b"
                    fontSize="17"
                    fontWeight="bold"
                  >
                    ½L 컵
                  </text>
                  <text
                    x="384"
                    y="109"
                    textAnchor="middle"
                    fill="#2b514b"
                    fontSize="23"
                  >
                    ?
                  </text>
                </svg>
              </div>
            )}
            {game.solved.includes(quest.id) ? (
              <div className={s.clueReward} role="status">
                <Icon name="star" size={44} />
                <h3>{quest.clue} 획득!</h3>
                <p>{quest.explanation}</p>
              </div>
            ) : (
              <>
                <div
                  className={s.answers}
                  role="group"
                  aria-label="모험 퀴즈 답 고르기"
                >
                  {quest.options.map((option, i) => (
                    <button
                      key={option}
                      aria-pressed={selection === i}
                      onClick={() => {
                        setSelection(i);
                        setFeedback("");
                      }}
                    >
                      <span aria-hidden="true">{i + 1}</span>
                      {option}
                    </button>
                  ))}
                </div>
                <div className={s.quizActions}>
                  <button
                    className="btn primary"
                    disabled={selection === null}
                    onClick={() => {
                      if (selection === quest.answer) {
                        update({ solved: [...game.solved, quest.id] });
                        reward(`market-${quest.id}`, 10, 8);
                        setFeedback("");
                      } else {
                        setFeedback(
                          "다시 생각해 봐요. 힌트를 보고 한 번 더 도전할 수 있어요.",
                        );
                        setHint(true);
                      }
                    }}
                  >
                    모험 퀴즈 확인하기
                  </button>
                  <button
                    className="btn secondary"
                    onClick={() => setHint(true)}
                  >
                    모험 힌트 보기
                  </button>
                </div>
                <p role="status">{feedback}</p>
                {hint && <p className={lesson.notice}>{quest.hint}</p>}
              </>
            )}
          </div>
        </Presentation>
      )}
      {game.finished && (
        <section className={s.victory} role="status">
          <Icon name="badge" size={58} />
          <div>
            <h2>축제 수호 탐정 배지 획득!</h2>
            <p>
              네 단서로 초대장을 찾았어요. 루미·모아·두리·올리가 너의 멋진
              선택을 축하해!
            </p>
          </div>
          <button className="btn secondary" onClick={onBack}>
            수료증 보러 가기
          </button>
        </section>
      )}
    </section>
  );
}

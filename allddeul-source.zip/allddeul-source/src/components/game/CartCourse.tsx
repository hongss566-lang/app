import { CharacterPortrait } from "./StoryScene";
import { Icon } from "../ui/Icon";
import s from "./Story.module.css";

export function CartCourse({ visited }: { visited: number }) {
  return (
    <div
      className={s.cartCourse}
      role="img"
      aria-label={`카트 레이스: 다섯 정거장 중 ${visited}곳을 살펴봤어요`}
    >
      {Array.from({ length: 5 }, (_, index) => (
        <div
          className={s.cartStop}
          key={index}
          data-passed={index < visited}
          data-current={index === Math.min(visited, 4)}
        >
          {index === Math.min(visited, 4) ? (
            <CharacterPortrait who="bear" />
          ) : (
            <span>
              {index < visited ? <Icon name="check" size={21} /> : index + 1}
            </span>
          )}
          <strong>{index + 1} 정거장</strong>
        </div>
      ))}
    </div>
  );
}

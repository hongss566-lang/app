import { useId, useState, type ReactNode } from "react";
import { useLearning } from "../../app/useLearning";
import type { Choice, ProductPair } from "../../types";
import {
  formatInteger,
  formatQuotient,
  formatWon,
  roundPrice,
  toLitres,
  winner,
} from "../../lib/math";
import { pairPrices } from "../../lib/learning";
import { Icon } from "../ui/Icon";
import s from "./Lesson.module.css";

export function Hint({
  task,
  hints,
}: {
  task: string;
  hints: [ReactNode, ReactNode, ReactNode];
}) {
  const { note, dispatch, id, state } = useLearning();
  const level = note.hints[task] ?? 0;
  return (
    <aside className={s.hint} aria-label="단계별 힌트">
      <strong>조금씩 단서를 찾아봐요</strong>
      {level > 0 && (
        <ol>
          {hints.slice(0, level).map((hint, i) => (
            <li key={i}>{hint}</li>
          ))}
        </ol>
      )}
      {level < 3 ? (
        <button
          className="text-button"
          onClick={() =>
            dispatch({ type: "hint", participantId: id, key: task })
          }
        >
          <Icon name="search" size={17} />
          {level + 1}단계 힌트 보기
        </button>
      ) : (
        <p>풀이를 보고 다시 도전해 봐요.</p>
      )}
      <p className={s.muted}>
        틀려도 감점은 없어요. 힌트 한 단계마다 이 미션의 보상이 2점씩 줄어요.
      </p>
      {state.mode === "teacher" && state.settings.showAnswers && (
        <div className={s.notice}>
          <strong>교사용 풀이</strong>
          <div>{hints[2]}</div>
        </div>
      )}
    </aside>
  );
}
export function ChoiceButtons({
  value,
  onChange,
  disabled = false,
  label = "선택",
  labels = ["A", "B", "똑같다"],
}: {
  value?: string;
  onChange: (value: Choice) => void;
  disabled?: boolean;
  label?: string;
  labels?: string[];
}) {
  return (
    <div className={s.choices} role="group" aria-label={label}>
      {(["A", "B", "same"] as const).map((choice, index) => (
        <button
          key={choice}
          type="button"
          aria-pressed={value === choice}
          disabled={disabled}
          onClick={() => onChange(choice)}
        >
          {labels[index]}
        </button>
      ))}
    </div>
  );
}
export function Products({
  pair,
  litresOnly = false,
}: {
  pair: ProductPair;
  litresOnly?: boolean;
}) {
  const volumes = (["A", "B"] as const).map(
    (key) => Number(pair[key].amount) * (pair[key].unit === "mL" ? 0.001 : 1),
  );
  const maximum = Math.max(...volumes);
  return (
    <div className={s.grid}>
      {(["A", "B"] as const).map((key) => (
        <article key={key} className={s.product} data-product={key}>
          <div className={s.bottleShelf} aria-hidden="true">
            <span
              className={s.bottle}
              style={{
                height: 35 + (60 * volumes[key === "A" ? 0 : 1]) / maximum,
              }}
            />
          </div>
          <div className={s.productHead}>
            <span className={s.letter}>{key}</span>
            <h3>{pair[key].name}</h3>
          </div>
          <div className={s.priceTag}>
            <span>
              {litresOnly
                ? `${formatQuotient(toLitres(pair[key].amount, pair[key].unit))}L`
                : `${pair[key].amount}${pair[key].unit}`}
            </span>
            <strong>{Number(pair[key].price).toLocaleString("ko-KR")}원</strong>
          </div>
        </article>
      ))}
    </div>
  );
}
export function Verdict({
  pair,
  place = 1,
}: {
  pair: ProductPair;
  place?: 1 | 10;
}) {
  const prices = pairPrices(pair);
  const choice = winner(prices.A, prices.B);
  const sameRounded =
    roundPrice(prices.A, place) === roundPrice(prices.B, place);
  return (
    <div className={s.success} role="status">
      <span className={s.stamp}>
        {choice === "same" ? "같아요" : `${choice} 알뜰 선택`}
      </span>
      <p>
        A {formatWon(prices.A, place)} / B {formatWon(prices.B, place)}
      </p>
      <p>
        {choice === "same"
          ? "두 상품의 1L당 가격이 정확히 같아요."
          : sameRounded
            ? `어림한 값은 같지만 어림하기 전 몫은 ${choice}가 더 작아요.`
            : `${pair[choice].name}의 1L당 가격이 더 낮아요.`}
      </p>
      <p className={s.muted}>
        어림하기 전 몫: A {formatQuotient(prices.A)} / B{" "}
        {formatQuotient(prices.B)}
      </p>
    </div>
  );
}
export function PromptCard({ text }: { text: string }) {
  const [message, setMessage] = useState("");
  const [fallback, setFallback] = useState(false);
  const id = useId();
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(text);
      setMessage("복사했어요. 원하는 곳에 붙여 넣어 보세요.");
    } catch {
      setFallback(true);
      setMessage("아래 문장을 길게 누르거나 선택해서 복사해 주세요.");
    }
  };
  return (
    <section className={s.card}>
      <h2>나도 만들어 보는 프롬프트</h2>
      <p>AI에게 어떤 기능이 필요한지 또렷하게 설명해 봐요.</p>
      <div className={s.prompt}>{text}</div>
      <button
        className="btn secondary"
        onClick={() => {
          void copy();
        }}
      >
        프롬프트 복사
      </button>
      <p role="status">{message}</p>
      {fallback && (
        <label htmlFor={id}>
          복사할 문장
          <textarea
            id={id}
            readOnly
            value={text}
            onFocus={(event) => event.target.select()}
          />
        </label>
      )}
    </section>
  );
}
export function ScoreReceipt({ points }: { points: number }) {
  return (
    <span className={s.tag}>
      <Icon name="search" size={16} />
      단서 {formatInteger(points)}점
    </span>
  );
}

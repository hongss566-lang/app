import { useLearning } from "../../app/useLearning";
import { productCases } from "../../data/cases";
import {
  compare,
  decimal,
  divide,
  formatQuotient,
  formatWon,
  unitPrice,
} from "../../lib/math";
import { ProductArt } from "./ProductArt";
import { CharacterDialogue } from "./StoryScene";
import s from "./MilkLab.module.css";
import lesson from "./Lesson.module.css";
export function MilkLab() {
  const { note, patch, reward } = useLearning();
  const milk = productCases[1],
    drunk = Number(note.milkAmount);
  const small = unitPrice(milk.A.price, milk.A.amount, milk.A.unit);
  const big = unitPrice(milk.B.price, note.milkAmount, "L");
  const boundary = divide(decimal(milk.B.price), small);
  const explore = (amount: string) => {
    patch({ milkAmount: amount, milkExplored: true });
    reward("c8-milk", 10, 8);
  };
  return (
    <section className={lesson.card}>
      <h2>게임 1 · 우유를 남긴다면?</h2>
      <CharacterDialogue
        line={{
          who: "bear",
          text: "큰 병의 우유를 다 마실 수 있을까? 유통기한 안에 마실 양을 바꿔 보자. 남겨 버릴 양까지 생각하면 선택이 달라질 수 있어!",
        }}
      />
      <div className={s.packages}>
        <article className={s.pack} data-product="A">
          <span className={s.tag}>A · 작은 우유</span>
          <ProductArt product={milk.A} label="A" />
          <h3>900mL · 2,650원</h3>
          <p>작은 우유는 모두 마셔요</p>
          <strong className={s.price}>1L당 {formatWon(small)}</strong>
        </article>
        <article className={s.pack} data-product="B">
          <span className={s.tag}>B · 큰 우유</span>
          <ProductArt product={milk.B} label="B" consumed={drunk / 2.3} />
          <h3>2.3L · 5,980원</h3>
          <div className={s.amounts}>
            <span>
              마신 양 <b>{drunk.toFixed(2)}L</b>
            </span>
            <span>
              버릴 양 <b>{(2.3 - drunk).toFixed(2)}L</b>
            </span>
          </div>
          <strong className={s.price}>마신 1L당 {formatWon(big)}</strong>
        </article>
      </div>
      <div className={s.sliderPanel}>
        <label>
          큰 우유에서 실제로 마실 양 <strong>{drunk.toFixed(2)}L</strong>
          <input
            aria-label="실제로 마신 우유의 양"
            type="range"
            min="0.5"
            max="2.3"
            step="0.01"
            value={note.milkAmount}
            onChange={(e) => explore(e.target.value)}
          />
        </label>
        <p>파란 부분은 마신 양, 빗금 부분은 남겨 버릴 양이에요.</p>
      </div>
      <div
        role="status"
        className={compare(big, small) > 0 ? lesson.feedback : lesson.success}
      >
        {compare(big, small) > 0
          ? `${note.milkAmount}L만 마시면 큰 우유의 실제 1L당 가격이 더 높아요!`
          : "이만큼 마신다면 큰 우유의 실제 1L당 가격이 더 낮아요."}
      </div>
      <div className={s.receipt}>
        <span>두리의 계산 영수증 · 큰 우유 B</span>
        <p>
          5,980 ÷ {note.milkAmount} = {formatQuotient(big)} → {formatWon(big)} /
          L
        </p>
        <small>
          선택이 바뀌는 경계는 약 {formatQuotient(boundary).replace("…", "")}
          L예요. 실제 몫으로 비교해요.
        </small>
      </div>
      <button className="btn primary" onClick={() => explore(note.milkAmount)}>
        마신 양과 가격 살펴보기 완료
      </button>
    </section>
  );
}

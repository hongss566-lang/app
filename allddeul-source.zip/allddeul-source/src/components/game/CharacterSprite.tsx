import type { CharacterId } from "../../data/adventure";
import s from "./CharacterSprite.module.css";
export type WalkDirection = "up" | "down" | "left" | "right";
export function CharacterSprite({
  who,
  walking = false,
  direction = "down",
}: {
  who: CharacterId;
  walking?: boolean;
  direction?: WalkDirection;
}) {
  const fur = {
    fox: "#d87834",
    raccoon: "#89796c",
    bear: "#a56d3e",
    owl: "#b99765",
  }[who];
  const dark = "#4c3a2a",
    cream = "#fff0cf";
  return (
    <svg
      viewBox="0 0 120 160"
      className={`${s.sprite} ${walking ? s.walking : ""}`}
      data-direction={direction}
      aria-hidden="true"
    >
      <ellipse cx="60" cy="149" rx="34" ry="8" fill="#203a3d26" />
      <g className={s.figure}>
        {who === "fox" && (
          <path
            d="M86 121Q120 112 105 77Q99 102 77 103Z"
            fill={fur}
            stroke={dark}
            strokeWidth="2"
          />
        )}
        {who === "fox" && (
          <path d="M105 77Q116 95 108 106L98 100Z" fill={cream} />
        )}
        {who === "raccoon" && (
          <g>
            <path
              d="M83 117Q119 116 102 83"
              fill="none"
              stroke={fur}
              strokeWidth="16"
              strokeLinecap="round"
            />
            <path
              d="M95 115L101 103M101 99L109 95"
              stroke={dark}
              strokeWidth="7"
            />
          </g>
        )}
        <g className={s.leftLeg}>
          <path
            d="M46 113L44 142"
            stroke="#304956"
            strokeWidth="15"
            strokeLinecap="round"
          />
          <path
            d="M44 142H34"
            stroke={dark}
            strokeWidth="12"
            strokeLinecap="round"
          />
        </g>
        <g className={s.rightLeg}>
          <path
            d="M73 113L76 142"
            stroke="#304956"
            strokeWidth="15"
            strokeLinecap="round"
          />
          <path
            d="M76 142H86"
            stroke={dark}
            strokeWidth="12"
            strokeLinecap="round"
          />
        </g>
        <g className={s.leftArm}>
          <path
            d="M40 83L29 113"
            stroke="#e9bd66"
            strokeWidth="16"
            strokeLinecap="round"
          />
          <circle
            cx="28"
            cy="116"
            r="8"
            fill={fur}
            stroke={dark}
            strokeWidth="2"
          />
        </g>
        <g className={s.rightArm}>
          <path
            d="M80 83L92 113"
            stroke="#e9bd66"
            strokeWidth="16"
            strokeLinecap="round"
          />
          <circle
            cx="94"
            cy="116"
            r="8"
            fill={fur}
            stroke={dark}
            strokeWidth="2"
          />
        </g>
        <path
          d="M39 77Q60 69 81 77L84 120Q60 129 36 120Z"
          fill="#f1cc80"
          stroke={dark}
          strokeWidth="2"
        />
        <path d="M60 85V121M39 110H83" stroke="#c19648" strokeWidth="2" />
        <path
          d="M42 76L60 89L79 75L74 96L60 89L52 99Z"
          fill="#347b6b"
          stroke={dark}
          strokeWidth="1.5"
        />
        <circle
          cx="74"
          cy="102"
          r="7"
          fill="#f8df84"
          stroke="#997333"
          strokeWidth="2"
        />
        <path
          d="M71 102L73 104L77 99"
          stroke="#805d27"
          fill="none"
          strokeWidth="2"
        />
        <g className={s.head}>
          {who === "fox" ? (
            <path
              d="M29 43L23 7L46 26Q60 19 75 26L99 7L92 45Z"
              fill={fur}
              stroke={dark}
              strokeWidth="2.5"
            />
          ) : who === "bear" || who === "raccoon" ? (
            <>
              <circle
                cx="32"
                cy="30"
                r="16"
                fill={fur}
                stroke={dark}
                strokeWidth="2"
              />
              <circle
                cx="88"
                cy="30"
                r="16"
                fill={fur}
                stroke={dark}
                strokeWidth="2"
              />
              <circle cx="32" cy="30" r="8" fill="#d8b48b" />
              <circle cx="88" cy="30" r="8" fill="#d8b48b" />
            </>
          ) : (
            <path
              d="M26 40L24 15L44 26H76L97 15L94 40Z"
              fill={fur}
              stroke={dark}
              strokeWidth="2"
            />
          )}
          <ellipse
            cx="60"
            cy="49"
            rx="36"
            ry="31"
            fill={fur}
            stroke={dark}
            strokeWidth="2.5"
          />
          <g className={s.face}>
            {who === "fox" && (
              <path
                d="M26 47Q40 68 59 65Q79 68 95 47L81 72L60 80L39 72Z"
                fill={cream}
              />
            )}
            {who === "raccoon" && (
              <path
                d="M28 40Q44 32 60 43Q78 32 93 40L88 59Q72 68 60 53Q45 68 31 59Z"
                fill="#3e3d37"
              />
            )}
            {who === "bear" && (
              <ellipse cx="60" cy="62" rx="20" ry="16" fill="#e4ba80" />
            )}
            {who === "owl" && (
              <>
                <ellipse cx="44" cy="48" rx="21" ry="25" fill={cream} />
                <ellipse cx="77" cy="48" rx="21" ry="25" fill={cream} />
              </>
            )}
            <ellipse
              cx="44"
              cy="47"
              rx={who === "owl" ? 10 : 7}
              ry={who === "owl" ? 12 : 10}
              fill="#fff"
            />
            <ellipse
              cx="77"
              cy="47"
              rx={who === "owl" ? 10 : 7}
              ry={who === "owl" ? 12 : 10}
              fill="#fff"
            />
            <ellipse cx="46" cy="49" rx="4" ry="6" fill="#243d3b" />
            <ellipse cx="75" cy="49" rx="4" ry="6" fill="#243d3b" />
            <circle cx="47" cy="47" r="1.6" fill="#fff" />
            <circle cx="76" cy="47" r="1.6" fill="#fff" />
            {who === "owl" ? (
              <path
                d="M54 61L60 72L67 61Z"
                fill="#d58934"
                stroke={dark}
                strokeWidth="1.5"
              />
            ) : (
              <>
                <path d="M53 60Q60 55 67 60L60 66Z" fill={dark} />
                <path
                  d="M60 66V70M51 70Q60 78 69 70"
                  fill="none"
                  stroke={dark}
                  strokeWidth="2"
                  strokeLinecap="round"
                />
              </>
            )}
            <circle cx="34" cy="61" r="5" fill="#e68c7770" />
            <circle cx="86" cy="61" r="5" fill="#e68c7770" />
          </g>
          <path
            d="M28 31Q30 19 51 18L54 11H76L80 27L96 31Q63 41 27 35Z"
            fill="#3d7061"
            stroke={dark}
            strokeWidth="2"
          />
          <path d="M53 19H77" stroke="#e9c065" strokeWidth="5" />
        </g>
        <g className={s.backpack}>
          <rect
            x="42"
            y="79"
            width="36"
            height="39"
            rx="9"
            fill="#426d61"
            stroke={dark}
            strokeWidth="2"
          />
          <path d="M48 91H72M48 105H72" stroke="#e5c37e" strokeWidth="3" />
        </g>
      </g>
    </svg>
  );
}

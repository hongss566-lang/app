import { toMixed, type Fraction as FractionValue } from "../../lib/math";

export function Fraction({
  value,
  mixed = false,
  raw = false,
}: {
  value: FractionValue;
  mixed?: boolean;
  raw?: boolean;
}) {
  if (mixed) {
    const parts = toMixed(value);
    return (
      <span
        className="mixed-fraction"
        role="math"
        aria-label={
          parts.numerator === 0n
            ? parts.whole.toString()
            : `${parts.whole ? `${parts.whole}와 ` : ""}${parts.denominator}분의 ${parts.numerator}`
        }
      >
        {parts.whole !== 0n && (
          <span aria-hidden="true">{parts.whole.toString()}</span>
        )}
        {parts.numerator !== 0n && (
          <span aria-hidden="true">
            <Fraction
              value={{
                numerator: parts.numerator,
                denominator: parts.denominator,
              }}
            />
          </span>
        )}
        {parts.whole === 0n && parts.numerator === 0n && "0"}
      </span>
    );
  }
  if (value.denominator === 1n && !raw)
    return <span>{value.numerator.toString()}</span>;
  return (
    <span
      className="fraction"
      role="math"
      aria-label={`${value.denominator}분의 ${value.numerator}`}
    >
      <span aria-hidden="true">{value.numerator.toString()}</span>
      <span aria-hidden="true">{value.denominator.toString()}</span>
    </span>
  );
}

import { useState } from "react";
import { render, screen, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it } from "vitest";
import { FractionInput } from "./FractionInput";
import { parseFractionAnswer } from "../../lib/learning";
import { compare, fraction } from "../../lib/math";
function Editor({ initial = "" }: { initial?: string }) {
  const [value, setValue] = useState(initial);
  return (
    <>
      <FractionInput value={value} onChange={setValue} />
      <output aria-label="저장할 답">{value}</output>
    </>
  );
}
describe("어린이를 위한 분수 숫자 칸", () => {
  it("분자·분모와 자연수를 따로 입력한 대분수가 기존 계산과 연결된다", async () => {
    const user = userEvent.setup();
    render(<Editor />);
    await user.click(
      within(screen.getByRole("group", { name: "답의 모양" })).getByRole(
        "button",
        { name: "대분수" },
      ),
    );
    await user.type(screen.getByLabelText("자연수 부분"), "2");
    await user.type(screen.getByLabelText("분자"), "2");
    await user.type(screen.getByLabelText("분모"), "3");
    const value = screen.getByLabelText("저장할 답").textContent!;
    expect(compare(parseFractionAnswer(value)!, fraction(8, 3))).toBe(0);
    expect(
      screen.getByRole("math", { name: "2와 3분의 2" }),
    ).toBeInTheDocument();
  });
  it("기존 가분수 저장을 숫자 칸으로 복원하고 분모 0은 유효한 답으로 표시하지 않는다", async () => {
    const user = userEvent.setup();
    render(<Editor initial="8/3" />);
    expect(screen.getByLabelText("분자")).toHaveValue("8");
    expect(screen.getByLabelText("분모")).toHaveValue("3");
    await user.clear(screen.getByLabelText("분모"));
    await user.type(screen.getByLabelText("분모"), "0");
    expect(screen.queryByText("내 답:")).not.toBeInTheDocument();
    expect(
      parseFractionAnswer(screen.getByLabelText("저장할 답").textContent!),
    ).toBeNull();
  });
});

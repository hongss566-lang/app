import type { Product } from "../../types";
import {
  divide,
  formatQuotient,
  formatWon,
  fraction,
  toLitres,
  unitPrice,
} from "../../lib/math";
import { Fraction } from "./Fraction";
import s from "../game/Lesson.module.css";

export function PourDiagram({
  product,
  label,
  scaleLitres,
}: {
  product: Product;
  label: "A" | "B";
  scaleLitres?: number;
}) {
  const litres = toLitres(product.amount, product.unit);
  const amount = Number(litres.numerator) / Number(litres.denominator);
  const count = Math.ceil(1 / amount - 1e-10);
  const total = Math.max(1, count * amount, scaleLitres ?? 0);
  const drawn = Math.min(40, count);
  const groups = Array.from({ length: drawn }, (_, i) => ({
    start: i * amount,
    size: count > 40 && i === drawn - 1 ? total - i * amount : amount,
  }));
  const times = divide(fraction(1), litres);
  return (
    <div className={s.product} data-product={label} style={{ padding: 20 }}>
      <h3>
        {label} · {product.name}
      </h3>
      <p>한 병의 양: {formatQuotient(litres)}L</p>
      <p className={s.muted}>
        막대 전체 눈금: 0L부터{" "}
        {total.toLocaleString("ko-KR", { maximumFractionDigits: 3 })}L까지
      </p>
      <div
        className={s.pourTrack}
        role="img"
        aria-label={`${product.name}, 1L는 한 병의 ${formatQuotient(times)}배만큼. 1L 밖의 부분은 흐리게 표시해요.`}
      >
        {groups.map((group, index) => (
          <span key={index}>
            <span
              className={s.pourSegment}
              style={{
                left: `${(group.start / total) * 100}%`,
                width: `${(Math.max(0, Math.min(group.size, 1 - group.start)) / total) * 100}%`,
                animationDelay: `${Math.min(index, 20) * 0.05}s`,
              }}
            />
            {group.start + group.size > 1 && (
              <span
                className={s.pourSegment}
                style={{
                  left: `${(Math.max(group.start, 1) / total) * 100}%`,
                  width: `${((group.start + group.size - Math.max(group.start, 1)) / total) * 100}%`,
                  opacity: 0.22,
                  animationDelay: `${Math.min(index, 20) * 0.05}s`,
                }}
              />
            )}
          </span>
        ))}
        <span
          className={s.pourLine}
          style={{ left: 0, width: `${(1 / total) * 100}%` }}
        />
      </div>
      <div className={s.pourLabel}>
        굵은 선까지 1L · 흐린 부분은 1L를 넘는 양
      </div>
      {count > 40 && (
        <p className={s.muted}>
          칸이 40개보다 많아 마지막 부분은 여러 개를 묶어 그렸어요.
        </p>
      )}
      <div className={s.math}>
        1 ÷ <Fraction value={litres} /> = <Fraction value={times} mixed />{" "}
        (병만큼)
        <br />
        1L당 가격 = {Number(product.price).toLocaleString("ko-KR")} ×{" "}
        <Fraction value={times} />
        <br />={" "}
        {formatQuotient(unitPrice(product.price, product.amount, product.unit))}
        원<br />
        <span style={{ fontSize: ".85em" }}>
          반올림하여 일의 자리까지 →{" "}
          {formatWon(unitPrice(product.price, product.amount, product.unit))}
        </span>
      </div>
    </div>
  );
}

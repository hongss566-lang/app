import { useState } from "react";
import { parseFractionAnswer } from "../../lib/learning";
import { Fraction } from "./Fraction";
import s from "../game/Lesson.module.css";

type Shape = "whole" | "fraction" | "mixed";
export function FractionInput({
  value,
  onChange,
  disabled = false,
}: {
  value: string;
  onChange: (value: string) => void;
  disabled?: boolean;
}) {
  const [shape, setShape] = useState<Shape>(() =>
    value.includes("/")
      ? /[\s와]/.test(value.trim())
        ? "mixed"
        : "fraction"
      : "whole",
  );
  const mixed = value.match(/^(\d*)\s*(?:와|\s)\s*(\d*)\s*\/\s*(\d*)$/);
  const simple = value.match(/^(\d*)\/(\d*)$/);
  const parts =
    shape === "mixed"
      ? [mixed?.[1] ?? "", mixed?.[2] ?? "", mixed?.[3] ?? ""]
      : ["", simple?.[1] ?? "", simple?.[2] ?? ""];
  const update = (index: number, text: string) => {
    const next = [...parts];
    next[index] = text.replace(/[^0-9]/g, "").slice(0, 12);
    onChange(`${shape === "mixed" ? `${next[0]} ` : ""}${next[1]}/${next[2]}`);
  };
  const parsed = parseFractionAnswer(value);
  return (
    <fieldset className={s.fractionEditor} disabled={disabled}>
      <legend>몇 컵만큼 덜어낼까요?</legend>
      <p>어떤 모양으로 답을 적을까요?</p>
      <div className={s.choices} role="group" aria-label="답의 모양">
        {(
          [
            ["whole", "자연수"],
            ["fraction", "분수"],
            ["mixed", "대분수"],
          ] as const
        ).map(([key, label]) => (
          <button
            key={key}
            type="button"
            aria-pressed={shape === key}
            onClick={() => {
              setShape(key);
              onChange("");
            }}
          >
            {label}
          </button>
        ))}
      </div>
      <div className={s.fractionFields}>
        {shape === "whole" ? (
          <label>
            컵 수
            <input
              aria-label="몇 컵만큼 덜어낼까요?"
              inputMode="numeric"
              pattern="[0-9]*"
              maxLength={12}
              value={value}
              onChange={(e) => onChange(e.target.value.replace(/[^0-9]/g, ""))}
            />
          </label>
        ) : (
          <>
            {shape === "mixed" && (
              <label>
                자연수 부분
                <input
                  inputMode="numeric"
                  pattern="[0-9]*"
                  value={parts[0]}
                  onChange={(e) => update(0, e.target.value)}
                />
              </label>
            )}
            <div className={s.stackedInputs}>
              <label>
                분자
                <input
                  inputMode="numeric"
                  pattern="[0-9]*"
                  value={parts[1]}
                  onChange={(e) => update(1, e.target.value)}
                />
              </label>
              <label>
                분모
                <input
                  inputMode="numeric"
                  pattern="[0-9]*"
                  value={parts[2]}
                  onChange={(e) => update(2, e.target.value)}
                />
              </label>
            </div>
          </>
        )}
        {parsed && (
          <span className={s.answerPreview}>
            내 답: <Fraction value={parsed} mixed={shape === "mixed"} /> 컵
          </span>
        )}
      </div>
      {shape !== "whole" && (
        <p className={s.muted}>
          위 칸에는 분자, 아래 칸에는 분모를 적어요. 분모에는 0을 쓸 수 없어요.
        </p>
      )}
    </fieldset>
  );
}

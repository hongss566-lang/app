import { marketMap, marketQuests } from "../data/cases";
export const marketStart = { x: 4, y: 5 };
export const marketGate = { x: 4, y: 1 };
export const isMarketPath = (x: number, y: number) => marketMap[y]?.[x] === ".";
export function marketMove(
  position: { x: number; y: number },
  dx: number,
  dy: number,
) {
  const next = { x: position.x + dx, y: position.y + dy };
  return Math.abs(dx) + Math.abs(dy) === 1 &&
    isMarketPath(next.x, next.y) &&
    !marketQuests.some((q) => q.x === next.x && q.y === next.y)
    ? next
    : position;
}
export const marketComplete = (solved: readonly string[]) =>
  marketQuests.every((q) => solved.includes(q.id));

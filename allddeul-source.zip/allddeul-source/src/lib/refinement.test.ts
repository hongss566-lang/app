import { describe, expect, it } from "vitest";
import { bugCases, productCases, speedCases } from "../data/cases";
import { emptyNotebook, makeReport, pairPrices, pairWinner } from "./learning";
import { initialState, loadState, saveState, validState } from "./storage";

describe("새 문제와 계산 과정", () => {
  it("스피드 문제는 앞 사건과 다른 상품·수치이며 나누어떨어지고 A·B·동률을 포함한다", () => {
    for (const pair of speedCases) {
      expect(
        productCases.some(
          (old) =>
            JSON.stringify([old.A, old.B]) === JSON.stringify([pair.A, pair.B]),
        ),
      ).toBe(false);
      const prices = pairPrices(pair);
      expect(prices.A.denominator).toBe(1n);
      expect(prices.B.denominator).toBe(1n);
    }
    expect(speedCases.map(pairWinner)).toEqual(["A", "B", "A", "same", "A"]);
  });
  it("여섯 기록이 모두 판단 전에 계산 과정을 제공하고 오류 종류와 단계가 일치한다", () => {
    expect(bugCases.map((item) => item.steps.length)).toEqual([
      3, 3, 3, 3, 3, 3,
    ]);
    expect(bugCases.map((item) => item.wrongStep)).toEqual([2, 0, 2, 2, 3, 0]);
    expect(bugCases[0].steps[1]).toContain("1,200 ÷ 500");
    expect(bugCases[2].steps[1]).toContain("1.5 ÷ 2,480");
    expect(bugCases[3].steps[1]).toContain("1,200 × 0.5");
    expect(bugCases[4].steps[2]).toContain("십의 자리까지");
  });
});
describe("수첩 호환성과 필기·초안 저장", () => {
  it("기존 우유 선택의 실제 상품·점수를 보존하며 A/B 표기를 한 번만 옮긴다", () => {
    const note = emptyNotebook();
    delete note.milkLabelsVersion;
    note.families = {
      grandmother: { choice: "B", reason: "유통기한" },
      four: { choice: "A", reason: "버리는 양" },
    };
    const state = {
      ...initialState(),
      mode: "solo" as const,
      learning: { solo: note },
    };
    saveState(state);
    const first = loadState();
    expect(first.status).toBe("available");
    expect(first.state.learning.solo.families.grandmother.choice).toBe("A");
    expect(first.state.learning.solo.families.four.choice).toBe("B");
    expect(first.state.scores).toEqual(state.scores);
    saveState(first.state);
    expect(loadState().state).toEqual(first.state);
  });
  it("개인·모둠별 장 필기와 사건별 수정 초안을 복원하고 잘못된 좌표는 거절한다", () => {
    const note = emptyNotebook();
    note.scratch = {
      6: {
        strokes: [
          {
            color: "#235db0",
            width: 0.007,
            erase: false,
            points: [
              [0.1, 0.2],
              [0.5, 0.7],
            ],
          },
        ],
        text: "1200 ÷ 0.5 = 2400",
      },
    };
    note.reportDrafts = {
      "case:milk": {
        report: {
          ...makeReport(productCases[1], "case:milk"),
          conclusion: "큰 우유를 고른 이유를 설명했어요.",
        },
        saved: false,
        answers: {},
      },
    };
    const state = {
      ...initialState(),
      mode: "group" as const,
      learning: { g1: note, g2: emptyNotebook() },
    };
    expect(validState(state)).toBe(true);
    saveState(state);
    const result = loadState().state;
    expect(result.learning.g1.scratch).toEqual(note.scratch);
    expect(result.learning.g2.scratch).toBeUndefined();
    expect(result.learning.g1.reportDrafts).toEqual(note.reportDrafts);
    expect(
      validState({
        ...state,
        learning: {
          g1: {
            ...note,
            scratch: {
              6: {
                strokes: [
                  {
                    color: "#235db0",
                    width: 0.007,
                    erase: false,
                    points: [[2, 0.5]],
                  },
                ],
                text: "",
              },
            },
          },
        },
      }),
    ).toBe(false);
    expect(
      validState({
        ...state,
        learning: {
          g1: {
            ...note,
            reportDrafts: { unknown: note.reportDrafts["case:milk"] },
          },
        },
      }),
    ).toBe(false);
  });
});

import { describe, expect, it, vi } from "vitest";
import {
  clearState,
  initialState,
  loadState,
  saveState,
  STORAGE_KEY,
  validState,
} from "./storage";

describe("수첩 저장과 복원", () => {
  it("처음에는 5모둠·1장 열림·효과음 꺼짐으로 시작한다", () => {
    const { state, status } = loadState();
    expect(status).toBe("available");
    expect(state.groups).toHaveLength(5);
    expect(state.openChapters).toEqual([1]);
    expect(state.settings.sound).toBe(false);
    expect(state.mode).toBeNull();
  });
  it("정상적인 상태를 빠짐없이 복원한다", () => {
    const state = initialState();
    state.mode = "teacher";
    state.openChapters = [1, 4, 7];
    state.teacher = { selectedGroupId: "g3", collectionKind: "peerReview" };
    state.settings.projection = true;
    expect(saveState(state)).toBe(true);
    expect(loadState()).toEqual({ state, status: "available" });
  });
  it.each([
    "{broken",
    "null",
    '{"version":9}',
    JSON.stringify({ ...initialState(), groups: null }),
    JSON.stringify({ ...initialState(), progress: { g1: null } }),
    JSON.stringify({
      ...initialState(),
      teacher: { selectedGroupId: ["g1"], collectionKind: "prediction" },
    }),
  ])("손상되거나 다른 형식인 기록에서도 멈추지 않는다: %s", (raw) => {
    localStorage.setItem(STORAGE_KEY, raw);
    expect(loadState()).toEqual({ state: initialState(), status: "recovered" });
  });
  it("읽기 권한이 없어도 메모리에서 시작한다", () => {
    vi.spyOn(Storage.prototype, "getItem").mockImplementation(() => {
      throw new DOMException("Blocked", "SecurityError");
    });
    expect(loadState()).toEqual({
      state: initialState(),
      status: "unavailable",
    });
  });
  it("저장 공간이 꽉 차도 예외를 전파하지 않는다", () => {
    vi.spyOn(Storage.prototype, "setItem").mockImplementation(() => {
      throw new DOMException("Full", "QuotaExceededError");
    });
    expect(saveState(initialState())).toBe(false);
  });
  it("기록 삭제 권한이 없어도 예외를 전파하지 않는다", () => {
    vi.spyOn(Storage.prototype, "removeItem").mockImplementation(() => {
      throw new DOMException("Blocked", "SecurityError");
    });
    expect(clearState()).toBe(false);
  });
  it("초기화할 때 다른 앱의 데이터는 보존한다", () => {
    localStorage.setItem("other-app", "keep");
    saveState(initialState());
    expect(clearState()).toBe(true);
    expect(localStorage.getItem(STORAGE_KEY)).toBeNull();
    expect(localStorage.getItem("other-app")).toBe("keep");
  });
  it("존재하지 않는 모둠과 비정상 점수 기록을 거절한다", () => {
    expect(validState({ ...initialState(), activeGroupId: "g9" })).toBe(false);
    expect(
      validState({
        ...initialState(),
        scores: [
          { id: "x", participantId: "g1", delta: -1, source: "teacher" },
        ],
      }),
    ).toBe(false);
  });
});

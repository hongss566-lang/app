/** 클릭으로 켠 효과음만 재생한다. 오디오 미지원 환경에서도 활동은 계속된다. */
export function playClueSound(): void {
  try {
    if (typeof window.AudioContext !== "function") return;
    const context = new AudioContext();
    const oscillator = context.createOscillator();
    const gain = context.createGain();
    oscillator.connect(gain);
    gain.connect(context.destination);
    gain.gain.setValueAtTime(0.035, context.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, context.currentTime + 0.18);
    oscillator.frequency.setValueAtTime(660, context.currentTime);
    oscillator.frequency.setValueAtTime(880, context.currentTime + 0.08);
    oscillator.onended = () => {
      void context.close().catch(() => undefined);
    };
    oscillator.start();
    oscillator.stop(context.currentTime + 0.2);
    void context.resume().catch(() => context.close().catch(() => undefined));
  } catch {
    /* 소리가 없어도 점수는 정상 반영된다. */
  }
}

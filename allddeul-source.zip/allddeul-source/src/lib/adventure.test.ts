import { describe, expect, it } from "vitest";
import { initialState, validState } from "./storage";
import { emptyNotebook, chapterReady, makeReport } from "./learning";
import { canOpenChapter } from "./progression";
import { briefingPassed, briefingQuestions } from "./briefing";
import { reducer } from "../app/reducer";
import { badgeNames, productCases } from "../data/cases";

describe("학생 수첩별 순차 모험", () => {
  it("교사 설정 없이 첫 장이 열리고 교사의 열림 설정으로 순서를 건너뛰지 않는다", () => {
    const state = {
      ...initialState(),
      mode: "solo" as const,
      openChapters: [],
    };
    expect(canOpenChapter(state, 1)).toBe(true);
    expect(canOpenChapter(state, 2)).toBe(false);
    expect(canOpenChapter({ ...state, openChapters: [1, 2, 3] }, 3)).toBe(
      false,
    );
  });
  it("미션을 마쳐 배지를 받으면 다음 장이 열리고 보상은 한 번만 지급한다", () => {
    const note = {
      ...emptyNotebook(),
      prediction: { choice: "A" as const, reason: "", eligible: true },
      contexts: ["우유 200mL와 1L"],
      ownContext: "크기가 다른 물감",
    };
    const state = {
      ...initialState(),
      mode: "group" as const,
      learning: { g1: note },
    };
    const action = {
      type: "complete" as const,
      participantId: "g1",
      chapter: 1 as const,
    };
    const next = reducer(state, action);
    expect(canOpenChapter(next, 2)).toBe(true);
    expect(canOpenChapter(next, 3)).toBe(false);
    expect(canOpenChapter({ ...next, activeGroupId: "g2" }, 2)).toBe(false);
    expect(reducer(next, action)).toEqual(next);
    expect(validState(next)).toBe(true);
  });
  it("이전 수첩에서 이미 해결한 사건은 유지하고 빠진 앞 사건을 건너뛰지는 않는다", () => {
    const state = {
      ...initialState(),
      mode: "solo" as const,
      progress: {
        solo: { completedChapters: [3 as const], badges: [badgeNames[2]] },
      },
    };
    expect(canOpenChapter(state, 3)).toBe(true);
    expect(canOpenChapter(state, 4)).toBe(false);
    expect(canOpenChapter(state, 1)).toBe(true);
  });
  it("활동 기록이 있어도 잠긴 사건을 직접 열거나 완료할 수 없다", () => {
    const note = {
      ...emptyNotebook(),
      reportSaved: true,
      report: makeReport(productCases[0], "case:drink"),
      briefingAnswers: { basis: "litre", decision: "A", reason: "exact" },
    };
    const state = {
      ...initialState(),
      mode: "solo" as const,
      learning: { solo: note },
    };
    expect(chapterReady(state, "solo", 7)).toBe(true);
    expect(reducer(state, { type: "chapter", id: 7 })).toEqual(state);
    expect(
      reducer(state, { type: "complete", participantId: "solo", chapter: 7 }),
    ).toEqual(state);
  });
});

describe("교사·동료 없이 완료하는 캐릭터 질문", () => {
  it.each(["solo", "group"] as const)(
    "%s: 보고서와 세 질문을 완료하면 동료 평가 없이 7장을 해결한다",
    (mode) => {
      const note = {
        ...emptyNotebook(),
        report: makeReport(productCases[0], "case:drink"),
        reportSaved: true,
      };
      const id = mode === "solo" ? "solo" : "g1";
      const state = { ...initialState(), mode, learning: { [id]: note } };
      expect(chapterReady(state, id, 7)).toBe(false);
      note.briefingAnswers = { basis: "litre", decision: "A", reason: "exact" };
      expect(chapterReady(state, id, 7)).toBe(true);
      expect(state.reviews).toEqual([]);
    },
  );
  it("보고서의 상품이 바뀌면 그 상품으로 질문의 정답을 계산한다", () => {
    const note = {
      ...emptyNotebook(),
      report: makeReport(productCases[1], "case:milk"),
      briefingAnswers: { basis: "litre", decision: "A", reason: "exact" },
    };
    expect(briefingPassed(note)).toBe(false);
    note.briefingAnswers.decision = "B";
    expect(briefingPassed(note)).toBe(true);
  });
  it("반올림한 가격이 같아도 어림하기 전 몫으로 질문을 판정한다", () => {
    const pair = {
      A: { name: "A", price: "1000.1", amount: "1", unit: "L" as const },
      B: { name: "B", price: "1000.2", amount: "1", unit: "L" as const },
    };
    expect(
      briefingQuestions(pair).find((question) => question.id === "decision")
        ?.correct,
    ).toBe("A");
  });
  it("기존 수첩과 새 미션 위치·질문 답안을 모두 읽고 잘못된 새 필드는 거절한다", () => {
    const state = {
      ...initialState(),
      mode: "solo" as const,
      learning: { solo: emptyNotebook() },
    };
    expect(validState(state)).toBe(true);
    state.learning.solo.missionPages = { 3: 1, 5: 1 };
    state.learning.solo.briefingAnswers = { basis: "litre" };
    expect(validState(state)).toBe(true);
    expect(
      validState({
        ...state,
        learning: { solo: { ...state.learning.solo, missionPages: { 3: -1 } } },
      }),
    ).toBe(false);
    expect(
      validState({
        ...state,
        learning: {
          solo: {
            ...state.learning.solo,
            briefingAnswers: { unknown: "litre" },
          },
        },
      }),
    ).toBe(false);
  });
});

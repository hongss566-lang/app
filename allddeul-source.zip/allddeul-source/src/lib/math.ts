/** 분자·분모를 BigInt로 유지한다. 저장할 때는 원래 입력 문자열을 사용한다. */
export interface Fraction {
  numerator: bigint;
  denominator: bigint;
}
export type Unit = "L" | "mL";

function gcd(a: bigint, b: bigint): bigint {
  a = a < 0n ? -a : a;
  b = b < 0n ? -b : b;
  while (b !== 0n) [a, b] = [b, a % b];
  return a;
}

export function fraction(
  numerator: bigint | number,
  denominator: bigint | number = 1,
): Fraction {
  let n = BigInt(numerator);
  let d = BigInt(denominator);
  if (d === 0n) throw new Error("0으로 나눌 수 없어요.");
  if (d < 0n) {
    n = -n;
    d = -d;
  }
  const divisor = gcd(n, d);
  return { numerator: n / divisor, denominator: d / divisor };
}

/** 최대 소수 셋째 자리 입력. 지수 표기·빈 값·NaN·Infinity를 받지 않는다. */
export function decimal(value: string | number): Fraction {
  const text = String(value).trim();
  if (!/^[+-]?\d+(?:\.\d{1,3})?$/.test(text)) {
    throw new Error("소수 셋째 자리까지 숫자로 입력해 주세요.");
  }
  const [whole, tail = ""] = text.replace(/^[+-]/, "").split(".");
  const denominator = 10n ** BigInt(tail.length);
  const numerator = BigInt(whole) * denominator + BigInt(tail || "0");
  return fraction(text.startsWith("-") ? -numerator : numerator, denominator);
}

export function multiply(a: Fraction, b: Fraction): Fraction {
  return fraction(a.numerator * b.numerator, a.denominator * b.denominator);
}

export function divide(a: Fraction, b: Fraction): Fraction {
  if (b.numerator === 0n) throw new Error("0으로 나눌 수 없어요.");
  return fraction(a.numerator * b.denominator, a.denominator * b.numerator);
}

/** 수업에서 역수를 뒤집은 원래 모양(예: 2/1)도 보여 주기 위한 값. */
export function reciprocalSteps(a: Fraction, b: Fraction) {
  if (b.numerator === 0n) throw new Error("0으로 나눌 수 없어요.");
  return {
    reciprocal: { numerator: b.denominator, denominator: b.numerator },
    result: divide(a, b),
  };
}

export function toLitres(amount: string | number, unit: Unit): Fraction {
  if (unit !== "L" && unit !== "mL")
    throw new Error("단위는 L 또는 mL로 골라 주세요.");
  const value = decimal(amount);
  if (value.numerator <= 0n)
    throw new Error("양은 0보다 큰 수로 입력해 주세요.");
  return unit === "mL" ? divide(value, fraction(1000)) : value;
}

export function unitPrice(
  price: string | number,
  amount: string | number,
  unit: Unit,
): Fraction {
  const value = decimal(price);
  if (value.numerator <= 0n)
    throw new Error("가격은 0보다 큰 수로 입력해 주세요.");
  return divide(value, toLitres(amount, unit));
}

export function compare(a: Fraction, b: Fraction): -1 | 0 | 1 {
  const difference = a.numerator * b.denominator - b.numerator * a.denominator;
  return difference < 0n ? -1 : difference > 0n ? 1 : 0;
}

export function winner(a: Fraction, b: Fraction): "A" | "B" | "same" {
  const result = compare(a, b);
  return result < 0 ? "A" : result > 0 ? "B" : "same";
}

export function formatInteger(value: bigint | number): string {
  return value.toLocaleString("ko-KR");
}

/** 유한소수는 정확한 값, 순환소수는 둘째 자리까지 버림 + …로 표시한다. */
export function formatQuotient(value: Fraction): string {
  const negative = value.numerator < 0n;
  const numerator = negative ? -value.numerator : value.numerator;
  const whole = numerator / value.denominator;
  const remainder = numerator % value.denominator;
  const sign = negative ? "-" : "";
  if (remainder === 0n) return sign + formatInteger(whole);
  let denominator = value.denominator;
  while (denominator % 2n === 0n) denominator /= 2n;
  while (denominator % 5n === 0n) denominator /= 5n;
  if (denominator !== 1n) {
    const tail = ((remainder * 100n) / value.denominator)
      .toString()
      .padStart(2, "0");
    return `${sign}${formatInteger(whole)}.${tail}…`;
  }
  let rest = remainder;
  let tail = "";
  while (rest !== 0n) {
    rest *= 10n;
    tail += (rest / value.denominator).toString();
    rest %= value.denominator;
  }
  return `${sign}${formatInteger(whole)}.${tail}`;
}

/** 양수인 단위가격의 반올림. 십의 자리도 정수 나눗셈으로 계산한다. */
export function roundPrice(value: Fraction, place: 1 | 10 = 1): bigint {
  if (value.numerator < 0n) throw new Error("가격은 음수일 수 없어요.");
  const unit = BigInt(place);
  const divisor = value.denominator * unit;
  return ((value.numerator * 2n + divisor) / (divisor * 2n)) * unit;
}

export function formatWon(value: Fraction, place: 1 | 10 = 1): string {
  return `${formatInteger(roundPrice(value, place))}원`;
}

export function toMixed(value: Fraction) {
  const reduced = fraction(value.numerator, value.denominator);
  return {
    whole: reduced.numerator / reduced.denominator,
    numerator: reduced.numerator % reduced.denominator,
    denominator: reduced.denominator,
  };
}

import {
  adCases,
  badgeNames,
  bugCases,
  familyCases,
  familyReasons,
  flowOrder,
  fractionCases,
  productCases,
} from "../data/cases";
import type {
  AppState,
  ChapterId,
  Notebook,
  ProductPair,
  Rule,
} from "../types";
import {
  compare,
  decimal,
  divide,
  formatQuotient,
  formatWon,
  fraction,
  toLitres,
  unitPrice,
  winner,
  type Fraction,
} from "./math";
import { briefingPassed } from "./briefing";

export const clonePair = (pair: ProductPair): ProductPair => ({
  A: { ...pair.A },
  B: { ...pair.B },
});
export function emptyNotebook(): Notebook {
  return {
    steps: {},
    hints: {},
    contexts: [],
    ownContext: "",
    introGuess: "",
    fractionIndex: 0,
    scoops: {},
    selectedCase: "drink",
    calculations: {},
    shelfPrices: ["", ""],
    outline: {
      order: ["판단", "입력", "시각화", "계산"],
      flowVerified: false,
      flowStep: -1,
      rule: { left: "A", right: "B", operator: "<", target: "A" },
      ruleVerified: false,
      features: [],
      blanks: ["", "", ""],
      storyVerified: false,
    },
    toolPair: clonePair(productCases[0]),
    toolCalculated: false,
    bugs: {},
    hand: ["", ""],
    handVerified: false,
    reportSaved: false,
    milkAmount: "2.3",
    milkExplored: false,
    familyIndex: 0,
    families: {},
    ads: {},
    pledge: "",
    pledgeSaved: false,
  };
}
export function actorId(state: AppState) {
  return state.mode === "solo"
    ? "solo"
    : state.mode === "teacher"
      ? state.teacher.selectedGroupId
      : state.activeGroupId;
}
export function actorName(state: AppState, id: string) {
  return id === "solo"
    ? state.nickname
    : (state.groups.find((group) => group.id === id)?.name ?? "탐정");
}
export function pairPrices(pair: ProductPair) {
  return {
    A: unitPrice(pair.A.price, pair.A.amount, pair.A.unit),
    B: unitPrice(pair.B.price, pair.B.amount, pair.B.unit),
  };
}
export function pairWinner(pair: ProductPair) {
  const prices = pairPrices(pair);
  return winner(prices.A, prices.B);
}
export function validPair(pair: ProductPair): string | null {
  try {
    for (const key of ["A", "B"] as const)
      if (!pair[key].name.trim()) return `상품 ${key}의 이름을 적어 주세요.`;
    pairPrices(pair);
    return null;
  } catch (error) {
    return error instanceof Error
      ? error.message
      : "상품 정보를 다시 확인해 주세요.";
  }
}
export function parseFractionAnswer(text: string): Fraction | null {
  try {
    const value = text.trim();
    const mixed = value.match(/^(\d+)\s*(?:와|\s)\s*(\d+)\s*\/\s*(\d+)$/);
    if (mixed)
      return fraction(
        BigInt(mixed[1]) * BigInt(mixed[3]) + BigInt(mixed[2]),
        BigInt(mixed[3]),
      );
    const simple = value.match(/^(\d+)\s*\/\s*(\d+)$/);
    return simple
      ? fraction(BigInt(simple[1]), BigInt(simple[2]))
      : decimal(value);
  } catch {
    return null;
  }
}
export const scoopQuotient = (index: number) => {
  const item = fractionCases[index];
  return divide(fraction(item.a[0], item.a[1]), fraction(item.b[0], item.b[1]));
};
export function ruleFeedback(rule: Rule): {
  correct: boolean;
  message: string;
} {
  if (rule.left === rule.right)
    return { correct: false, message: "서로 다른 두 상품을 비교해 보세요." };
  if (rule.operator === "=")
    return {
      correct: false,
      message: "같을 때는 '같아요'라고 알려 주는 규칙을 따로 만들어요.",
    };
  const correct =
    rule.target === (rule.operator === "<" ? rule.left : rule.right);
  return {
    correct,
    message: correct
      ? "단위가격이 더 작은 상품을 찾는 올바른 규칙이에요!"
      : "이 규칙대로면 더 비싼 상품에 표시가 붙어요. 다시 생각해 봐요.",
  };
}
export function chapterReady(
  state: AppState,
  id: string,
  chapter: ChapterId,
): boolean {
  const n = state.learning[id] ?? emptyNotebook();
  switch (chapter) {
    case 1:
      return !!n.prediction && n.contexts.length > 0 && !!n.ownContext.trim();
    case 2:
      return (
        !!n.introGuess && fractionCases.every((item) => n.scoops[item.id]?.done)
      );
    case 3:
      return (
        productCases.every((item) => n.calculations[item.id]?.stage === 4) &&
        state.envelopeRevealed
      );
    case 4:
      return (
        n.outline.flowVerified &&
        n.outline.ruleVerified &&
        n.outline.storyVerified
      );
    case 5:
      return n.toolCalculated && !validPair(n.toolPair) && !!n.speed?.finished;
    case 6:
      return (
        bugCases.every((item) => n.bugs[item.id]?.solved) && n.handVerified
      );
    case 7:
      return (
        n.reportSaved &&
        !!n.report &&
        (state.mode === "teacher"
          ? id === "solo" || state.reviews.some((review) => review.from === id)
          : briefingPassed(n))
      );
    case 8:
      return (
        n.milkExplored &&
        Object.keys(n.families).length > 0 &&
        adCases.every((item) => n.ads[item.id] === pairWinner(item)) &&
        n.pledgeSaved &&
        !!n.pledge.trim()
      );
  }
}
export function makeReport(pair: ProductPair, source: string) {
  const prices = pairPrices(pair);
  const choice = pairWinner(pair);
  const small = (["A", "B"] as const).find(
    (key) =>
      compare(toLitres(pair[key].amount, pair[key].unit), fraction(1)) < 0,
  );
  const reciprocal = small
    ? divide(fraction(1), toLitres(pair[small].amount, pair[small].unit))
    : undefined;
  const principle =
    small && reciprocal
      ? `${formatQuotient(toLitres(pair[small].amount, pair[small].unit))}L로 나누는 것은 ${reciprocal.denominator === 1n ? `${reciprocal.numerator}배 하는 것` : "나누는 수의 분자와 분모를 바꾸어 곱하는 것"}과 같아요. 그래서 같은 양으로 비교할 수 있어요.`
      : "두 상품의 가격을 양(L)으로 나누어 모두 1L를 기준으로 비교했어요.";
  const evidence = (key: "A" | "B") =>
    `${pair[key].name}: ${Number(pair[key].price).toLocaleString("ko-KR")} ÷ ${formatQuotient(toLitres(pair[key].amount, pair[key].unit))} = ${formatQuotient(prices[key])} → 1L당 ${formatWon(prices[key])}`;
  return {
    pair: clonePair(pair),
    source,
    event: `A ${pair.A.name} vs B ${pair.B.name}`,
    evidenceA: evidence("A"),
    evidenceB: evidence("B"),
    principle,
    conclusion:
      choice === "same"
        ? "두 상품의 1L당 가격은 같아요!"
        : `오늘의 알뜰 선택은 ${choice} ${pair[choice].name}!`,
  };
}
export const completionBadge = (chapter: ChapterId) => badgeNames[chapter - 1];
export const knownFamily = (id: string, reason: string) =>
  familyCases.some((item) => item.id === id) && familyReasons.includes(reason);
export const correctFlow = (order: string[]) =>
  order.join("|") === flowOrder.join("|");

export interface ChapterTask {
  label: string;
  done: boolean;
  mission: number;
  caseId?: string;
}
// 완료 판정과 같은 기록을 읽어 미완료 활동으로 직접 안내한다.
export function chapterTasks(
  state: AppState,
  id: string,
  chapter: ChapterId,
): ChapterTask[] {
  const n = state.learning[id] ?? emptyNotebook();
  switch (chapter) {
    case 1:
      return [
        { label: "예측 봉투 봉인하기", done: !!n.prediction, mission: 0 },
        {
          label: "생활 속 비교 상황 고르기",
          done: n.contexts.length > 0,
          mission: 1,
        },
        {
          label: "내가 찾은 생활 속 비교 적기",
          done: !!n.ownContext.trim(),
          mission: 1,
        },
      ];
    case 2:
      return [
        { label: "두리의 첫 예측 고르기", done: !!n.introGuess, mission: 0 },
        ...fractionCases.map((item, index) => ({
          label: `덜어내기 실험 ${index + 1}`,
          done: !!n.scoops[item.id]?.done,
          mission: 1,
        })),
      ];
    case 3:
      return [
        ...productCases.map((item) => ({
          label: `${item.label} 계산 · ${Math.min(4, n.calculations[item.id]?.stage ?? 0)}/4단계 완료`,
          done: n.calculations[item.id]?.stage === 4,
          mission: 0,
          caseId: item.id,
        })),
        { label: "예측 봉투 열기", done: state.envelopeRevealed, mission: 1 },
      ];
    case 4:
      return [
        {
          label: "흐름 순서 확인하기",
          done: n.outline.flowVerified,
          mission: 0,
        },
        {
          label: "판단 규칙 확인하기",
          done: n.outline.ruleVerified,
          mission: 1,
        },
        { label: "설계도 완성하기", done: n.outline.storyVerified, mission: 2 },
      ];
    case 5:
      return [
        {
          label: "탐정기로 1L당 가격 비교하기",
          done: n.toolCalculated && !validPair(n.toolPair),
          mission: 0,
        },
        {
          label: "스피드 라운드 다섯 정거장 완료하기",
          done: !!n.speed?.finished,
          mission: 1,
        },
      ];
    case 6:
      return [
        ...bugCases.map((item, i) => ({
          label: `버그 기록 ${i + 1} 확인하기`,
          done: !!n.bugs[item.id]?.solved,
          mission: 1,
        })),
        { label: "손계산 대조하기", done: n.handVerified, mission: 2 },
      ];
    case 7:
      return [
        {
          label: "증거 보고서 저장하기",
          done: n.reportSaved && !!n.report,
          mission: 0,
        },
        {
          label:
            state.mode === "teacher"
              ? "동료 평가 남기기"
              : "탐정단의 세 질문 해결하기",
          done:
            state.mode === "teacher"
              ? id === "solo" || state.reviews.some((r) => r.from === id)
              : briefingPassed(n),
          mission: 1,
        },
      ];
    case 8:
      return [
        {
          label: "실제로 마신 우유의 양 탐구하기",
          done: n.milkExplored,
          mission: 0,
        },
        {
          label: "가족 상황에 맞는 선택과 이유 남기기",
          done: Object.keys(n.families).length > 0,
          mission: 1,
        },
        ...adCases.map((item, i) => ({
          label: `가상 광고 ${i + 1} 해결하기`,
          done: n.ads[item.id] === pairWinner(item),
          mission: 2,
        })),
        {
          label: "소비 다짐 저장하기",
          done: n.pledgeSaved && !!n.pledge.trim(),
          mission: 3,
        },
      ];
  }
}

import { describe, expect, it } from "vitest";
import { adCases, productCases } from "../data/cases";
import { compare, fraction } from "./math";
import {
  correctFlow,
  emptyNotebook,
  makeReport,
  pairWinner,
  parseFractionAnswer,
  ruleFeedback,
  validPair,
} from "./learning";

describe("장별 계산과 판단 규칙", () => {
  it.each([
    ["A", "<", "B", "A"],
    ["A", ">", "B", "B"],
    ["B", "<", "A", "B"],
    ["B", ">", "A", "A"],
  ] as const)(
    "%s %s %s이면 %s가 알뜰 선택이다",
    (left, operator, right, target) => {
      expect(ruleFeedback({ left, operator, right, target }).correct).toBe(
        true,
      );
    },
  );
  it("같은 상품·동률·반대 규칙을 구분해 안내한다", () => {
    expect(
      ruleFeedback({ left: "A", operator: "<", right: "A", target: "A" })
        .message,
    ).toContain("서로 다른");
    expect(
      ruleFeedback({ left: "A", operator: "=", right: "B", target: "A" })
        .message,
    ).toContain("같아요");
    expect(
      ruleFeedback({ left: "A", operator: "<", right: "B", target: "B" })
        .message,
    ).toContain("더 비싼");
  });
  it("흐름은 네 단계를 정확히 한 번씩 포함해야 한다", () => {
    expect(correctFlow(["입력", "계산", "판단", "시각화"])).toBe(true);
    expect(correctFlow(["계산", "입력", "판단", "시각화"])).toBe(false);
    expect(correctFlow(["입력", "계산", "판단", "판단"])).toBe(false);
  });
  it.each(["2 2/3", "2와 2/3", "8/3"])(
    "대분수 예측 %s를 정확히 읽는다",
    (text) => {
      expect(compare(parseFractionAnswer(text)!, fraction(8, 3))).toBe(0);
    },
  );
  it.each(["2/0", "두 컵", "2 3/0", ""])(
    "잘못된 예측 %s에서 멈추지 않는다",
    (text) => {
      expect(parseFractionAnswer(text)).toBeNull();
    },
  );
  it("가상 광고는 전체 묶음 양으로 비교한다", () => {
    expect(adCases.map(pairWinner)).toEqual(["B", "B", "A"]);
  });
  it("음료·우유·주스의 실제 알뜰 선택을 계산한다", () => {
    expect(productCases.map(pairWinner)).toEqual(["A", "B", "A"]);
  });
  it("보고서는 상품의 스냅샷과 계산 근거를 보존한다", () => {
    const notebook = emptyNotebook();
    const report = makeReport(notebook.toolPair, "tool");
    notebook.toolPair.A.price = "9999";
    expect(report.pair.A.price).toBe("2480");
    expect(report.evidenceA).toContain("1,653.33…");
    expect(report.evidenceB).toContain("2,400");
    expect(report.principle).toContain("2배");
    expect(report.conclusion).toContain("A");
  });
  it("잘못된 탐정기 값은 계산 전에 안내한다", () => {
    const notebook = emptyNotebook();
    notebook.toolPair.A.amount = "0";
    expect(validPair(notebook.toolPair)).toContain("0보다");
    notebook.toolPair.A.amount = "1";
    notebook.toolPair.A.name = " ";
    expect(validPair(notebook.toolPair)).toContain("이름");
  });
});

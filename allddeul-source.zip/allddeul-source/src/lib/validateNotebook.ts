import {
  adCases,
  bugCases,
  familyCases,
  familyReasons,
  featureChoices,
  flowOrder,
  fractionCases,
  productCases,
} from "../data/cases";
import { unitPrice } from "./math";
const record = (x: unknown): x is Record<string, unknown> =>
  !!x && typeof x === "object" && !Array.isArray(x);
const text = (x: unknown, max = 2000): x is string =>
  typeof x === "string" && x.length <= max;
const bool = (x: unknown) => typeof x === "boolean";
const integer = (x: unknown, min: number, max: number) =>
  typeof x === "number" && Number.isInteger(x) && x >= min && x <= max;
const strings = (x: unknown, max = 20): x is string[] =>
  Array.isArray(x) && x.length <= max && x.every((v) => text(v));
const choice = (x: unknown) => x === "A" || x === "B" || x === "same";
const pair = (x: unknown) =>
  record(x) &&
  ["A", "B"].every((k) => {
    const p = x[k];
    return (
      record(p) &&
      text(p.name, 80) &&
      text(p.price, 24) &&
      text(p.amount, 24) &&
      (p.unit === "L" || p.unit === "mL")
    );
  });
export function validNotebook(x: unknown): boolean {
  if (!record(x)) return false;
  if (x.milkLabelsVersion !== undefined && x.milkLabelsVersion !== 2)
    return false;
  if (
    x.scratch !== undefined &&
    !(
      record(x.scratch) &&
      Object.entries(x.scratch).every(
        ([key, page]) =>
          /^[1-8]$/.test(key) &&
          record(page) &&
          text(page.text, 4000) &&
          Array.isArray(page.strokes) &&
          page.strokes.every(
            (stroke) =>
              record(stroke) &&
              ["#253f49", "#235db0", "#af433a"].includes(
                String(stroke.color),
              ) &&
              bool(stroke.erase) &&
              typeof stroke.width === "number" &&
              stroke.width > 0 &&
              stroke.width <= 0.1 &&
              Array.isArray(stroke.points) &&
              stroke.points.length > 0 &&
              stroke.points.every(
                (p) =>
                  Array.isArray(p) &&
                  p.length === 2 &&
                  p.every(
                    (n) =>
                      typeof n === "number" &&
                      Number.isFinite(n) &&
                      n >= 0 &&
                      n <= 1,
                  ),
              ),
          ),
      )
    )
  )
    return false;
  if (
    x.reportDrafts !== undefined &&
    !(
      record(x.reportDrafts) &&
      Object.entries(x.reportDrafts).every(
        ([key, draft]) =>
          /^(case:(drink|milk|juice)|tool)$/.test(key) &&
          record(draft) &&
          bool(draft.saved) &&
          record(draft.report) &&
          pair(draft.report.pair) &&
          [
            "source",
            "event",
            "evidenceA",
            "evidenceB",
            "principle",
            "conclusion",
          ].every((k) => text((draft.report as Record<string, unknown>)[k])) &&
          record(draft.answers) &&
          Object.entries(draft.answers).every(
            ([k, v]) =>
              ["basis", "decision", "reason"].includes(k) && text(v, 32),
          ),
      )
    )
  )
    return false;

  if (record(x.reportDrafts)) {
    try {
      for (const draft of Object.values(x.reportDrafts)) {
        const report = (
          draft as {
            report: {
              pair: Record<
                string,
                { price: string; amount: string; unit: "L" | "mL" }
              >;
            };
          }
        ).report;
        for (const product of Object.values(report.pair))
          unitPrice(product.price, product.amount, product.unit);
      }
    } catch {
      return false;
    }
  }
  if (
    x.shelfWork !== undefined &&
    !(
      record(x.shelfWork) &&
      Object.entries(x.shelfWork).every(
        ([id, v]) =>
          productCases.some((c) => c.id === id) &&
          record(v) &&
          strings(v.values, 2) &&
          v.values.length === 2 &&
          bool(v.checked),
      )
    )
  )
    return false;
  if (x.marketGame !== undefined) {
    const game = x.marketGame;
    if (!(
      record(game) &&
      integer(game.x, 0, 8) &&
      integer(game.y, 0, 6) &&
      ["fox", "raccoon", "bear", "owl"].includes(String(game.character)) &&
      strings(game.solved, 4) &&
      new Set(game.solved).size === game.solved.length &&
      game.solved.every((id) =>
        ["water", "milk", "juice", "waste"].includes(id),
      ) &&
      bool(game.finished) &&
      (!game.finished || game.solved.length === 4)
    ))
      return false;
  }

  if (
    x.missionPages !== undefined &&
    !(
      record(x.missionPages) &&
      Object.entries(x.missionPages).every(
        ([k, v]) => /^[1-8]$/.test(k) && integer(v, 0, 8),
      )
    )
  )
    return false;
  if (
    x.briefingAnswers !== undefined &&
    !(
      record(x.briefingAnswers) &&
      Object.entries(x.briefingAnswers).every(
        ([k, v]) => ["basis", "decision", "reason"].includes(k) && text(v, 32),
      )
    )
  )
    return false;
  if (
    !record(x.steps) ||
    !Object.entries(x.steps).every(
      ([k, v]) => /^[1-8]$/.test(k) && integer(v, 0, 2),
    )
  )
    return false;
  if (
    !record(x.hints) ||
    !Object.values(x.hints).every((v) => integer(v, 0, 3))
  )
    return false;
  if (
    x.prediction !== undefined &&
    !(
      record(x.prediction) &&
      choice(x.prediction.choice) &&
      text(x.prediction.reason) &&
      bool(x.prediction.eligible)
    )
  )
    return false;
  if (
    !strings(x.contexts) ||
    !text(x.ownContext) ||
    !text(x.introGuess, 32) ||
    !integer(x.fractionIndex, 0, 5)
  )
    return false;
  if (
    !record(x.scoops) ||
    !Object.entries(x.scoops).every(
      ([id, v]) =>
        fractionCases.some((c) => c.id === id) &&
        record(v) &&
        text(v.prediction, 64) &&
        bool(v.locked) &&
        bool(v.done) &&
        integer(v.scoops, 0, 12),
    )
  )
    return false;
  if (
    !productCases.some((c) => c.id === x.selectedCase) ||
    !record(x.calculations)
  )
    return false;
  if (
    !Object.entries(x.calculations).every(
      ([id, v]) =>
        productCases.some((c) => c.id === id) &&
        record(v) &&
        integer(v.stage, 0, 4) &&
        (v.place === 1 || v.place === 10) &&
        Array.isArray(v.entries) &&
        v.entries.length === 4 &&
        v.entries.every((row) => strings(row, 2)),
    )
  )
    return false;
  if (
    !strings(x.shelfPrices, 2) ||
    x.shelfPrices.length !== 2 ||
    !record(x.outline)
  )
    return false;
  const o = x.outline;
  if (
    !strings(o.order, 4) ||
    o.order.length !== 4 ||
    new Set(o.order).size !== 4 ||
    !o.order.every((k) => flowOrder.includes(k)) ||
    !bool(o.flowVerified) ||
    !integer(o.flowStep, -1, 3)
  )
    return false;
  if (
    !record(o.rule) ||
    ![o.rule.left, o.rule.right, o.rule.target].every(
      (v) => v === "A" || v === "B",
    ) ||
    ![o.rule.operator].every((v) => v === "<" || v === ">" || v === "=")
  )
    return false;
  if (
    !bool(o.ruleVerified) ||
    !strings(o.features, 4) ||
    !o.features.every((v) => featureChoices.includes(v)) ||
    !strings(o.blanks, 3) ||
    o.blanks.length !== 3 ||
    !bool(o.storyVerified)
  )
    return false;
  if (!pair(x.toolPair) || !bool(x.toolCalculated)) return false;
  if (x.speed !== undefined) {
    if (!record(x.speed)) return false;
    const s = x.speed;
    if (
      !integer(s.startedAt, 0, Number.MAX_SAFE_INTEGER) ||
      !integer(s.elapsedMs, 0, Number.MAX_SAFE_INTEGER) ||
      !Array.isArray(s.answers) ||
      s.answers.length > 5 ||
      !s.answers.every((v) => choice(v) || v === "timeout") ||
      !bool(s.timed) ||
      !bool(s.finished)
    )
      return false;
  }
  if (
    !record(x.bugs) ||
    !Object.entries(x.bugs).every(
      ([id, v]) =>
        bugCases.some((c) => c.id === id) &&
        record(v) &&
        text(v.verdict, 16) &&
        text(v.cause, 32) &&
        (v.step === undefined || integer(v.step, 1, 3)) &&
        bool(v.solved),
    )
  )
    return false;
  if (
    !strings(x.hand, 2) ||
    x.hand.length !== 2 ||
    !bool(x.handVerified) ||
    !bool(x.reportSaved)
  )
    return false;
  if (
    x.report !== undefined &&
    !(
      record(x.report) &&
      pair(x.report.pair) &&
      [
        "source",
        "event",
        "evidenceA",
        "evidenceB",
        "principle",
        "conclusion",
      ].every((k) => text((x.report as Record<string, unknown>)[k]))
    )
  )
    return false;
  if (record(x.report) && record(x.report.pair)) {
    try {
      for (const key of ["A", "B"]) {
        const p = x.report.pair[key] as {
          price: string;
          amount: string;
          unit: "L" | "mL";
        };
        unitPrice(p.price, p.amount, p.unit);
      }
    } catch {
      return false;
    }
  }
  if (
    !text(x.milkAmount, 24) ||
    !/^\d(?:\.\d{1,2})?$/.test(x.milkAmount) ||
    Number(x.milkAmount) < 0.5 ||
    Number(x.milkAmount) > 2.3 ||
    !bool(x.milkExplored) ||
    !integer(x.familyIndex, 0, 3)
  )
    return false;
  if (
    !record(x.families) ||
    !Object.entries(x.families).every(
      ([id, v]) =>
        familyCases.some((c) => c.id === id) &&
        record(v) &&
        (v.choice === "A" || v.choice === "B") &&
        typeof v.reason === "string" &&
        familyReasons.includes(v.reason),
    )
  )
    return false;
  return (
    record(x.ads) &&
    Object.entries(x.ads).every(
      ([id, v]) => adCases.some((c) => c.id === id) && choice(v),
    ) &&
    text(x.pledge) &&
    bool(x.pledgeSaved)
  );
}

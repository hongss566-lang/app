import type { Notebook, ProductPair } from "../types";
import type { CharacterId } from "../data/adventure";
import { unitPrice, winner, formatQuotient } from "./math";

export function briefingQuestions(pair: ProductPair) {
  const prices = {
    A: unitPrice(pair.A.price, pair.A.amount, pair.A.unit),
    B: unitPrice(pair.B.price, pair.B.amount, pair.B.unit),
  };
  const result = winner(prices.A, prices.B);
  return [
    {
      id: "basis",
      who: "owl" as CharacterId,
      question:
        "크기가 다른 두 상품의 가격을 비교할 때, 이번 보고서에서는 어떤 양을 기준으로 맞췄니?",
      correct: "litre",
      options: [
        { id: "bottle", label: "병 한 개의 겉보기 크기" },
        { id: "litre", label: "똑같은 1L" },
        { id: "price", label: "전체 가격만" },
      ],
      explanation:
        "두 상품을 같은 1L 기준으로 맞추어야 양이 달라도 가격을 비교할 수 있어.",
    },
    {
      id: "decision",
      who: "bear" as CharacterId,
      question: `네 보고서의 A ${pair.A.name}, B ${pair.B.name} 중 1L당 가격이 더 낮은 쪽은 누구야?`,
      correct: result,
      options: [
        { id: "A", label: `A ${pair.A.name}` },
        { id: "B", label: `B ${pair.B.name}` },
        { id: "same", label: "두 상품이 같아" },
      ],
      explanation: `어림하기 전 몫은 A ${formatQuotient(prices.A)}, B ${formatQuotient(prices.B)}이야. ${result === "same" ? "두 값이 같아." : `${result}의 값이 더 작아.`}`,
    },
    {
      id: "reason",
      who: "raccoon" as CharacterId,
      question:
        "두 몫을 반올림한 값이 같아졌다면, 정말 같은 가격인지 어떻게 확인할까?",
      correct: "exact",
      options: [
        { id: "rounded", label: "반올림한 값이 같으니 같은 가격이야" },
        { id: "exact", label: "어림하기 전 몫을 비교해" },
        { id: "size", label: "무조건 큰 병을 골라" },
      ],
      explanation:
        "반올림하면 서로 다른 몫이 같은 값으로 보일 수 있어. 어림하기 전 값을 비교해야 정확해!",
    },
  ];
}
export function briefingPassed(note: Notebook): boolean {
  return (
    !!note.report &&
    briefingQuestions(note.report.pair).every(
      (question) => note.briefingAnswers?.[question.id] === question.correct,
    )
  );
}

import type { AppState, ChapterId } from "../types";
import { validNotebook } from "./validateNotebook";

export const STORAGE_KEY = "allddeul-detective:v1";
export type StorageStatus = "available" | "unavailable" | "recovered";

export function initialState(): AppState {
  return {
    version: 1,
    mode: null,
    groups: Array.from({ length: 5 }, (_, i) => ({
      id: `g${i + 1}`,
      name: `${i + 1}모둠`,
    })),
    nickname: "새싹 탐정",
    activeGroupId: "g1",
    currentChapter: 1,
    openChapters: [1],
    settings: {
      theme: "system",
      sound: false,
      projection: false,
      showAnswers: false,
      speedLimit: false,
    },
    teacher: { selectedGroupId: "g1", collectionKind: "prediction" },
    scores: [],
    progress: {},
    learning: {},
    reviews: [],
    envelopeRevealed: false,
  };
}

const record = (value: unknown): value is Record<string, unknown> =>
  typeof value === "object" && value !== null && !Array.isArray(value);
const chapter = (value: unknown): value is ChapterId =>
  Number.isInteger(value) && Number(value) >= 1 && Number(value) <= 8;
const participant = (value: unknown): value is string =>
  typeof value === "string" && /^(g[1-6]|solo)$/.test(value);
const name = (value: unknown): value is string =>
  typeof value === "string" && value.trim().length > 0 && value.length <= 20;
const chapterList = (value: unknown): value is ChapterId[] =>
  Array.isArray(value) &&
  value.every(chapter) &&
  new Set(value).size === value.length;

export function validState(value: unknown): value is AppState {
  if (!record(value) || value.version !== 1) return false;
  if (
    value.mode !== null &&
    (typeof value.mode !== "string" ||
      !["teacher", "group", "solo"].includes(value.mode))
  )
    return false;
  if (
    !Array.isArray(value.groups) ||
    value.groups.length < 2 ||
    value.groups.length > 6
  )
    return false;
  if (
    !value.groups.every(
      (group) =>
        record(group) &&
        typeof group.id === "string" &&
        /^g[1-6]$/.test(group.id) &&
        name(group.name),
    )
  )
    return false;
  const ids = value.groups.map((group) => (group as { id: string }).id);
  if (
    new Set(ids).size !== ids.length ||
    typeof value.activeGroupId !== "string" ||
    !ids.includes(value.activeGroupId)
  )
    return false;
  if (
    !name(value.nickname) ||
    !chapter(value.currentChapter) ||
    !chapterList(value.openChapters)
  )
    return false;
  if (
    !record(value.settings) ||
    typeof value.settings.theme !== "string" ||
    !["light", "dark", "system"].includes(value.settings.theme)
  )
    return false;
  if (
    !["sound", "projection", "showAnswers", "speedLimit"].every(
      (key) =>
        typeof (value.settings as Record<string, unknown>)[key] === "boolean",
    )
  )
    return false;
  if (
    !record(value.teacher) ||
    typeof value.teacher.selectedGroupId !== "string" ||
    !ids.includes(value.teacher.selectedGroupId)
  )
    return false;
  if (
    typeof value.teacher.collectionKind !== "string" ||
    !["prediction", "peerReview", "familyChoice"].includes(
      value.teacher.collectionKind,
    )
  )
    return false;
  if (
    !Array.isArray(value.scores) ||
    !value.scores.every(
      (entry) =>
        record(entry) &&
        typeof entry.id === "string" &&
        participant(entry.participantId) &&
        Number.isInteger(entry.delta) &&
        (entry.source === "teacher"
          ? entry.delta === 1 || entry.delta === -1
          : (entry.source === "mission" || entry.source === "peer") &&
            Number(entry.delta) >= 0 &&
            Number(entry.delta) <= 50) &&
        (entry.chapter === undefined || chapter(entry.chapter)),
    )
  )
    return false;
  if (
    new Set(value.scores.map((entry) => entry.id)).size !== value.scores.length
  )
    return false;
  // 교사 조정 기록도 음수가 되지 않는지 확인한다.
  const totals: Record<string, number> = {};
  for (const entry of value.scores) {
    totals[entry.participantId] =
      (totals[entry.participantId] ?? 0) + entry.delta;
    if (totals[entry.participantId] < 0) return false;
  }
  if (!record(value.progress)) return false;
  if (
    !record(value.learning) ||
    !Object.entries(value.learning).every(
      ([id, note]) => participant(id) && validNotebook(note),
    )
  )
    return false;
  if (
    typeof value.envelopeRevealed !== "boolean" ||
    !Array.isArray(value.reviews)
  )
    return false;
  if (
    !value.reviews.every(
      (review) =>
        record(review) &&
        typeof review.id === "string" &&
        participant(review.from) &&
        participant(review.to) &&
        review.from !== review.to &&
        Array.isArray(review.stars) &&
        review.stars.length === 3 &&
        review.stars.every(
          (star) => Number.isInteger(star) && star >= 1 && star <= 3,
        ) &&
        typeof review.praise === "string" &&
        typeof review.wish === "string" &&
        typeof review.applied === "boolean",
    )
  )
    return false;
  if (
    new Set(value.reviews.map((review) => review.id)).size !==
      value.reviews.length ||
    !value.reviews.every(
      (review) => review.id === `${review.from}:${review.to}`,
    )
  )
    return false;
  return Object.entries(value.progress).every(
    ([id, progress]) =>
      participant(id) &&
      record(progress) &&
      chapterList(progress.completedChapters) &&
      Array.isArray(progress.badges) &&
      progress.badges.every((badge) => typeof badge === "string"),
  );
}

export function loadState(): { state: AppState; status: StorageStatus } {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw === null) return { state: initialState(), status: "available" };
    let parsed: unknown = JSON.parse(raw);
    // 1단계 수첩의 모둠·점수를 보존하며 장별 활동 저장 공간을 추가한다.
    if (
      record(parsed) &&
      parsed.version === 1 &&
      !("learning" in parsed) &&
      !("reviews" in parsed) &&
      !("envelopeRevealed" in parsed) &&
      record(parsed.settings)
    ) {
      parsed = {
        ...parsed,
        settings: { ...parsed.settings, speedLimit: false },
        learning: {},
        reviews: [],
        envelopeRevealed: false,
      };
    }
    if (!validState(parsed))
      return { state: initialState(), status: "recovered" };
    // 이전 가족 활동의 A=큰 우유 표기를 새 A=작은 우유 표기로 옮긴다.
    // 학생이 실제로 고른 상품은 유지하고 한 번만 변환한다.
    for (const note of Object.values(parsed.learning)) {
      if (note.milkLabelsVersion !== 2) {
        note.families = Object.fromEntries(
          Object.entries(note.families).map(([key, answer]) => [
            key,
            { ...answer, choice: answer.choice === "A" ? "B" : "A" },
          ]),
        );
        note.milkLabelsVersion = 2;
      }
    }
    return { state: parsed, status: "available" };
  } catch (error) {
    return {
      state: initialState(),
      status: error instanceof SyntaxError ? "recovered" : "unavailable",
    };
  }
}

export function saveState(state: AppState): boolean {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    return true;
  } catch {
    return false;
  }
}

export function clearState(): boolean {
  try {
    localStorage.removeItem(STORAGE_KEY);
    return true;
  } catch {
    return false;
  }
}

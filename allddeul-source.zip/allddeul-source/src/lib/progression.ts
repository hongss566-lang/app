import type { AppState, ChapterId } from "../types";
import { actorId } from "./learning";

// 학생의 길은 각 탐정 수첩의 배지로 열린다. 교사 화면의 잠금과 독립적이다.
export function canOpenChapter(
  state: AppState,
  chapter: ChapterId,
  id = actorId(state),
): boolean {
  if (state.mode === "teacher") return true;
  const done = state.progress[id]?.completedChapters ?? [];
  return (
    chapter === 1 ||
    done.includes(chapter) ||
    Array.from({ length: chapter - 1 }, (_, index) => index + 1).every(
      (previous) => done.includes(previous as ChapterId),
    )
  );
}

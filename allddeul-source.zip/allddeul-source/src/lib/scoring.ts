import type { AppState } from "../types";

let scoreSequence = 0;
export function newScoreEventId(): string {
  try {
    if (typeof globalThis.crypto?.randomUUID === "function") {
      return globalThis.crypto.randomUUID();
    }
  } catch {
    // 일부 브라우저 정책에서는 이 API를 제공하지 않는다.
  }
  // 점수 기록 식별자이며 인증용 값이 아니다. 일반 HTTP에서도 사용할 수 있다.
  return `teacher-${Date.now()}-${++scoreSequence}-${Math.random().toString(36).slice(2)}`;
}

export const ranks = [
  { name: "견습 탐정", threshold: 0 },
  { name: "탐정", threshold: 60 },
  { name: "선임 탐정", threshold: 140 },
  { name: "수석 탐정", threshold: 240 },
] as const;

export function scoreFor(state: AppState, participantId: string): number {
  return state.scores.reduce(
    (sum, entry) =>
      sum + (entry.participantId === participantId ? entry.delta : 0),
    0,
  );
}

export function rankFor(score: number) {
  return (
    [...ranks].reverse().find((rank) => score >= rank.threshold) ?? ranks[0]
  );
}

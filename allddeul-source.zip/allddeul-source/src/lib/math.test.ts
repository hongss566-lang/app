import { describe, expect, it } from "vitest";
import {
  compare,
  decimal,
  divide,
  formatQuotient,
  formatWon,
  fraction,
  reciprocalSteps,
  roundPrice,
  toLitres,
  toMixed,
  unitPrice,
  winner,
} from "./math";

describe("요구사항의 단위가격 기대값", () => {
  it.each([
    ["2480", "1.5", "L", "1,653.33…", "1,653원"],
    ["1200", "0.5", "L", "2,400", "2,400원"],
    ["2650", "0.9", "L", "2,944.44…", "2,944원"],
    ["5980", "2.3", "L", "2,600", "2,600원"],
    ["3200", "1", "L", "3,200", "3,200원"],
    ["900", "0.25", "L", "3,600", "3,600원"],
  ] as const)("%s ÷ %s%s", (price, amount, unit, quotient, won) => {
    const result = unitPrice(price, amount, unit);
    expect(formatQuotient(result)).toBe(quotient);
    expect(formatWon(result)).toBe(won);
  });
  it("십의 자리까지 반올림한다", () => {
    expect(formatWon(unitPrice("2480", "1.5", "L"), 10)).toBe("1,650원");
  });
  it("mL를 L로 바꾼다", () => {
    expect(toLitres("500", "mL")).toEqual(fraction(1, 2));
    expect(unitPrice("2650", "900", "mL")).toEqual(
      unitPrice("2650", "0.9", "L"),
    );
    expect(formatWon(unitPrice("1200", "500", "mL"))).toBe("2,400원");
  });
});

describe("분수의 나눗셈", () => {
  it.each([
    [6, 1, 1, 2, 12, 1],
    [3, 1, 1, 4, 12, 1],
    [1, 1, 1, 8, 8, 1],
    [3, 4, 1, 8, 6, 1],
    [3, 2, 1, 4, 6, 1],
    [1, 1, 3, 8, 8, 3],
  ])("%i/%i ÷ %i/%i", (an, ad, bn, bd, n, d) => {
    expect(divide(fraction(an, ad), fraction(bn, bd))).toEqual(fraction(n, d));
  });
  it("대분수 2와 2/3으로 나누어 표시한다", () => {
    expect(toMixed(divide(fraction(1), fraction(3, 8)))).toEqual({
      whole: 2n,
      numerator: 2n,
      denominator: 3n,
    });
  });
  it("뒤집은 분수 2/1을 보존한다", () => {
    expect(reciprocalSteps(fraction(6), fraction(1, 2))).toEqual({
      reciprocal: { numerator: 2n, denominator: 1n },
      result: fraction(12),
    });
  });
});

describe("표시와 판단을 분리한다", () => {
  it("반올림하지 않고 순환소수를 자른다", () => {
    expect(formatQuotient(fraction(2, 3))).toBe("0.66…");
    expect(formatQuotient(fraction(1, 6))).toBe("0.16…");
  });
  it("유한소수와 정수는 정확하게 표시한다", () => {
    expect(formatQuotient(fraction(1, 8))).toBe("0.125");
    expect(formatQuotient(fraction(2500))).toBe("2,500");
    expect(formatQuotient(fraction(1, 2))).toBe("0.5");
  });
  it("어림한 값이 같아도 정확한 값으로 판단한다", () => {
    const a = unitPrice("1000", "3", "L");
    const b = unitPrice("1000.2", "3", "L");
    expect(roundPrice(a)).toBe(roundPrice(b));
    expect(winner(a, b)).toBe("A");
    expect(winner(b, a)).toBe("B");
  });
  it("같은 가격은 같다고 판단한다", () => {
    expect(
      winner(unitPrice("1200", "500", "mL"), unitPrice("2400", "1", "L")),
    ).toBe("same");
  });
  it("셋째 자리와 반올림 경계에서 부동소수점 오차가 없다", () => {
    expect(unitPrice("0.3", "0.1", "L")).toEqual(fraction(3));
    expect(unitPrice("1.005", "1", "L")).toEqual(fraction(201, 200));
    expect(formatWon(unitPrice("100.5", "1", "L"))).toBe("101원");
    expect(formatWon(unitPrice("1655", "1", "L"), 10)).toBe("1,660원");
    expect(toLitres("0.001", "mL")).toEqual(fraction(1, 1000000));
  });
});

describe("우유 낭비 경계", () => {
  const small = unitPrice("2650", "900", "mL");
  it("2.0L만 마시면 큰 우유가 더 비싸다", () => {
    const big = unitPrice("5980", "2.0", "L");
    expect(formatWon(big)).toBe("2,990원");
    expect(compare(big, small)).toBe(1);
  });
  it("2.1L를 마시면 큰 우유가 더 저렴하다", () => {
    const big = unitPrice("5980", "2.1", "L");
    expect(formatWon(big)).toBe("2,848원");
    expect(compare(big, small)).toBe(-1);
  });
  it("경계값을 어림한 2,944원이 아닌 정확한 가격으로 계산한다", () => {
    const boundary = divide(fraction(5980), small);
    expect(boundary).toEqual(fraction(2691, 1325));
    expect(compare(divide(fraction(5980), boundary), small)).toBe(0);
  });
});

describe("잘못된 입력", () => {
  it.each(["", " ", "NaN", "Infinity", "1e3", "0.0001", "1,000", "1.2.3"])(
    "%s를 거절한다",
    (value) => {
      expect(() => decimal(value)).toThrow();
    },
  );
  it.each(["0", "-1"])("가격 또는 양 %s를 거절한다", (value) => {
    expect(() => unitPrice(value, "1", "L")).toThrow("가격");
    expect(() => unitPrice("1000", value, "L")).toThrow("양");
  });
  it("0으로 나누지 않는다", () => {
    expect(() => fraction(1, 0)).toThrow();
    expect(() => divide(fraction(1), fraction(0))).toThrow();
  });
});

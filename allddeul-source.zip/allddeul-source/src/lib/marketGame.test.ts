import { describe, expect, it } from "vitest";
import { marketMap, marketQuests } from "../data/cases";
import {
  marketComplete,
  marketGate,
  marketMove,
  marketStart,
} from "./marketGame";
import { initialState, validState } from "./storage";
import { chapterReady, chapterTasks, emptyNotebook } from "./learning";

describe("마지막 모험의 이동과 단서", () => {
  it("벽·친구 칸과 지도 밖으로 이동하지 않고 한 칸씩만 이동한다", () => {
    expect(marketMove(marketStart, 0, 1)).toEqual(marketStart);
    expect(marketMove(marketStart, 1, 0)).toEqual({ x: 5, y: 5 });
    expect(marketMove({ x: 1, y: 2 }, 0, -1)).toEqual({ x: 1, y: 2 });
    expect(marketMove({ x: 1, y: 5 }, -1, 0)).toEqual({ x: 1, y: 5 });
    expect(marketMove(marketStart, 3, 0)).toEqual(marketStart);
  });
  it("출발점에서 네 친구의 옆과 마지막 문까지 실제로 이동할 수 있다", () => {
    const seen = new Set([`${marketStart.x},${marketStart.y}`]);
    const queue = [marketStart];
    for (let i = 0; i < queue.length; i++) {
      for (const [dx, dy] of [
        [0, 1],
        [0, -1],
        [1, 0],
        [-1, 0],
      ]) {
        const next = marketMove(queue[i], dx, dy),
          key = `${next.x},${next.y}`;
        if (!seen.has(key)) {
          seen.add(key);
          queue.push(next);
        }
      }
    }
    for (const q of marketQuests)
      expect(
        queue.some((p) => Math.abs(q.x - p.x) + Math.abs(q.y - p.y) === 1),
      ).toBe(true);
    expect(seen.has(`${marketGate.x},${marketGate.y}`)).toBe(true);
    expect(marketMap).toHaveLength(7);
  });
  it("중복 단서로 문을 열 수 없고 네 종류를 모두 모아야 한다", () => {
    expect(marketComplete(["water", "water", "water", "water"])).toBe(false);
    expect(marketComplete(marketQuests.map((q) => q.id))).toBe(true);
  });
  it("이전 저장과 새 모험을 복원하며 잘못된 단서·좌표·완료 상태는 거절한다", () => {
    const note = emptyNotebook();
    const state = {
      ...initialState(),
      mode: "solo" as const,
      learning: { solo: note },
    };
    expect(validState(state)).toBe(true);
    note.marketGame = {
      ...marketStart,
      character: "bear",
      solved: ["water"],
      finished: false,
    };
    note.shelfWork = { drink: { values: ["165", "240"], checked: true } };
    expect(validState(state)).toBe(true);
    expect(
      validState({
        ...state,
        learning: {
          solo: { ...note, marketGame: { ...note.marketGame, finished: true } },
        },
      }),
    ).toBe(false);
    expect(
      validState({
        ...state,
        learning: {
          solo: { ...note, marketGame: { ...note.marketGame, x: 90 } },
        },
      }),
    ).toBe(false);
    expect(
      validState({
        ...state,
        learning: {
          solo: {
            ...note,
            marketGame: { ...note.marketGame, solved: ["unknown"] },
          },
        },
      }),
    ).toBe(false);
  });
});
describe("미완료 활동 안내와 선택 미션", () => {
  it("음료만 해결한 기존 수첩에서 우유·주스·봉투가 남았다고 정확히 안내한다", () => {
    const note = emptyNotebook();
    note.calculations.drink = { stage: 4, place: 1, entries: [[], [], [], []] };
    note.shelfPrices = ["165.33", "240"];
    const state = {
      ...initialState(),
      mode: "solo" as const,
      learning: { solo: note },
    };
    expect(chapterReady(state, "solo", 3)).toBe(false);
    expect(
      chapterTasks(state, "solo", 3)
        .filter((t) => !t.done)
        .map((t) => t.caseId ?? "envelope"),
    ).toEqual(["milk", "juice", "envelope"]);
    note.calculations.milk = note.calculations.drink;
    note.calculations.juice = note.calculations.drink;
    state.envelopeRevealed = true;
    note.shelfPrices = ["", ""];
    expect(chapterReady(state, "solo", 3)).toBe(true);
    expect(chapterTasks(state, "solo", 3).every((t) => t.done)).toBe(true);
  });
});

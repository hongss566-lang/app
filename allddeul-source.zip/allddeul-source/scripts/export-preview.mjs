import { readFile, mkdir, writeFile } from "node:fs/promises";
import { dirname, extname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

// 외부 서버·모듈·글꼴 요청 없이 열 수 있는 검토용 HTML을 만든다.
// 원본 코드와 일반 Netlify 빌드 결과는 바꾸지 않는다.
const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const dist = resolve(root, "dist");
let html = await readFile(resolve(dist, "index.html"), "utf8");
const scripts = [
  ...html.matchAll(/<script\b[^>]*\bsrc="([^"]+)"[^>]*><\/script>/g),
];
const styles = [
  ...html.matchAll(/<link\b[^>]*rel="stylesheet"[^>]*href="([^"]+)"[^>]*>/g),
];
if (scripts.length !== 1 || styles.length !== 1) {
  throw new Error(
    "미리보기 내보내기: 단일 JavaScript와 CSS 빌드를 확인해 주세요.",
  );
}

function assetPath(path, base = dist) {
  const absolute = resolve(base, path);
  if (!absolute.startsWith(`${dist}/`))
    throw new Error("빌드 폴더 밖의 파일은 포함할 수 없어요.");
  return absolute;
}

const javascript = await readFile(assetPath(scripts[0][1]), "utf8");
if (/\bimport\s*(?:\(|["'{*])/.test(javascript)) {
  throw new Error(
    "미리보기 내보내기: 외부 모듈이 남아 있어요. 단일 번들이 필요해요.",
  );
}
const cssPath = assetPath(styles[0][1]);
let css = await readFile(cssPath, "utf8");
const assets = new Map();
for (const match of css.matchAll(/url\(["']?([^"')]+)["']?\)/g)) {
  const path = match[1];
  if (path.startsWith("data:")) continue;
  if (/^(?:https?:)?\/\//.test(path))
    throw new Error("외부 에셋은 미리보기에 포함할 수 없어요.");
  if (assets.has(path)) continue;
  const absolute = assetPath(path, dirname(cssPath));
  const mime = {
    ".woff2": "font/woff2",
    ".woff": "font/woff",
    ".webp": "image/webp",
  }[extname(absolute)];
  if (!mime) throw new Error(`지원하지 않는 에셋 형식: ${extname(absolute)}`);
  const bytes = await readFile(absolute);
  assets.set(path, `data:${mime};base64,${bytes.toString("base64")}`);
}
css = css.replace(/url\(["']?([^"')]+)["']?\)/g, (original, path) =>
  assets.has(path) ? `url("${assets.get(path)}")` : original,
);
html = html.replace(
  scripts[0][0],
  () =>
    `<script type="module">${javascript.replace(/<\/script/gi, "<\\/script")}</script>`,
);
html = html.replace(
  styles[0][0],
  () => `<style>${css.replace(/<\/style/gi, "<\\/style")}</style>`,
);
const output = resolve(root, "preview/allddeul-detective.html");
await mkdir(dirname(output), { recursive: true });
await writeFile(output, html);
console.log(
  `미리보기 HTML: ${output} (${Buffer.byteLength(html).toLocaleString("ko-KR")}바이트)`,
);

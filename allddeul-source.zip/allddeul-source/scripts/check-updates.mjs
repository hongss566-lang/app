import { chromium } from "playwright";
import AxeBuilder from "@axe-core/playwright";
import fs from "node:fs/promises";
import { resolve } from "node:path";
const root = process.cwd();
const url = process.env.APP_URL || "http://127.0.0.1:3000";
const browser = await chromium.launch({
  executablePath: "/usr/bin/chromium",
  args: ["--no-sandbox"],
});
const context = await browser.newContext({
  viewport: { width: 1024, height: 1000 },
  reducedMotion: "reduce",
});
const page = await context.newPage();
page.setDefaultTimeout(10000);
const errors = [],
  checks = [],
  layouts = [];
const externalRequests = [];
if (process.env.OFFLINE_HTML === "1") {
  await context.route("**/*", (route) => {
    if (route.request().isNavigationRequest() && route.request().url() === url)
      return route.continue();
    externalRequests.push(route.request().url());
    return route.abort();
  });
}
page.on("pageerror", (e) => errors.push(e.message));
const button = (name, exact = true) =>
  page.getByRole("button", { name, exact });
const stage = (name) =>
  page
    .getByRole("navigation", { name: "사건 진행 단계" })
    .getByRole("button", { name: new RegExp(name) })
    .click();
const mission = (index) =>
  page
    .getByRole("navigation", { name: "이번 장의 미션" })
    .getByRole("button")
    .nth(index)
    .click();
const read = () =>
  page.evaluate(() =>
    JSON.parse(localStorage.getItem("allddeul-detective:v1")),
  );
const load = async (data) => {
  await page.goto(url);
  await page.evaluate(
    (data) =>
      localStorage.setItem("allddeul-detective:v1", JSON.stringify(data)),
    data,
  );
  await page.reload();
  await page
    .getByRole("navigation", { name: "사건 파일 1장부터 8장" })
    .getByRole("button", { name: new RegExp(`^${data.currentChapter}장 `) })
    .click();
};
const shot = (name) =>
  page.screenshot({
    path: resolve(root, `test-results/screenshots/update-${name}.png`),
    fullPage: true,
  });
const checkLayout = async (name) => {
  await page.evaluate(() => document.fonts.ready);
  const dimensions = await page.evaluate(() => ({
    viewport: innerWidth,
    width: document.documentElement.scrollWidth,
  }));
  const result = await new AxeBuilder({ page })
    .withTags(["wcag2a", "wcag2aa", "wcag21aa"])
    .analyze();
  const violations = result.violations.map((v) => ({
    id: v.id,
    nodes: v.nodes.map((n) => ({ html: n.html, summary: n.failureSummary })),
  }));
  layouts.push({ name, dimensions, violations });
  await shot(name);
  if (dimensions.width > dimensions.viewport || violations.length)
    throw new Error(JSON.stringify(layouts.at(-1)));
};
try {
  const seed = JSON.parse(
    await fs.readFile(
      resolve(root, "test-results/student-solo-state.json"),
      "utf8",
    ),
  );
  // 실제로 막혔던 수첩: 음료만 완료, 선택 미션 165.33·240, 우유·주스·봉투 미완료.
  const blocked = structuredClone(seed);
  blocked.currentChapter = 3;
  blocked.progress.solo.completedChapters = [1, 2];
  blocked.progress.solo.badges = blocked.progress.solo.badges.slice(0, 2);
  const n = blocked.learning.solo;
  n.calculations = { drink: n.calculations.drink };
  n.selectedCase = "drink";
  n.shelfPrices = ["165.33", "240"];
  delete n.shelfWork;
  n.steps[3] = 1;
  n.missionPages[3] = 2;
  blocked.envelopeRevealed = false;
  await load(blocked);
  await page
    .getByRole("heading", { name: "선택 미션 · 100mL당 가격으로 바꿔 보기" })
    .waitFor();
  if (await page.getByText(/÷ 10 =/).count())
    throw new Error("정답을 확인 전에 노출함");
  if (!(await button("사건 해결로 이동").isEnabled()))
    throw new Error("마지막 미션 버튼 비활성");
  await button("건너뛰고 사건 해결로 이동").click();
  await button(/미완료 · 우유 계산/, false).waitFor();
  await button(/미완료 · 주스 계산/, false).waitFor();
  await button("미완료 · 예측 봉투 열기").waitFor();
  if (await button("사건 해결하고 배지 받기").isEnabled())
    throw new Error("필수 활동을 건너뛰어 배지 획득");
  checks.push(
    "blocked-old-notebook-shows-three-specific-links-and-optional-skip",
  );
  for (const [caseName, amounts, quotients, rounded, choice] of [
    ["우유", ["0.9", "2.3"], ["2944.44", "2600"], ["2944", "2600"], "B"],
    ["주스", ["1", "0.25"], ["3200", "3600"], ["3200", "3600"], "A"],
  ]) {
    await button(new RegExp(`미완료 · ${caseName} 계산`), false).click();
    for (const [step, values] of [amounts, quotients, rounded].entries()) {
      for (let i = 0; i < 2; i++)
        await page
          .getByLabel(
            `상품 ${i ? "B" : "A"} ${step === 0 ? "양 (L)" : step === 1 ? "나눗셈의 몫" : "어림한 가격 (원)"}`,
            { exact: true },
          )
          .fill(values[i]);
      await button("이 단계 확인하기").click();
    }
    const table = page.getByRole("table");
    for (const value of [...quotients, ...rounded])
      if (!(await table.innerText()).includes(value))
        throw new Error(`계산 기록 누락: ${value}`);
    await shot(`evidence-${caseName}`);
    await page
      .getByRole("group", { name: "더 저렴한 상품" })
      .getByRole("button", { name: choice, exact: true })
      .click();
    await button("이 단계 확인하기").click();
    await stage("사건 해결");
  }
  await button("미완료 · 예측 봉투 열기").click();
  await button("예측 봉투 열기").click();
  await mission(0);
  await button("음료 · 해결").click();
  await mission(2);
  await page
    .getByLabel("상품 A의 100mL당 가격 (원)", { exact: true })
    .fill("165");
  await page
    .getByLabel("상품 B의 100mL당 가격 (원)", { exact: true })
    .fill("240");
  await button("100mL당 가격 확인하기").click();
  if ((await page.getByText(/맞았어요!/).count()) !== 2)
    throw new Error("100mL 반올림 판정 오류");
  await mission(0);
  await button("우유 · 해결").click();
  await mission(2);
  if (
    await page
      .getByLabel("상품 A의 100mL당 가격 (원)", { exact: true })
      .inputValue()
  )
    throw new Error("다른 상품의 답이 섞임");
  await button("사건 해결로 이동").click();
  await button("사건 해결하고 배지 받기").click();
  await button("다음 사건 · 4장").click();
  await page
    .getByRole("heading", { name: "탐정기 설계도", exact: true })
    .waitFor();
  checks.push(
    "resume-milk-juice-envelope-compare-keeps-records-and-unlock-outline",
  );
  // 최종 게임: 실제 이동·충돌·오답 재도전·중간 복원·클리어·중복 보상 방지.
  seed.currentChapter = 8;
  seed.learning.solo.steps[8] = 2;
  delete seed.learning.solo.marketGame;
  await load(seed);
  await button("마지막 모험 시작하기").click();
  await page
    .getByRole("group", { name: "움직일 탐정 고르기" })
    .getByRole("button", { name: "모아", exact: true })
    .click();
  const score = (state) =>
    state.scores
      .filter((e) => e.participantId === "solo")
      .reduce((sum, e) => sum + e.delta, 0);
  const before = score(await read());
  await button("아래로 이동").click();
  if ((await read()).learning.solo.marketGame.y !== 5)
    throw new Error("벽 충돌 실패");
  const map = [
    "#########",
    "#.......#",
    "#.#...#.#",
    "#.......#",
    "#.#...#.#",
    "#.......#",
    "#########",
  ];
  const quests = [
    { id: "water", x: 1, y: 1, who: "모아", option: "12컵" },
    { id: "milk", x: 7, y: 1, who: "올리", option: "0.75L" },
    { id: "juice", x: 1, y: 3, who: "루미", option: "상품 B" },
    { id: "waste", x: 7, y: 3, who: "두리", option: "1L 우유" },
  ];
  async function walk(goal, keyboard = false) {
    const pos = (await read()).learning.solo.marketGame;
    const queue = [{ x: pos.x, y: pos.y, path: [] }],
      seen = new Set([`${pos.x},${pos.y}`]);
    for (let i = 0; i < queue.length; i++) {
      const node = queue[i];
      if (goal(node)) {
        for (const [dx, dy] of node.path) {
          if (keyboard) {
            const board = page.getByRole("group", { name: /^반짝시장 지도/ });
            await board.focus();
            await board.press(
              dx === 1
                ? "ArrowRight"
                : dx === -1
                  ? "ArrowLeft"
                  : dy === 1
                    ? "ArrowDown"
                    : "ArrowUp",
            );
          } else
            await button(
              dx === 1
                ? "오른쪽으로 이동"
                : dx === -1
                  ? "왼쪽으로 이동"
                  : dy === 1
                    ? "아래로 이동"
                    : "위로 이동",
            ).click();
        }
        return;
      }
      for (const [dx, dy] of [
        [0, -1],
        [0, 1],
        [1, 0],
        [-1, 0],
      ]) {
        const x = node.x + dx,
          y = node.y + dy,
          key = `${x},${y}`;
        if (
          !seen.has(key) &&
          map[y]?.[x] === "." &&
          !quests.some((q) => q.x === x && q.y === y)
        ) {
          seen.add(key);
          queue.push({ x, y, path: [...node.path, [dx, dy]] });
        }
      }
    }
    throw new Error("목표까지 경로 없음");
  }
  await walk((p) => p.x === 4 && p.y === 2, true);
  if (await button(/단서를 더 모아 주세요/, false).isEnabled())
    throw new Error("단서 없이 문 열기 가능");
  for (const [index, q] of quests.entries()) {
    await walk(
      (p) => Math.abs(p.x - q.x) + Math.abs(p.y - q.y) === 1,
      index % 2 === 0,
    );
    await button(`${q.who}와 대화하기`).click();
    const answers = page.getByRole("group", { name: "모험 퀴즈 답 고르기" });
    if (index === 0) {
      await answers.getByRole("button", { name: "3컵", exact: true }).click();
      await button("모험 퀴즈 확인하기").click();
      await page.getByText(/다시 생각해 봐요. 힌트를 보고/).waitFor();
    }
    await answers.getByRole("button", { name: q.option, exact: true }).click();
    await button("모험 퀴즈 확인하기").click();
    await button("시장으로 돌아가기").click();
    if (index === 0) {
      const saved = (await read()).learning.solo.marketGame;
      await page.reload();
      await page
        .getByRole("navigation", { name: "사건 파일 1장부터 8장" })
        .getByRole("button", { name: /^8장 / })
        .click();
      const restored = (await read()).learning.solo.marketGame;
      if (JSON.stringify(saved) !== JSON.stringify(restored))
        throw new Error("모험 복원 오류");
      await button("모아와 대화하기").click();
      await page.getByText(/열두 컵을 채울 수 있어/).waitFor();
      await button("시장으로 돌아가기").click();
    }
  }
  await walk((p) => p.x === 4 && p.y === 2);
  await button("네 단서로 축제 문 열기").click();
  await page
    .getByRole("heading", { name: "축제 수호 탐정 배지 획득!" })
    .waitFor();
  if (score(await read()) - before !== 60)
    throw new Error("게임 보상 중복 또는 누락");
  await page.reload();
  await page
    .getByRole("navigation", { name: "사건 파일 1장부터 8장" })
    .getByRole("button", { name: /^8장 / })
    .click();
  await page
    .getByRole("heading", { name: "축제 수호 탐정 배지 획득!" })
    .waitFor();
  if (score(await read()) - before !== 60)
    throw new Error("새로고침 보상 중복");
  checks.push(
    "finale-four-quizzes-collision-keyboard-touch-buttons-retry-restore-unique-rewards",
  );
  for (const width of [390, 800, 1920]) {
    await page.setViewportSize({ width, height: 1100 });
    await checkLayout(`finale-${width}`);
  }
  await page.getByLabel("화면 색").selectOption("dark");
  await page.setViewportSize({ width: 800, height: 1100 });
  await checkLayout("finale-dark");
  // 최종 퀴즈·분수 입력·L눈금도 작은 화면과 다크 모드에서 점검한다.
  await button("출발 광장으로 돌아가기").click();
  await walk((p) => p.x === 2 && p.y === 1);
  await button("모아와 대화하기").click();
  await checkLayout("finale-quiz-dark");
  seed.currentChapter = 2;
  seed.learning.solo.steps[2] = 1;
  seed.learning.solo.missionPages[2] = 1;
  seed.learning.solo.fractionIndex = 0;
  await load(seed);
  await page.getByLabel("화면 색").selectOption("light");
  await checkLayout("litre-markers-800");
  const water = page.getByRole("img", { name: /12칸 중/ });
  const geometry = await water.evaluate((el) => {
    const waterRect = el.getBoundingClientRect();
    const marks = [
      ...el.parentElement.querySelectorAll('[class*="litreLines"] > span'),
    ].map((el) => el.getBoundingClientRect().x);
    const cups = [...el.children].map((el) => el.getBoundingClientRect().right);
    return { marks, cups, start: waterRect.left, width: waterRect.width };
  });
  for (let i = 0; i < geometry.marks.length; i++)
    if (Math.abs(geometry.marks[i] + 2 - geometry.cups[i * 2 + 1]) > 2)
      throw new Error("1L 눈금이 두 컵 경계와 다름");
  await page.setViewportSize({ width: 390, height: 1100 });
  await checkLayout("litre-markers-390");
  checks.push("six-litres-twelve-cups-one-litre-line-every-two-cups");
  if (errors.length || externalRequests.length)
    throw new Error(JSON.stringify({ errors, externalRequests }));
  await fs.writeFile(
    resolve(
      root,
      process.env.OFFLINE_HTML === "1"
        ? "test-results/updates-standalone-report.json"
        : "test-results/updates-report.json",
    ),
    JSON.stringify(
      { source: url, checks, layouts, errors, externalRequests },
      null,
      2,
    ),
  );
  console.log(JSON.stringify({ checks, layouts: layouts.length, errors }));
} catch (e) {
  await shot("failure");
  throw e;
} finally {
  await browser.close();
}

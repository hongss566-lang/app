import { chromium } from "playwright";
import { existsSync } from "node:fs";
import AxeBuilder from "@axe-core/playwright";
import fs from "node:fs/promises";
import { resolve } from "node:path";
const root = process.cwd(),
  url = process.env.APP_URL || "http://127.0.0.1:3000";
const browser = await chromium.launch({
  executablePath:
    process.env.CHROMIUM_EXECUTABLE ||
    (existsSync("/usr/bin/chromium") ? "/usr/bin/chromium" : undefined),
  args: ["--no-sandbox"],
});
const context = await browser.newContext({
  viewport: { width: 1024, height: 1100 },
  reducedMotion: "reduce",
  hasTouch: true,
});
const page = await context.newPage(),
  session = await context.newCDPSession(page);
page.setDefaultTimeout(10000);
const errors = [],
  checks = [],
  layouts = [];
page.on("pageerror", (e) => errors.push(e.message));
const externalRequests = [];
if (process.env.OFFLINE_HTML === "1")
  await context.route("**/*", (route) => {
    if (route.request().isNavigationRequest() && route.request().url() === url)
      return route.continue();
    externalRequests.push(route.request().url());
    return route.abort();
  });
const button = (name, exact = true) =>
  page.getByRole("button", { name, exact });
const read = () =>
  page.evaluate(() =>
    JSON.parse(localStorage.getItem("allddeul-detective:v1")),
  );
const chapter = async (id) => {
  await page
    .getByRole("navigation", { name: "사건 파일 1장부터 8장" })
    .getByRole("button", { name: new RegExp(`^${id}장 `) })
    .click();
  await page
    .getByRole("navigation", { name: "사건 진행 단계" })
    .getByRole("button", { name: /수사하기/ })
    .click();
};
const mission = (index) =>
  page
    .getByRole("navigation", { name: "이번 장의 미션" })
    .getByRole("button")
    .nth(index)
    .click();
const assert = (condition, text) => {
  if (!condition) throw new Error(text);
};
const capture = (name) =>
  page.screenshot({
    path: resolve(root, `test-results/screenshots/refinements-${name}.png`),
    fullPage: true,
  });
async function layout(name) {
  await page.evaluate(() => document.fonts.ready);
  const dimensions = await page.evaluate(() => ({
    width: innerWidth,
    content: document.documentElement.scrollWidth,
  }));
  const result = await new AxeBuilder({ page })
    .withTags(["wcag2a", "wcag2aa", "wcag21aa"])
    .analyze();
  const violations = result.violations.map((v) => ({
    id: v.id,
    nodes: v.nodes.map((n) => ({ html: n.html, reason: n.failureSummary })),
  }));
  layouts.push({ name, dimensions, violations });
  await capture(name);
  assert(
    dimensions.content <= dimensions.width && violations.length === 0,
    JSON.stringify(layouts.at(-1)),
  );
}
async function drag(from, to, touch = false) {
  const first = page.locator(`[data-flow-index="${from}"]`);
  await first.evaluate((el) => el.scrollIntoView({ block: "center" }));
  const a = await first.boundingBox(),
    b = await page.locator(`[data-flow-index="${to}"]`).boundingBox();
  const sx = a.x + a.width * 0.3,
    sy = a.y + a.height * 0.5,
    ex = b.x + b.width * 0.3,
    ey = b.y + b.height * 0.5;
  if (touch) {
    const point = (x, y) => ({ x, y, id: 1, radiusX: 4, radiusY: 4, force: 1 });
    await session.send("Input.dispatchTouchEvent", {
      type: "touchStart",
      touchPoints: [point(sx, sy)],
    });
    for (let i = 1; i <= 12; i++)
      await session.send("Input.dispatchTouchEvent", {
        type: "touchMove",
        touchPoints: [
          point(sx + ((ex - sx) * i) / 12, sy + ((ey - sy) * i) / 12),
        ],
      });
    assert(
      (await page.locator('[data-drop="true"]').count()) > 0,
      "터치 놓기 위치가 보이지 않음",
    );
    await session.send("Input.dispatchTouchEvent", {
      type: "touchEnd",
      touchPoints: [],
    });
  } else {
    await page.mouse.move(sx, sy);
    await page.mouse.down();
    await page.mouse.move(ex, ey, { steps: 12 });
    assert(
      (await page.locator('[data-drop="true"]').count()) > 0,
      "마우스 놓기 위치가 보이지 않음",
    );
    await page.mouse.up();
  }
}
const pixels = () =>
  page.locator("canvas").evaluate((el) => {
    const data = el
      .getContext("2d")
      .getImageData(0, 0, el.width, el.height).data;
    let count = 0;
    for (let i = 3; i < data.length; i += 4) if (data[i] > 10) count++;
    return count;
  });
async function stroke(touch = false) {
  const c = page.locator("canvas");
  await c.scrollIntoViewIfNeeded();
  const r = await c.boundingBox();
  const a = { x: r.x + r.width * 0.2, y: r.y + r.height * 0.45 },
    b = { x: r.x + r.width * 0.75, y: r.y + r.height * 0.45 };
  if (touch) {
    await session.send("Input.dispatchTouchEvent", {
      type: "touchStart",
      touchPoints: [{ ...a, id: 1 }],
    });
    for (let i = 1; i <= 15; i++)
      await session.send("Input.dispatchTouchEvent", {
        type: "touchMove",
        touchPoints: [{ x: a.x + ((b.x - a.x) * i) / 15, y: a.y, id: 1 }],
      });
    await session.send("Input.dispatchTouchEvent", {
      type: "touchEnd",
      touchPoints: [],
    });
  } else {
    await page.mouse.move(a.x, a.y);
    await page.mouse.down();
    await page.mouse.move(b.x, b.y, { steps: 15 });
    await page.mouse.up();
  }
}
try {
  const seed = JSON.parse(
    await fs.readFile(
      resolve(root, "test-results/student-group-state.json"),
      "utf8",
    ),
  );
  seed.currentChapter = 4;
  seed.learning.g1.steps[4] = 1;
  seed.learning.g1.missionPages[4] = 0;
  seed.learning.g1.outline.order = ["판단", "입력", "시각화", "계산"];
  seed.learning.g1.outline.flowVerified = false;
  seed.learning.g1.bugs = {};
  delete seed.learning.g1.scratch;
  delete seed.learning.g1.reportDrafts;
  await page.goto(url);
  await page.evaluate(
    (s) => localStorage.setItem("allddeul-detective:v1", JSON.stringify(s)),
    seed,
  );
  await page.reload();
  await chapter(4);
  await drag(0, 1);
  await drag(3, 1, true);
  assert(
    (await read()).learning.g1.outline.order.join() === "입력,계산,판단,시각화",
    "드래그 순서 오류",
  );
  await button("흐름 확인하기").click();
  assert(
    (await read()).learning.g1.outline.flowVerified,
    "흐름 정답 검증 실패",
  );
  await mission(2);
  assert(
    !(
      await page.getByLabel("알뜰 선택은", { exact: true }).textContent()
    ).includes("어림하기 전"),
    "선택 문구가 남아 있음",
  );
  checks.push("mouse-and-real-touch-drag-with-drop-indicator-and-renumber");
  await chapter(6);
  await mission(1);
  for (let i = 0; i < 6; i++) {
    await page
      .getByRole("navigation", { name: "버그 터널 기록 선택" })
      .getByRole("button")
      .nth(i)
      .click();
    const process = page.getByRole("list", {
      name: `기록 ${i + 1}의 AI 계산 과정`,
    });
    await process.waitFor();
    assert(
      (await process.getByRole("listitem").count()) === 3,
      "계산 단계 누락",
    );
    const causes = ["unit", "", "reverse", "multiply", "rounding", ""],
      steps = [2, 0, 2, 2, 3, 0];
    if (causes[i]) {
      await button("버그예요").click();
      await process
        .locator("..")
        .getByLabel("고칠 계산 단계")
        .selectOption(String(steps[i]));
      if (i === 0) {
        await process
          .locator("..")
          .getByLabel("고칠 계산 단계")
          .selectOption("");
        assert(
          !(await read()).learning.g1.bugs.unit.step,
          "빈 단계 선택을 잘못 저장함",
        );
        await process
          .locator("..")
          .getByLabel("고칠 계산 단계")
          .selectOption("2");
      }
      await process
        .locator("..")
        .getByLabel("버그의 원인")
        .selectOption(causes[i]);
    } else await button("맞아요").click();
    await button("판정과 원인 확인하기").click();
    assert(
      (await read()).learning.g1.bugs[
        ["unit", "right-a", "reverse", "multiply", "rounding", "right-b"][i]
      ].solved,
      "버그 기록 채점 실패",
    );
  }
  checks.push(
    "all-six-bug-records-show-calculation-before-grading-and-highlight-corrected-step",
  );
  await mission(2);
  assert(
    (await page
      .getByRole("heading", { name: "달빛 보리차", exact: true })
      .count()) > 0,
    "손계산 상품 그림 누락",
  );
  assert(
    !(await page.locator("main").innerText()).includes("위 덜어내기 그림"),
    "없는 그림을 가리키는 안내",
  );
  await button("계산 노트 열기").click();
  await stroke(true);
  const ink = await pixels();
  assert(ink > 100, "태블릿 필기 누락");
  await button("지우개").click();
  await stroke();
  assert((await pixels()) < ink * 0.4, "지우개가 필기를 지우지 않음");
  await button("실행 취소").click();
  assert((await pixels()) >= ink * 0.95, "지우개 실행 취소 실패");
  await button("전체 지우기").click();
  assert((await pixels()) === 0, "전체 지우기 실패");
  await button("실행 취소").click();
  assert((await pixels()) > 100, "전체 지우기 실행 취소 실패");
  await page.getByText("글자로 메모하기", { exact: true }).click();
  await page.getByLabel("계산 메모", { exact: true }).fill("나의 계산 기록");
  const savedInk = (await read()).learning.g1.scratch[6];
  await button("계산 노트 닫기").click();
  await mission(1);
  await button("계산 노트 열기").click();
  assert(
    JSON.stringify((await read()).learning.g1.scratch[6]) ===
      JSON.stringify(savedInk),
    "미션 이동 필기 보존 실패",
  );
  await page.setViewportSize({ width: 800, height: 1100 });
  await layout("notes-tablet");
  await page.setViewportSize({ width: 390, height: 1000 });
  await layout("notes-mobile");
  await button("계산 노트 닫기").click();
  await page.getByLabel("활동할 모둠").selectOption("g2");
  await button("계산 노트 열기").click();
  assert((await pixels()) === 0, "다른 모둠 필기가 섞임");
  await button("계산 노트 닫기").click();
  await page.getByLabel("활동할 모둠").selectOption("g1");
  await chapter(6);
  await button("계산 노트 열기").click();
  assert((await pixels()) > 100, "원래 모둠 필기 복원 실패");
  await button("계산 노트 닫기").click();
  await page.reload();
  await chapter(6);
  await button("계산 노트 열기").click();
  assert((await pixels()) > 100, "새로고침 필기 복원 실패");
  await button("계산 노트 닫기").click();
  checks.push(
    "mouse-touch-ink-eraser-undo-clear-undo-resize-reopen-reload-group-isolation",
  );
  await page.setViewportSize({ width: 800, height: 1100 });
  await chapter(7);
  await mission(0);
  const cards = page.getByRole("group", { name: "소개할 사건 고르기" });
  await cards.getByRole("button", { name: /^우유 사건/ }).click();
  await page
    .getByLabel("결론 문장", { exact: true })
    .fill("내가 고친 우유 사건 설명이에요.");
  await cards.getByRole("button", { name: /^우유 사건/ }).click();
  assert(
    (await page.getByLabel("결론 문장", { exact: true }).inputValue()) ===
      "내가 고친 우유 사건 설명이에요.",
    "같은 사건 카드가 문장을 덮어씀",
  );
  await cards.getByRole("button", { name: /^주스 사건/ }).click();
  await cards.getByRole("button", { name: /^우유 사건/ }).click();
  assert(
    (await page.getByLabel("결론 문장", { exact: true }).inputValue()) ===
      "내가 고친 우유 사건 설명이에요.",
    "사건 변경으로 문장을 잃음",
  );
  await button("보고서 봉인하기").click();
  await mission(1);
  assert(
    (await page
      .getByRole("heading", { name: "우유 900mL", exact: true })
      .count()) > 0,
    "확인 문제 상품 카드 누락",
  );
  assert(
    (await page
      .getByText("선택 활동 · 실제 친구에게도 의견 전하기")
      .count()) === 0,
    "학생 동료 평가가 남아 있음",
  );
  checks.push(
    "automatic-case-report-preserves-edits-and-student-jury-shows-evidence",
  );
  for (const width of [390, 800, 1920]) {
    await page.setViewportSize({ width, height: width === 1920 ? 1080 : 1100 });
    await mission(0);
    await layout(`report-${width}`);
    await chapter(8);
    await mission(0);
    await page
      .getByRole("slider", { name: "실제로 마신 우유의 양" })
      .fill("2.18");
    assert(
      (await page.locator("main").innerText()).includes("0.12L"),
      "남길 양 계산 오류",
    );
    await layout(`milk-${width}`);
    await page
      .getByRole("navigation", { name: "사건 진행 단계" })
      .getByRole("button", { name: /사건 해결/ })
      .click();
    await layout(`certificate-${width}`);
    if (width !== 1920) await chapter(7);
  }
  checks.push(
    "milk-consumption-picture-consistent-labels-and-designed-certificate",
  );
  await page.setViewportSize({ width: 1280, height: 1000 });
  await button("마지막 모험 시작하기").click();
  assert(
    (await page
      .getByRole("navigation", { name: "사건 파일 1장부터 8장" })
      .count()) === 0,
    "게임이 별도 화면이 아님",
  );
  await page.emulateMedia({ reducedMotion: "no-preference" });
  const board = page.getByRole("group", { name: /^반짝시장 지도/ });
  await board.focus();
  await page.keyboard.down("ArrowUp");
  await page.waitForTimeout(230);
  assert(
    (await page.locator('[data-walking="true"]').count()) > 0,
    "걷기 상태 없음",
  );
  const animation = await page
    .locator('[data-walking="true"] [class*="leftLeg"]')
    .evaluate((el) => getComputedStyle(el).animationName);
  assert(animation !== "none", "팔·다리 걷기 애니메이션 없음");
  await page.keyboard.up("ArrowUp");
  await page.waitForTimeout(250);
  await button("출발 광장으로 돌아가기").click();
  await page.emulateMedia({ reducedMotion: "reduce" });
  for (const width of [390, 800, 1920]) {
    await page.setViewportSize({ width, height: width === 1920 ? 1080 : 1100 });
    await layout(`game-${width}`);
  }
  await page.setViewportSize({ width: 800, height: 1100 });
  // 모아에게 가는 실제 경로: 위 네 번, 왼쪽 두 번. NPC가 있는 칸까지 들어가지는 않는다.
  for (let i = 0; i < 4; i++) {
    await board.focus();
    await board.press("ArrowUp");
  }
  for (let i = 0; i < 2; i++) {
    await board.focus();
    await board.press("ArrowLeft");
  }
  await button("모아와 대화하기").click();
  const popup = page.getByRole("dialog", { name: "분수 샘터 퀴즈" });
  await popup.waitFor();
  const pos = (await read()).learning.g1.marketGame;
  await page.keyboard.press("ArrowRight");
  assert(
    JSON.stringify((await read()).learning.g1.marketGame) ===
      JSON.stringify(pos),
    "퀴즈 중 캐릭터 이동",
  );
  await button("계산 노트 열기").click();
  await stroke();
  assert(
    (await read()).learning.g1.scratch[8].strokes.length > 0,
    "퀴즈 노트 저장 실패",
  );
  await button("계산 노트 닫기").click();
  await layout("game-quiz-tablet");
  await button("시장으로 돌아가기").click();
  await button("← 수료증으로 돌아가기").click();
  await page.getByLabel("화면 색").selectOption("dark");
  await button("마지막 모험 시작하기").click();
  await button("모아와 대화하기").click();
  await layout("game-quiz-dark");
  await page.keyboard.press("Escape");
  await button("← 수료증으로 돌아가기").click();
  await layout("certificate-dark");
  checks.push(
    "dedicated-game-screen-walking-limbs-popup-pauses-movement-and-in-popup-notes",
  );
  assert(
    errors.length === 0 && externalRequests.length === 0,
    JSON.stringify({ errors, externalRequests }),
  );
  await fs.writeFile(
    resolve(
      root,
      process.env.OFFLINE_HTML === "1"
        ? "test-results/refinements-standalone-report.json"
        : "test-results/refinements-report.json",
    ),
    JSON.stringify(
      { source: url, checks, layouts, errors, externalRequests },
      null,
      2,
    ),
  );
  console.log(JSON.stringify({ checks, layouts: layouts.length, errors }));
} catch (error) {
  await capture("failure");
  throw error;
} finally {
  await browser.close();
}

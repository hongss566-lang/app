import { chromium } from "playwright";
import { existsSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { spawn } from "node:child_process";
import AxeBuilder from "@axe-core/playwright";
import fs from "node:fs/promises";
const projectRoot = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const outputDir = resolve(projectRoot, "test-results");
const baseURL = process.env.APP_URL || "http://127.0.0.1:4178";
let server;
if (!process.env.APP_URL) {
  server = spawn(
    process.execPath,
    [
      resolve(projectRoot, "node_modules/vite/bin/vite.js"),
      "--host",
      "127.0.0.1",
      "--port",
      "4178",
      "--strictPort",
    ],
    { cwd: projectRoot, stdio: ["ignore", "pipe", "pipe"] },
  );
  let startupLog = "";
  server.stdout.on("data", (chunk) => (startupLog += chunk));
  server.stderr.on("data", (chunk) => (startupLog += chunk));
  process.on("exit", () => server?.kill());
  let ready = false;
  for (let attempt = 0; attempt < 100; attempt++) {
    if (server.exitCode !== null)
      throw new Error(`검증 서버 시작 실패: ${startupLog}`);
    try {
      const response = await fetch(baseURL);
      if (response.ok && (await response.text()).includes("알뜰 소비 탐정단")) {
        ready = true;
        break;
      }
    } catch {}
    await new Promise((resolve) => setTimeout(resolve, 100));
  }
  if (!ready) throw new Error(`검증 서버가 준비되지 않았어요: ${startupLog}`);
}
const executablePath =
  process.env.CHROMIUM_EXECUTABLE ||
  (existsSync("/usr/bin/chromium") ? "/usr/bin/chromium" : undefined);

const state = JSON.parse(
  await fs.readFile(resolve(outputDir, "full-flow-state.json"), "utf8"),
);
const studentState = JSON.parse(
  await fs.readFile(resolve(outputDir, "student-group-state.json"), "utf8"),
);

const browser = await chromium.launch({
  executablePath,
  args: ["--no-sandbox"],
});
const context = await browser.newContext({ reducedMotion: "reduce" });
await context.addInitScript((data) => {
  if (!localStorage.getItem("allddeul-detective:v1"))
    localStorage.setItem("allddeul-detective:v1", JSON.stringify(data));
}, state);
const page = await context.newPage();
page.setDefaultTimeout(10000);
const errors = [];
const reports = [];
page.on("pageerror", (e) => errors.push(e.message));
await fs.mkdir(resolve(outputDir, "layout"), { recursive: true });
async function check(name, axe = true) {
  await page.evaluate(() => document.fonts.ready);
  const dimensions = await page.evaluate(() => ({
    viewport: innerWidth,
    content: document.documentElement.scrollWidth,
  }));
  const active = await page.evaluateHandle(() => document.activeElement);
  const result = axe
    ? await new AxeBuilder({ page })
        .withTags(["wcag2a", "wcag2aa", "wcag21aa"])
        .analyze()
    : { violations: [] };
  await active.evaluate((element) => {
    if (element instanceof HTMLElement) element.focus({ preventScroll: true });
  });
  await active.dispose();
  const violations = result.violations.map((v) => ({
    id: v.id,
    nodes: v.nodes.map((n) => ({
      html: n.html.slice(0, 180),
      failure: n.failureSummary,
    })),
  }));
  reports.push({ name, dimensions, violations });
  await page.screenshot({
    path: `${outputDir}/layout/${name}.png`,
    fullPage: true,
  });
}
try {
  await page.goto(baseURL);
  // 새 로비·지도·안내 창도 작은 휴대전화부터 수업용 대형 화면까지 확인한다.
  for (const width of [390, 800, 1920]) {
    await page.setViewportSize({ width, height: width === 1920 ? 1080 : 1100 });
    await page.getByRole("button", { name: "모드 바꾸기" }).click();
    await page.getByRole("button", { name: /모둠 모드/ }).click();
    await check(`lobby-group-${width}`);
    if (width >= 800) {
      const button = await page
        .getByRole("button", { name: "탐정 수첩 펼치기" })
        .boundingBox();
      if (!button || button.y + button.height > page.viewportSize().height)
        throw new Error(
          `${width}px 시작 화면에서 시작 버튼이 첫 화면 밖에 있어요.`,
        );
    }
    await page.getByRole("button", { name: /혼자 하기/ }).click();
    await check(`lobby-solo-${width}`);
    await page.getByRole("button", { name: /탐정단 소개/ }).click();
    await check(`detective-roster-${width}`);
    await page.keyboard.press("Escape");
    await page.getByRole("button", { name: "게임 안내", exact: true }).click();
    await check(`game-guide-${width}`);
    await page.keyboard.press("Escape");
    if (
      !(await page
        .getByRole("button", { name: "게임 안내", exact: true })
        .evaluate((e) => e === document.activeElement))
    )
      throw new Error(
        "게임 안내를 닫은 뒤 버튼으로 포커스가 돌아오지 않았어요.",
      );
    await page.getByRole("button", { name: /모둠 모드/ }).click();
    await page.getByRole("button", { name: "탐정 수첩 펼치기" }).click();
    await check(`adventure-map-${width}`);
    await page
      .getByRole("button", { name: "1장 수상한 가격표 · 사건 소개 보기" })
      .click();
    const steps = page.getByRole("navigation", { name: "사건 진행 단계" });
    await steps.getByRole("button", { name: /사건 소개/ }).click();
    await check(`mission-briefing-${width}`);
    await steps.getByRole("button", { name: /사건 해결/ }).click();
    await check(`case-clear-${width}`);
  }
  await page.setViewportSize({ width: 800, height: 1100 });
  await page.getByLabel("화면 색").selectOption("dark");
  await page.getByRole("button", { name: "사건 지도", exact: true }).click();
  await check("adventure-map-dark");
  await page.getByRole("button", { name: "모드 바꾸기" }).click();
  await check("lobby-dark");
  // 학생이 실제로 완료한 수첩으로 모든 미션의 캐릭터 장면과 활동을 확인한다.
  await page.evaluate(
    (data) =>
      localStorage.setItem("allddeul-detective:v1", JSON.stringify(data)),
    studentState,
  );
  await page.reload();
  for (const width of [800, 1920]) {
    await page.setViewportSize({ width, height: width === 800 ? 1100 : 1080 });
    for (let chapter = 1; chapter <= 8; chapter++) {
      await page
        .getByRole("navigation", { name: "사건 파일 1장부터 8장" })
        .getByRole("button", { name: new RegExp(`^${chapter}장 `) })
        .click();
      const stages = page.getByRole("navigation", { name: "사건 진행 단계" });
      if (width === 800) {
        await stages.getByRole("button", { name: /사건 소개/ }).click();
        await check(`student-story-${chapter}`);
      }
      await stages.getByRole("button", { name: /수사하기/ }).click();
      const missions = page
        .getByRole("navigation", { name: "이번 장의 미션" })
        .getByRole("button");
      for (let mission = 0; mission < (await missions.count()); mission++) {
        await missions.nth(mission).click();
        await check(`student-${chapter}-mission-${mission + 1}-${width}`);
      }
    }
  }
  await page.setViewportSize({ width: 390, height: 1100 });
  await check("student-mission-mobile");
  await page.getByLabel("화면 색").selectOption("dark");
  await page.setViewportSize({ width: 800, height: 1100 });
  await check("student-mission-dark");
  // 교사 수업 검증은 원래의 완료된 수첩으로 독립적으로 이어 간다.
  await page.evaluate(
    (data) =>
      localStorage.setItem("allddeul-detective:v1", JSON.stringify(data)),
    state,
  );
  await page.reload();
  for (const width of [800, 1920]) {
    await page.setViewportSize({ width, height: width === 800 ? 1100 : 1080 });
    await page.getByLabel("화면 색").selectOption("light");
    for (let i = 1; i <= 8; i++) {
      await page
        .getByRole("navigation", { name: "사건 파일 1장부터 8장" })
        .getByRole("button", { name: new RegExp(`^${i}장 `) })
        .click();
      await page
        .getByRole("navigation", { name: "사건 진행 단계" })
        .getByRole("button", { name: /수사하기/ })
        .click();
      await check(`chapter-${i}-${width}`);
    }
  }
  await page.setViewportSize({ width: 800, height: 1100 });
  await page.getByRole("button", { name: "교사실", exact: true }).click();
  for (const label of ["1장 예측", "7장 동료 평가", "8장 가족 선택"]) {
    await page.getByRole("button", { name: label, exact: true }).click();
    await check(`teacher-${label.slice(0, 1)}`);
  }
  await page.getByRole("switch", { name: /교사용 정답 보기/ }).check();
  await page
    .getByRole("navigation", { name: "사건 파일 1장부터 8장" })
    .getByRole("button", { name: /^4장 / })
    .click();
  await page
    .getByRole("navigation", { name: "사건 진행 단계" })
    .getByRole("button", { name: /수사하기/ })
    .click();
  await check("teacher-answer-view");
  await page.getByRole("button", { name: "교사실", exact: true }).click();
  await page.getByRole("switch", { name: /교사용 정답 보기/ }).uncheck();
  await page.getByLabel("화면 색").selectOption("dark");
  await check("teacher-dark");
  await page
    .getByRole("navigation", { name: "사건 파일 1장부터 8장" })
    .getByRole("button", { name: /^2장 / })
    .click();
  await page
    .getByRole("navigation", { name: "사건 진행 단계" })
    .getByRole("button", { name: /수사하기/ })
    .click();
  await check("fractions-dark");
  await page.getByLabel("화면 색").selectOption("light");
  await page
    .getByRole("navigation", { name: "사건 파일 1장부터 8장" })
    .getByRole("button", { name: /^7장 / })
    .click();
  await page
    .getByRole("navigation", { name: "사건 진행 단계" })
    .getByRole("button", { name: /수사하기/ })
    .click();
  await page.getByRole("button", { name: "발표 화면 크게 보기" }).click();
  await check("report-presentation");
  await page.keyboard.press("Escape");
  await page
    .getByRole("navigation", { name: "사건 파일 1장부터 8장" })
    .getByRole("button", { name: /^8장 / })
    .click();
  await page
    .getByRole("navigation", { name: "사건 진행 단계" })
    .getByRole("button", { name: /사건 해결/ })
    .click();
  await page.getByRole("button", { name: "수료증 크게 보기" }).click();
  await check("certificate-presentation");
  await fs.writeFile(
    resolve(outputDir, "layout-report.json"),
    JSON.stringify({ reports, errors }, null, 2),
  );
  console.log(
    JSON.stringify(
      {
        screens: reports.length,
        overflow: reports.filter(
          (r) => r.dimensions.content > r.dimensions.viewport,
        ),
        violations: reports.filter((r) => r.violations.length),
        errors,
      },
      null,
      2,
    ),
  );
  if (
    errors.length ||
    reports.some(
      (r) =>
        r.violations.length || r.dimensions.content > r.dimensions.viewport,
    )
  )
    process.exitCode = 1;
} finally {
  await browser.close();
  server?.kill();
}

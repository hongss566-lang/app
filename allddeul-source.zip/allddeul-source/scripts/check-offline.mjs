import { chromium } from "playwright";
import { readFile, writeFile } from "node:fs/promises";
import { existsSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const html = await readFile(
  resolve(root, "preview/allddeul-detective.html"),
  "utf8",
);
const browser = await chromium.launch({
  executablePath:
    process.env.CHROMIUM_EXECUTABLE ||
    (existsSync("/usr/bin/chromium") ? "/usr/bin/chromium" : undefined),
  args: ["--no-sandbox"],
});
const context = await browser.newContext({
  offline: true,
  viewport: { width: 1024, height: 1000 },
  reducedMotion: "reduce",
});
const page = await context.newPage();
page.setDefaultTimeout(10000);
const errors = [],
  requests = [],
  checks = [];
page.on("pageerror", (error) => errors.push(error.message));
page.on("request", (request) => {
  if (/^https?:/.test(request.url())) requests.push(request.url());
});
try {
  await page.setContent(
    '<iframe title="학생용 오프라인 모험" sandbox="allow-scripts" style="width:100%;height:1000px;border:0"></iframe>',
  );
  await page
    .locator("iframe")
    .evaluate((element, content) => (element.srcdoc = content), html);
  const frame = page.frameLocator("iframe");
  await frame.getByText(/이 브라우저에서는 기록을 저장할 수 없어요/).waitFor();
  await frame.getByRole("button", { name: "게임 안내", exact: true }).click();
  await frame
    .getByRole("button", { name: "안내 닫기 (Esc)", exact: true })
    .click();
  await frame.getByLabel("탐정 별명").fill("오프라인 탐정");
  await frame.getByLabel("탐정 별명").press("Enter");
  const nav = frame.getByRole("navigation", { name: "사건 파일 1장부터 8장" });
  await nav.getByRole("button", { name: /^1장 / }).click();
  const appFrame = page
    .frames()
    .find((frame) => frame.url() === "about:srcdoc");
  const images = await appFrame.evaluate(async () => {
    const elements = [
      document.querySelector('[class*="scenery"]'),
      document.querySelector('[class*="portrait"]'),
    ];
    return Promise.all(
      elements.map(async (element) => {
        const url = getComputedStyle(element).backgroundImage.match(
          /url\(["']?([^"')]+)["']?\)/,
        )[1];
        if (!url.startsWith("data:image/webp"))
          throw new Error("게임 그림이 HTML에 포함되지 않았어요.");
        const image = new Image();
        image.src = url;
        await image.decode();
        return { width: image.naturalWidth, height: image.naturalHeight };
      }),
    );
  });
  checks.push("embedded-story-and-character-art");
  await frame
    .getByRole("button", { name: "바로 수사하기", exact: true })
    .click();
  await frame
    .getByRole("group", { name: "예측 카드" })
    .getByRole("button", { name: "A 큰 병", exact: true })
    .click();
  await frame
    .getByRole("button", { name: "예측 봉투 봉인하기", exact: true })
    .click();
  await frame
    .getByRole("navigation", { name: "이번 장의 미션" })
    .getByRole("button")
    .nth(1)
    .click();
  await frame.getByLabel("우유 200mL와 1L", { exact: true }).check();
  await frame
    .getByLabel("내가 찾은 생활 속 비교")
    .fill("크기가 다른 물감 두 통");
  await frame
    .getByRole("button", { name: "생활 속 단서 기록하기", exact: true })
    .click();
  await frame
    .getByRole("navigation", { name: "사건 진행 단계" })
    .getByRole("button", { name: /사건 해결/ })
    .click();
  await frame
    .getByRole("button", { name: "사건 해결하고 배지 받기", exact: true })
    .click();
  await frame
    .getByRole("heading", { name: "사건 해결!", exact: true })
    .waitFor();
  if (
    !(await nav.getByRole("button", { name: /^2장 / }).isEnabled()) ||
    (await nav.getByRole("button", { name: /^3장 / }).isEnabled())
  )
    throw new Error("오프라인 순차 열림 오류");
  checks.push("start-and-first-badge-without-storage-or-forms");
  await nav.getByRole("button", { name: /^2장 / }).click();
  await frame
    .getByRole("navigation", { name: "사건 진행 단계" })
    .getByRole("button", { name: /수사하기/ })
    .click();
  await frame
    .getByRole("group", { name: "도입 예측" })
    .getByRole("button", { name: "12번일 것 같아요" })
    .click();
  await frame
    .getByRole("navigation", { name: "이번 장의 미션" })
    .getByRole("button")
    .nth(1)
    .click();
  await frame.getByLabel("몇 컵만큼 덜어낼까요?", { exact: false }).fill("12");
  await frame
    .getByRole("button", { name: "예측하고 실험하기", exact: true })
    .click();
  for (let cup = 0; cup < 12; cup++)
    await frame.getByRole("button", { name: /한 컵 덜어내기/ }).click();
  await frame.getByRole("button", { name: "다음 실험", exact: true }).waitFor();
  checks.push("interactive-waterway-without-network");
  const report = {
    checks,
    embeddedImages: images,
    storageBlocked: true,
    externalRequests: requests,
    errors,
  };
  if (errors.length || requests.length) throw new Error(JSON.stringify(report));
  await writeFile(
    resolve(root, "test-results/offline-report.json"),
    JSON.stringify(report, null, 2),
  );
  console.log(JSON.stringify(report));
} finally {
  await browser.close();
}

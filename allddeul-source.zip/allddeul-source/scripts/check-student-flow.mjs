import { chromium } from "playwright";
import fs from "node:fs/promises";
import { existsSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { spawn } from "node:child_process";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const output = resolve(root, "test-results");
const url = process.env.APP_URL || "http://127.0.0.1:4179";
let server;
if (!process.env.APP_URL) {
  server = spawn(
    process.execPath,
    [
      resolve(root, "node_modules/vite/bin/vite.js"),
      "--host",
      "127.0.0.1",
      "--port",
      "4179",
      "--strictPort",
    ],
    { cwd: root, stdio: ["ignore", "pipe", "pipe"] },
  );
  let log = "";
  server.stdout.on("data", (chunk) => (log += chunk));
  server.stderr.on("data", (chunk) => (log += chunk));
  process.on("exit", () => server?.kill());
  let ready = false;
  for (let i = 0; i < 100; i++) {
    if (server.exitCode !== null)
      throw new Error(`학생 검증 서버 시작 실패: ${log}`);
    try {
      const response = await fetch(url);
      if (response.ok) {
        ready = true;
        break;
      }
    } catch {}
    await new Promise((resolve) => setTimeout(resolve, 100));
  }
  if (!ready) throw new Error(`학생 검증 서버 준비 실패: ${log}`);
}
const browser = await chromium.launch({
  executablePath:
    process.env.CHROMIUM_EXECUTABLE ||
    (existsSync("/usr/bin/chromium") ? "/usr/bin/chromium" : undefined),
  args: ["--no-sandbox"],
});
await fs.mkdir(resolve(output, "screenshots"), { recursive: true });
const reports = [];
try {
  for (const mode of ["solo", "group"]) {
    const actor = mode === "solo" ? "solo" : "g1";
    const context = await browser.newContext({
      viewport: { width: 1024, height: 900 },
      reducedMotion: "reduce",
    });
    const page = await context.newPage();
    page.setDefaultTimeout(10000);
    const errors = [];
    const checks = [];
    page.on("pageerror", (error) => errors.push(error.message));
    const button = (name, exact = true) =>
      page.getByRole("button", { name, exact });
    const read = () =>
      page.evaluate(() =>
        JSON.parse(localStorage.getItem("allddeul-detective:v1")),
      );
    const nav = () =>
      page.getByRole("navigation", { name: "사건 파일 1장부터 8장" });
    const stage = () =>
      page.getByRole("navigation", { name: "사건 진행 단계" });
    const missions = () =>
      page.getByRole("navigation", { name: "이번 장의 미션" });
    const mission = async (index) =>
      missions().getByRole("button").nth(index).click();
    const open = async (chapter) => {
      await nav()
        .getByRole("button", { name: new RegExp(`^${chapter}장 `) })
        .click();
      await stage()
        .getByRole("button", { name: /수사하기/ })
        .click();
    };
    const capture = async (name) => {
      await page.evaluate(() => document.fonts.ready);
      await page.screenshot({
        path: resolve(output, `screenshots/student-${mode}-${name}.png`),
        fullPage: true,
      });
    };
    const complete = async (chapter) => {
      await stage()
        .getByRole("button", { name: /사건 해결/ })
        .click();
      await button("사건 해결하고 배지 받기").click();
      await page
        .getByRole("heading", { name: "사건 해결!", exact: true })
        .waitFor();
      const state = await read();
      if (!state.progress[actor].completedChapters.includes(chapter))
        throw new Error(`${mode}: ${chapter}장 완료 기록 없음`);
      if (
        chapter < 8 &&
        !(await nav()
          .getByRole("button", { name: new RegExp(`^${chapter + 1}장 `) })
          .isEnabled())
      )
        throw new Error(`${chapter + 1}장 자동 열기 실패`);
      if (
        chapter < 7 &&
        (await nav()
          .getByRole("button", { name: new RegExp(`^${chapter + 2}장 `) })
          .isEnabled())
      )
        throw new Error("앞 사건을 건너뛰어 열림");
      checks.push(`chapter-${chapter}-completed-and-next-unlocked`);
      console.log(`PASS ${mode} chapter ${chapter}`);
    };
    try {
      await page.goto(url);
      if (mode === "group") await button(/모둠 모드/, false).click();
      else await page.getByLabel("탐정 별명").fill("반짝 모험가");
      await button("탐정 수첩 펼치기").click();
      if (await button("교사실").count())
        throw new Error("학생 화면에 교사실이 나타남");
      if (await nav().getByRole("button", { name: /^2장 / }).isEnabled())
        throw new Error("처음부터 2장이 열림");
      await nav().getByRole("button", { name: /^1장 / }).click();
      await button("다음 이야기").click();
      await page.getByText(/난 두리야/).waitFor();
      await button("다음 이야기").click();
      await capture("story-opening");
      await button("수사 시작하기").click();
      await stage()
        .getByRole("button", { name: /사건 해결/ })
        .click();
      if (await button("사건 해결하고 배지 받기").isEnabled())
        throw new Error("미션 전 배지 받기가 열림");
      await stage()
        .getByRole("button", { name: /수사하기/ })
        .click();
      await page
        .getByRole("group", { name: "예측 카드" })
        .getByRole("button", { name: "A 큰 병", exact: true })
        .click();
      await button("예측 봉투 봉인하기").click();
      await mission(1);
      await page.getByLabel("우유 200mL와 1L", { exact: true }).check();
      await page
        .getByLabel("내가 찾은 생활 속 비교")
        .fill("작은 물감과 큰 물감의 가격");
      await button("생활 속 단서 기록하기").click();
      await complete(1);

      await open(2);
      await page
        .getByRole("group", { name: "도입 예측" })
        .getByRole("button", { name: "12번일 것 같아요" })
        .click();
      await mission(1);
      const predictions = ["12", "12", "8", "6", "6", "2 2/3"];
      for (const [index, count] of [12, 12, 8, 6, 6, 3].entries()) {
        if (index === 5) {
          await page
            .getByRole("group", { name: "답의 모양" })
            .getByRole("button", { name: "대분수", exact: true })
            .click();
          await page.getByLabel("자연수 부분", { exact: true }).fill("2");
          await page.getByLabel("분자", { exact: true }).fill("2");
          await page.getByLabel("분모", { exact: true }).fill("3");
        } else
          await page
            .getByLabel("몇 컵만큼 덜어낼까요?", { exact: true })
            .fill(predictions[index]);
        await button("예측하고 실험하기").click();
        for (let cup = 0; cup < count; cup++)
          await button(/한 컵 덜어내기/, false).click();
        if (index < 5) await button("다음 실험").click();
      }
      await capture("fraction-waterway");
      await complete(2);

      await open(3);
      async function calculation(amounts, quotients, rounded, choice) {
        for (const [step, values] of [amounts, quotients, rounded].entries()) {
          for (let index = 0; index < 2; index++)
            await page
              .getByLabel(
                `상품 ${index ? "B" : "A"} ${step === 0 ? "양 (L)" : step === 1 ? "나눗셈의 몫" : "어림한 가격 (원)"}`,
                { exact: true },
              )
              .fill(values[index]);
          await button("이 단계 확인하기").click();
        }
        await page
          .getByRole("group", { name: "더 저렴한 상품" })
          .getByRole("button", { name: choice, exact: true })
          .click();
        await button("이 단계 확인하기").click();
      }
      await calculation(
        ["1.5", "0.5"],
        ["1653.33", "2400"],
        ["1653", "2400"],
        "A",
      );
      await mission(1);
      await button("예측 봉투 열기").click();
      if (
        !(await read()).scores.some(
          (entry) => entry.id === `${actor}:prediction-bonus`,
        )
      )
        throw new Error("예측 보너스 누락");
      await mission(0);
      await button("우유").click();
      await calculation(
        ["0.9", "2.3"],
        ["2944.44", "2600"],
        ["2944", "2600"],
        "B",
      );
      await button("주스").click();
      await calculation(["1", "0.25"], ["3200", "3600"], ["3200", "3600"], "A");
      await complete(3);

      await open(4);
      await button("입력 위로").click();
      await button("계산 위로").click();
      await button("계산 위로").click();
      await button("흐름 확인하기").click();
      for (let index = 0; index < 3; index++)
        await button("다음 흐름 따라가기").click();
      await mission(1);
      await button("판단 규칙 확인하기").click();
      await mission(2);
      await page.getByLabel("상품 입력 칸", { exact: true }).check();
      await page.getByLabel("덜어내기 그림", { exact: true }).check();
      await page
        .getByLabel("mL를 L로 바꾸려면", { exact: true })
        .selectOption("divide1000");
      await page
        .getByLabel("1L당 가격은", { exact: true })
        .selectOption("price/amount");
      await page
        .getByLabel("알뜰 선택은", { exact: true })
        .selectOption("lower");
      await button("설계도 완성하기").click();
      await complete(4);

      await open(5);
      await button("1L당 가격 비교하기").click();
      await mission(1);
      if (await page.getByLabel("선택 도전 · 150초 시간 제한 켜기").isChecked())
        throw new Error("학생에게 시간 제한이 기본 적용됨");
      await button("스피드 라운드 시작").click();
      await button("이 상품을 위 탐정기에 넣기").click();
      await button("1L당 가격 비교하기").click();
      await mission(1);
      for (const [index, choice] of ["A", "B", "A", "똑같다", "A"].entries()) {
        await page
          .getByRole("group", { name: "스피드 라운드 알뜰 선택" })
          .getByRole("button", { name: choice, exact: true })
          .click();
        if (index < 4) await button("다음 상품 쌍").click();
      }
      await capture("cart-race");
      await complete(5);

      await open(6);
      await mission(1);
      const outputs = [
        "B의 1L당 가격은 2원",
        "A의 1L당 가격은 1,653원",
        "A의 1L당 가격은 0원 (몫 0.0006…)",
        "B의 1L당 가격은 600원",
        "A의 1L당 가격은 1,650원",
        "B의 1L당 가격은 2,400원",
      ];
      const causes = ["unit", "", "reverse", "multiply", "rounding", ""];
      for (let index = 0; index < 6; index++) {
        await page
          .getByRole("navigation", { name: "버그 터널 기록 선택" })
          .getByRole("button")
          .nth(index)
          .click();
        const card = page
          .getByRole("heading", {
            name: `AI의 답: ${outputs[index]}`,
            exact: true,
          })
          .locator("..");
        await card
          .getByRole("button", {
            name: causes[index] ? "버그예요" : "맞아요",
            exact: true,
          })
          .click();
        if (causes[index])
          await card.getByLabel("버그의 원인").selectOption(causes[index]);
        await card
          .getByRole("button", { name: "판정과 원인 확인하기" })
          .click();
      }
      await capture("bug-tunnel");
      await mission(2);
      await page.getByLabel("상품 A 손계산 (원)", { exact: true }).fill("1653");
      await page.getByLabel("상품 B 손계산 (원)", { exact: true }).fill("2400");
      await button("손계산 대조하기").click();
      await complete(6);

      await open(7);
      await page.getByLabel("보고서에 사용할 상품").selectOption("tool");
      await button("이 상품으로 보고서 채우기").click();
      await button("사건 보고서 저장하기").click();
      await button("발표 화면 크게 보기").click();
      await page.getByRole("dialog", { name: "사건 보고서 발표" }).waitFor();
      await page.keyboard.press("Escape");
      await mission(1);
      let jury = page.getByRole("group", { name: "탐정단 질문에 답하기" });
      await jury
        .getByRole("button", { name: "전체 가격만", exact: true })
        .click();
      if ((await read()).learning[actor].briefingAnswers?.basis)
        throw new Error("잘못된 질문 답안을 통과시킴");
      await jury
        .getByRole("button", { name: "똑같은 1L", exact: true })
        .click();
      await jury
        .getByRole("button", { name: "A 큰 병 음료", exact: true })
        .click();
      await jury
        .getByRole("button", { name: "어림하기 전 몫을 비교해", exact: true })
        .click();
      if ((await read()).reviews.length)
        throw new Error("학생 모험이 동료 평가에 의존함");
      await capture("character-jury");
      await complete(7);

      await open(8);
      const slider = page.getByRole("slider", {
        name: "실제로 마신 우유의 양",
      });
      await slider.focus();
      for (let index = 0; index < 30; index++)
        await page.keyboard.press("ArrowLeft");
      await page.getByText(/오히려 더 높아요!/).waitFor();
      for (let index = 0; index < 10; index++)
        await page.keyboard.press("ArrowRight");
      await page
        .getByText("이만큼 마신다면 큰 우유의 실제 1L당 가격이 더 낮아요.", {
          exact: true,
        })
        .waitFor();
      await mission(1);
      await page
        .getByRole("group", { name: "가족에게 맞는 상품" })
        .getByRole("button", { name: "B 작은 우유 900mL" })
        .click();
      await page
        .getByLabel("선택한 이유", { exact: true })
        .selectOption("유통기한");
      await button("가족 선택 기록하기").click();
      await mission(2);
      const headlines = [
        "한 병을 사면 한 병 더! 1+1",
        "대용량 특가! 큰 병이 더 저렴할까?",
        "세 병 묶음! 이번에도 광고에 속은 걸까?",
      ];
      for (const [index, headline] of headlines.entries()) {
        const card = page
          .getByRole("heading", { name: headline, exact: true })
          .locator("..");
        if (index === 0)
          for (let hint = 1; hint <= 3; hint++)
            await card
              .getByRole("button", {
                name: new RegExp(`${hint}단계 힌트 보기`),
              })
              .click();
        await card
          .getByRole("group", { name: `${headline} 알뜰 선택` })
          .getByRole("button", { name: index === 2 ? "A" : "B", exact: true })
          .click();
        await card
          .getByRole("button", { name: "광고 속 알뜰 선택 확인하기" })
          .click();
      }
      await mission(3);
      await page
        .getByLabel("앞으로 나는 이렇게 선택할 거예요", { exact: true })
        .fill("단위가격을 확인하고 다 마실 수 있는 만큼만 사요.");
      await button("소비 다짐 남기기").click();
      await complete(8);
      await page
        .getByRole("heading", { name: "수석 탐정 수료증", exact: true })
        .waitFor();
      await capture("festival-certificate");
      let state = await read();
      if (
        state.progress[actor].badges.length !== 8 ||
        state.scores.some((entry) => entry.source === "teacher")
      )
        throw new Error("교사 없는 8개 배지 수료 실패");
      if (
        state.scores.find((entry) => entry.id === `${actor}:c8-ad-one-plus-one`)
          ?.delta !== 4
      )
        throw new Error("힌트 보상 감소 오류");
      const originalScore = state.scores
        .filter((entry) => entry.participantId === actor)
        .reduce((sum, entry) => sum + entry.delta, 0);
      await page.reload();
      await nav().getByRole("button", { name: /^8장 / }).click();
      await page
        .getByRole("heading", { name: "수석 탐정 수료증", exact: true })
        .waitFor();
      state = await read();
      if (
        state.scores
          .filter((entry) => entry.participantId === actor)
          .reduce((sum, entry) => sum + entry.delta, 0) !== originalScore
      )
        throw new Error("새로고침 후 점수 중복");
      if (mode === "group") {
        await page.getByLabel("활동할 모둠").selectOption("g2");
        await page
          .getByRole("heading", {
            name: "2모둠, 수사를 시작하자!",
            exact: true,
          })
          .waitFor();
        if (await nav().getByRole("button", { name: /^8장 / }).isEnabled())
          throw new Error("모둠 변경 뒤 다른 수첩의 잠긴 장으로 진입");
        await page.getByLabel("활동할 모둠").selectOption("g1");
        checks.push("group-switch-respects-own-route");
      }
      if (errors.length) throw new Error(JSON.stringify(errors));
      await fs.writeFile(
        resolve(output, `student-${mode}-state.json`),
        JSON.stringify(state, null, 2),
      );
      reports.push({ mode, checks, badges: 8, originalScore, errors });
    } catch (error) {
      await page.screenshot({
        path: resolve(output, `student-${mode}-failure.png`),
        fullPage: true,
      });
      throw error;
    } finally {
      await context.close();
    }
  }
  await fs.writeFile(
    resolve(output, "student-flow-report.json"),
    JSON.stringify(reports, null, 2),
  );
  console.log(JSON.stringify(reports));
} finally {
  await browser.close();
  server?.kill();
}

import { chromium } from "playwright";
import fs from "node:fs/promises";
import { existsSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { spawn } from "node:child_process";
const projectRoot = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const outputDir = resolve(projectRoot, "test-results");
const baseURL = process.env.APP_URL || "http://127.0.0.1:4178";
let server;
if (!process.env.APP_URL) {
  server = spawn(
    process.execPath,
    [
      resolve(projectRoot, "node_modules/vite/bin/vite.js"),
      "--host",
      "127.0.0.1",
      "--port",
      "4178",
      "--strictPort",
    ],
    { cwd: projectRoot, stdio: ["ignore", "pipe", "pipe"] },
  );
  let startupLog = "";
  server.stdout.on("data", (chunk) => (startupLog += chunk));
  server.stderr.on("data", (chunk) => (startupLog += chunk));
  process.on("exit", () => server?.kill());
  let ready = false;
  for (let attempt = 0; attempt < 100; attempt++) {
    if (server.exitCode !== null)
      throw new Error(`검증 서버 시작 실패: ${startupLog}`);
    try {
      const response = await fetch(baseURL);
      if (response.ok && (await response.text()).includes("알뜰 소비 탐정단")) {
        ready = true;
        break;
      }
    } catch {}
    await new Promise((resolve) => setTimeout(resolve, 100));
  }
  if (!ready) throw new Error(`검증 서버가 준비되지 않았어요: ${startupLog}`);
}
const executablePath =
  process.env.CHROMIUM_EXECUTABLE ||
  (existsSync("/usr/bin/chromium") ? "/usr/bin/chromium" : undefined);

const browser = await chromium.launch({
  executablePath,
  args: ["--no-sandbox"],
});
const context = await browser.newContext({
  viewport: { width: 1280, height: 1000 },
  reducedMotion: "reduce",
});
const page = await context.newPage();
page.setDefaultTimeout(10000);
const errors = [];
page.on("pageerror", (e) => errors.push(e.message));
const checks = [];
await fs.mkdir(resolve(outputDir, "screenshots"), { recursive: true });
const storage = () =>
  page.evaluate(() =>
    JSON.parse(localStorage.getItem("allddeul-detective:v1")),
  );
async function open(chapter) {
  const nav = page.getByRole("navigation", { name: "사건 파일 1장부터 8장" });
  await nav.getByRole("button", { name: new RegExp(`^${chapter}장 `) }).click();
  await page
    .getByRole("navigation", { name: "사건 진행 단계" })
    .getByRole("button", { name: /수사하기/ })
    .click();
}
async function complete(chapter) {
  await page
    .getByRole("navigation", { name: "사건 진행 단계" })
    .getByRole("button", { name: /사건 해결/ })
    .click();
  await page.getByRole("button", { name: "사건 해결하고 배지 받기" }).click();
  await page
    .getByRole("heading", { name: "사건 해결!", exact: true })
    .waitFor();
  const state = await storage();
  if (!state.progress.g1.completedChapters.includes(chapter))
    throw new Error(`Chapter ${chapter} not completed`);
  checks.push(`chapter-${chapter}-completed`);
  console.log(`PASS chapter ${chapter}`);
}
async function capture(name) {
  await page.evaluate(() => document.fonts.ready);
  await page.screenshot({
    path: `${outputDir}/screenshots/${name}.png`,
    fullPage: true,
  });
}
try {
  await page.goto(baseURL);
  await page.getByRole("button", { name: "게임 안내", exact: true }).click();
  await page.getByText("선택: 교사용 수업 도구", { exact: true }).click();
  await page.getByRole("button", { name: "교사실 열기" }).click();
  await page.getByRole("button", { name: "모두 열기", exact: true }).click();
  await page
    .getByRole("group", { name: "예측 카드" })
    .getByRole("button", { name: "A 큰 병", exact: true })
    .click();
  await page.getByRole("button", { name: "예측 봉투 봉인하기" }).click();
  await page.getByRole("button", { name: "다음 모둠", exact: true }).click();
  await page
    .getByRole("group", { name: "예측 카드" })
    .getByRole("button", { name: "B 작은 병", exact: true })
    .click();
  await page.getByRole("button", { name: "예측 봉투 봉인하기" }).click();
  await page
    .getByRole("group", { name: "입력받을 모둠" })
    .getByRole("button", { name: /1모둠/ })
    .click();
  await open(1);
  await page.getByLabel("우유 200mL와 1L", { exact: true }).check();
  await page
    .getByLabel("내가 찾은 생활 속 비교")
    .fill("작은 물감과 큰 물감의 가격");
  await page.getByRole("button", { name: "생활 속 단서 기록하기" }).click();
  await capture("chapter1");
  await complete(1);

  await open(2);
  await page
    .getByRole("group", { name: "도입 예측" })
    .getByRole("button", { name: "12번일 것 같아요" })
    .click();
  const predictions = ["12", "12", "8", "6", "6", "2 2/3"];
  const counts = [12, 12, 8, 6, 6, 3];
  for (let i = 0; i < 6; i++) {
    if (i === 5) {
      await page
        .getByRole("group", { name: "답의 모양" })
        .getByRole("button", { name: "대분수", exact: true })
        .click();
      await page.getByLabel("자연수 부분", { exact: true }).fill("2");
      await page.getByLabel("분자", { exact: true }).fill("2");
      await page.getByLabel("분모", { exact: true }).fill("3");
    } else
      await page
        .getByLabel("몇 컵만큼 덜어낼까요?", { exact: true })
        .fill(predictions[i]);
    await page.getByRole("button", { name: "예측하고 실험하기" }).click();
    for (let j = 0; j < counts[i]; j++)
      await page.getByRole("button", { name: /한 컵 덜어내기/ }).click();
    if (i < 5)
      await page
        .getByRole("button", { name: "다음 실험", exact: true })
        .click();
  }
  await capture("chapter2-partial-cup");
  await complete(2);

  await open(3);
  async function calculation(amounts, quotients, rounded, choice) {
    for (const [index, values] of [amounts, quotients, rounded].entries()) {
      for (let i = 0; i < 2; i++)
        await page
          .getByLabel(
            `상품 ${i === 0 ? "A" : "B"} ${index === 0 ? "양 (L)" : index === 1 ? "나눗셈의 몫" : "어림한 가격 (원)"}`,
            { exact: true },
          )
          .fill(values[i]);
      await page.getByRole("button", { name: "이 단계 확인하기" }).click();
    }
    await page
      .getByRole("group", { name: "더 저렴한 상품" })
      .getByRole("button", { name: choice, exact: true })
      .click();
    await page.getByRole("button", { name: "이 단계 확인하기" }).click();
  }
  await calculation(["1.5", "0.5"], ["1653.33", "2400"], ["1653", "2400"], "A");
  await page.getByRole("button", { name: "예측 봉투 열기" }).click();
  let state = await storage();
  if (
    !state.scores.some((e) => e.id === "g1:prediction-bonus") ||
    state.scores.some((e) => e.id === "g2:prediction-bonus")
  )
    throw new Error("Prediction bonus incorrect");
  await page.getByRole("button", { name: "우유", exact: true }).click();
  await calculation(["0.9", "2.3"], ["2944.44", "2600"], ["2944", "2600"], "B");
  await page.getByRole("button", { name: "주스", exact: true }).click();
  await calculation(["1", "0.25"], ["3200", "3600"], ["3200", "3600"], "A");
  await capture("chapter3-envelope");
  await complete(3);

  await open(4);
  await page.getByRole("button", { name: "입력 위로", exact: true }).click();
  await page.getByRole("button", { name: "계산 위로", exact: true }).click();
  await page.getByRole("button", { name: "계산 위로", exact: true }).click();
  await page.getByRole("button", { name: "흐름 확인하기" }).click();
  for (let i = 0; i < 3; i++)
    await page.getByRole("button", { name: "다음 흐름 따라가기" }).click();
  await page.getByRole("button", { name: "판단 규칙 확인하기" }).click();
  await page.getByLabel("상품 입력 칸", { exact: true }).check();
  await page.getByLabel("덜어내기 그림", { exact: true }).check();
  await page
    .getByLabel("mL를 L로 바꾸려면", { exact: true })
    .selectOption("divide1000");
  await page
    .getByLabel("1L당 가격은", { exact: true })
    .selectOption("price/amount");
  await page.getByLabel("알뜰 선택은", { exact: true }).selectOption("lower");
  await page.getByRole("button", { name: "설계도 완성하기" }).click();
  await capture("chapter4");
  await complete(4);

  await open(5);
  await page.getByRole("button", { name: "1L당 가격 비교하기" }).click();
  await page
    .getByRole("button", { name: "스피드 라운드 시작", exact: true })
    .click();
  const choices = ["A", "B", "A", "똑같다", "A"];
  for (let i = 0; i < 5; i++) {
    await page
      .getByRole("group", { name: "스피드 라운드 알뜰 선택" })
      .getByRole("button", { name: choices[i], exact: true })
      .click();
    if (i < 4) await page.getByRole("button", { name: "다음 상품 쌍" }).click();
  }
  await capture("chapter5");
  await complete(5);

  await open(6);
  const outputs = [
    "B의 1L당 가격은 2원",
    "A의 1L당 가격은 1,653원",
    "A의 1L당 가격은 0원 (몫 0.0006…)",
    "B의 1L당 가격은 600원",
    "A의 1L당 가격은 1,650원",
    "B의 1L당 가격은 2,400원",
  ];
  const causes = ["unit", "", "reverse", "multiply", "rounding", ""];
  for (let i = 0; i < 6; i++) {
    const card = page
      .getByRole("heading", { name: `AI의 답: ${outputs[i]}`, exact: true })
      .locator("..");
    await card
      .getByRole("button", {
        name: causes[i] ? "버그예요" : "맞아요",
        exact: true,
      })
      .click();
    if (causes[i]) {
      await card
        .getByLabel("고칠 계산 단계")
        .selectOption(String([2, 0, 2, 2, 3, 0][i]));
      await card.getByLabel("버그의 원인").selectOption(causes[i]);
    }
    await card.getByRole("button", { name: "판정과 원인 확인하기" }).click();
  }
  await page.getByLabel("상품 A 손계산 (원)", { exact: true }).fill("1653");
  await page.getByLabel("상품 B 손계산 (원)", { exact: true }).fill("2400");
  await page.getByRole("button", { name: "손계산 대조하기" }).click();
  await capture("chapter6");
  await complete(6);

  await open(7);
  await page
    .getByRole("group", { name: "소개할 사건 고르기" })
    .getByRole("button", { name: /^내 탐정기 사건/ })
    .click();
  await page
    .getByLabel("결론 문장", { exact: true })
    .fill("계산과 그림으로 큰 병 음료 A가 더 저렴함을 확인했어요.");
  await page.getByRole("button", { name: "보고서 봉인하기" }).click();
  const stars = [
    "계산이 정확해요",
    "그림으로 이유가 잘 보여요",
    "설명이 이해하기 쉬워요",
  ];
  for (let i = 0; i < 3; i++)
    await page
      .getByRole("button", {
        name: `${stars[i]} 별 ${i === 0 ? 2 : 3}개`,
        exact: true,
      })
      .click();
  await page
    .getByLabel("칭찬 한마디", { exact: true })
    .fill("그림이 또렷해서 이해하기 쉬웠어요.");
  await page
    .getByLabel("바라는 점 한마디", { exact: true })
    .fill("단위를 조금 더 크게 쓰면 좋겠어요.");
  await page.getByRole("button", { name: "동료 평가 저장하기" }).click();
  await page.getByRole("button", { name: "발표 화면 크게 보기" }).click();
  await page.getByRole("dialog", { name: "사건 보고서 발표" }).waitFor();
  await page.keyboard.press("Escape");
  await capture("chapter7");
  await complete(7);
  await page.getByRole("button", { name: "교사실", exact: true }).click();
  await page
    .getByRole("button", { name: "7장 동료 평가", exact: true })
    .click();
  await page.getByRole("button", { name: "8점 반영하기", exact: true }).click();
  if (
    !(await storage()).scores.some(
      (e) => e.id === "g2:peer-g1:g2" && e.delta === 8,
    )
  )
    throw new Error("Peer award not applied");

  await open(8);
  const slider = page.getByRole("slider", { name: "실제로 마신 우유의 양" });
  await slider.focus();
  for (let i = 0; i < 30; i++) await page.keyboard.press("ArrowLeft");
  await page.getByText(/실제 1L당 가격이 더 높아요!/).waitFor();
  for (let i = 0; i < 10; i++) await page.keyboard.press("ArrowRight");
  await page
    .getByText("이만큼 마신다면 큰 우유의 실제 1L당 가격이 더 낮아요.", {
      exact: true,
    })
    .waitFor();
  await page
    .getByRole("group", { name: "가족에게 맞는 상품" })
    .getByRole("button", { name: "A 작은 우유 900mL" })
    .click();
  await page
    .getByLabel("선택한 이유", { exact: true })
    .selectOption("유통기한");
  await page.getByRole("button", { name: "가족 선택 기록하기" }).click();
  const headlines = [
    "한 병을 사면 한 병 더! 1+1",
    "대용량 특가! 큰 병이 더 저렴할까?",
    "세 병 묶음! 이번에도 광고에 속은 걸까?",
  ];
  for (let i = 0; i < 3; i++) {
    const card = page
      .getByRole("heading", { name: headlines[i], exact: true })
      .locator("..");
    if (i === 0) {
      await card
        .getByRole("group", { name: `${headlines[i]} 알뜰 선택` })
        .getByRole("button", { name: "A", exact: true })
        .click();
      await card
        .getByRole("button", { name: "광고 속 알뜰 선택 확인하기" })
        .click();
      for (let h = 1; h <= 3; h++)
        await card
          .getByRole("button", { name: new RegExp(`${h}단계 힌트 보기`) })
          .click();
    }
    await card
      .getByRole("group", { name: `${headlines[i]} 알뜰 선택` })
      .getByRole("button", { name: i === 2 ? "A" : "B", exact: true })
      .click();
    await card
      .getByRole("button", { name: "광고 속 알뜰 선택 확인하기" })
      .click();
  }
  await page
    .getByLabel("앞으로 나는 이렇게 선택할 거예요", { exact: true })
    .fill("단위가격을 확인하고 다 마실 수 있는 만큼만 사요.");
  await page.getByRole("button", { name: "소비 다짐 남기기" }).click();
  await capture("chapter8");
  await complete(8);
  await page
    .getByRole("heading", { name: "수석 탐정 수료증", exact: true })
    .waitFor();
  await capture("certificate");
  state = await storage();
  if (
    state.progress.g1.badges.length !== 8 ||
    state.scores.find((e) => e.id === "g1:c8-ad-one-plus-one").delta !== 4
  )
    throw new Error("Badges or hint reward incorrect");
  const originalScore = state.scores
    .filter((e) => e.participantId === "g1")
    .reduce((a, e) => a + e.delta, 0);
  await page.reload();
  await page
    .getByRole("navigation", { name: "사건 파일 1장부터 8장" })
    .getByRole("button", { name: /^8장 / })
    .click();
  await page
    .getByRole("heading", { name: "수석 탐정 수료증", exact: true })
    .waitFor();
  state = await storage();
  if (
    state.scores
      .filter((e) => e.participantId === "g1")
      .reduce((a, e) => a + e.delta, 0) !== originalScore
  )
    throw new Error("Score duplicated on reload");
  if (errors.length) throw new Error(JSON.stringify(errors));
  await fs.writeFile(
    resolve(outputDir, "full-flow-state.json"),
    JSON.stringify(state, null, 2),
  );
  await fs.writeFile(
    resolve(outputDir, "full-flow-report.json"),
    JSON.stringify(
      {
        checks,
        originalScore,
        badgeCount: state.progress.g1.badges.length,
        errors,
      },
      null,
      2,
    ),
  );
  console.log(
    JSON.stringify({
      checks,
      originalScore,
      badges: state.progress.g1.badges.length,
      errors,
    }),
  );
} catch (error) {
  await page.screenshot({
    path: resolve(outputDir, "failure.png"),
    fullPage: true,
  });
  console.error("FAIL", error.message, "browser errors:", errors);
  throw error;
} finally {
  await browser.close();
  server?.kill();
}

import { useEffect } from "react";
import { useLearning } from "../app/useLearning";
import { badgeNames, chapters, principles } from "../data/cases";
import { chapterReady } from "../lib/learning";
import { Icon } from "../components/ui/Icon";
import { ChapterEmblem } from "../components/game/ChapterEmblem";
import { Chapter1 } from "../chapters/Chapter1";
import { Chapter2 } from "../chapters/Chapter2";
import { Chapter3 } from "../chapters/Chapter3";
import { Chapter4 } from "../chapters/Chapter4";
import { Chapter5 } from "../chapters/Chapter5";
import { Chapter6 } from "../chapters/Chapter6";
import { Chapter7 } from "../chapters/Chapter7";
import { Chapter8, Certificate } from "../chapters/Chapter8";
import type { ChapterId } from "../types";
import styles from "./Screens.module.css";
import s from "../components/game/Lesson.module.css";
import { StoryScene } from "../components/game/StoryScene";
import { canOpenChapter } from "../lib/progression";

const steps = ["사건 소개", "수사하기", "사건 해결"];
export function ChapterScreen({
  onMap,
  onOpen,
}: {
  onMap: () => void;
  onOpen?: (id: ChapterId) => void;
}) {
  const { state, note, patch, dispatch, id } = useLearning();
  const chapter = chapters.find((item) => item.id === state.currentChapter)!;
  const step = note.steps[chapter.id] ?? 0;
  const setStep = (next: number) =>
    patch({
      steps: { ...note.steps, [chapter.id]: Math.max(0, Math.min(2, next)) },
    });
  const ready = chapterReady(state, id, chapter.id);
  const completed = state.progress[id]?.completedChapters.includes(chapter.id);
  const next = chapter.id < 8 ? ((chapter.id + 1) as ChapterId) : undefined;
  useEffect(() => {
    if (!state.settings.projection || state.mode !== "teacher") return;
    function handleKey(event: KeyboardEvent) {
      const target = event.target as HTMLElement;
      if (
        target.closest(
          'input, select, textarea, [contenteditable="true"], [role="slider"]',
        ) ||
        event.altKey ||
        event.ctrlKey ||
        event.metaKey ||
        document.querySelector('[role="alertdialog"], [role="dialog"]')
      )
        return;
      if (event.key === "ArrowLeft" || event.key === "ArrowRight") {
        event.preventDefault();
        setStep(step + (event.key === "ArrowRight" ? 1 : -1));
      }
    }
    document.addEventListener("keydown", handleKey);
    return () => document.removeEventListener("keydown", handleKey);
  }, [state.settings.projection, state.mode, step, chapter.id, note.steps]);
  return (
    <section
      className={`${styles.chapterScreen} stage-${chapter.color}`}
      data-student={state.mode !== "teacher" || undefined}
    >
      {state.mode === "teacher" && (
        <button className="text-button" onClick={onMap}>
          <Icon name="grid" size={17} />
          사건 지도로 돌아가기
        </button>
      )}
      <div className={styles.chapterBanner}>
        <span className={styles.bigStage}>
          <small>MISSION</small>
          {String(chapter.id).padStart(2, "0")}
        </span>
        <div>
          <span className="eyebrow">
            사건 파일 {String(chapter.id).padStart(2, "0")} ·{" "}
            {chapter.stageLabel}
          </span>
          <h1>{chapter.title}</h1>
          <p>{chapter.subtitle}</p>
        </div>
        <ChapterEmblem chapter={chapter.id} className={styles.bannerEmblem} />
      </div>
      <nav className={styles.introSteps} aria-label="사건 진행 단계">
        {steps.map((label, index) => (
          <button
            key={label}
            onClick={() => setStep(index)}
            aria-current={step === index ? "step" : undefined}
          >
            <span>{index + 1}</span>
            {label}
          </button>
        ))}
      </nav>
      {step === 0 && (
        <>
          <StoryScene
            key={chapter.id}
            chapter={chapter.id}
            onStart={() => setStep(1)}
          />
          <div className={styles.briefing}>
            <span className="eyebrow">사건 브리핑 · 핵심 질문</span>
            <h2>{chapter.question}</h2>
            <ol className={styles.missionList}>
              {chapter.missions.map((mission, i) => (
                <li key={mission}>
                  <span>{String(i + 1).padStart(2, "0")}</span>
                  {mission}
                </li>
              ))}
            </ol>
            <div className={styles.briefingStamp}>수사 준비</div>
          </div>
        </>
      )}
      {step === 1 && (
        <>
          {(ready || state.mode === "teacher") && (
            <div className={styles.missionHud}>
              <span className={styles.guidePortrait} aria-hidden="true" />
              <div>
                <span className="eyebrow">
                  {ready
                    ? "미션 완료 · 배지를 받을 준비가 됐어!"
                    : "탐정단, 출동!"}
                </span>
                <h2>
                  {ready
                    ? "사건 해결 단계에서 배지를 받아요"
                    : "미션을 해결하고 단서를 모아 봐요"}
                </h2>
              </div>
              {ready && (
                <button className="btn primary" onClick={() => setStep(2)}>
                  배지 받으러 가기
                  <Icon name="badge" size={20} />
                </button>
              )}
            </div>
          )}
          {chapter.id === 1 ? (
            <Chapter1 />
          ) : chapter.id === 2 ? (
            <Chapter2 />
          ) : chapter.id === 3 ? (
            <Chapter3 />
          ) : chapter.id === 4 ? (
            <Chapter4 />
          ) : chapter.id === 5 ? (
            <Chapter5 />
          ) : chapter.id === 6 ? (
            <Chapter6 />
          ) : chapter.id === 7 ? (
            <Chapter7 />
          ) : (
            <Chapter8 />
          )}
        </>
      )}
      {step === 2 && (
        <div className={s.stack}>
          {completed ? (
            <div className={s.solved}>
              <span className={s.clearBanner} aria-hidden="true">
                CASE CLEAR
              </span>
              <Icon name="badge" size={65} />
              <h2>사건 해결!</h2>
              <h3>{badgeNames[chapter.id - 1]} 배지를 받았어요</h3>
              <p>
                이 장에서 모은 단서:{" "}
                {state.scores
                  .filter(
                    (entry) =>
                      entry.participantId === id &&
                      entry.chapter === chapter.id,
                  )
                  .reduce((sum, entry) => sum + entry.delta, 0)}
                점
              </p>
              <p>{principles[chapter.id - 1]}</p>
              <span className={s.stamp}>알뜰 탐정 사무소 · 해결 확인</span>
            </div>
          ) : (
            <section className={s.card}>
              <h2>사건 해결 기록을 남겨요</h2>
              <p>
                {ready
                  ? "미션을 모두 확인했어요. 배지와 사건 해결 단서 20점을 받아요."
                  : "아직 남은 미션이 있어요. 수사하기로 돌아가 각 활동을 마저 살펴봐요."}
              </p>
              <ul>
                {chapter.missions.map((mission) => (
                  <li key={mission}>{mission}</li>
                ))}
              </ul>
              <button
                className="btn primary"
                disabled={!ready}
                onClick={() =>
                  dispatch({
                    type: "complete",
                    participantId: id,
                    chapter: chapter.id,
                  })
                }
              >
                사건 해결하고 배지 받기
              </button>
            </section>
          )}
          {next && (
            <button
              className="btn primary"
              disabled={!canOpenChapter(state, next)}
              onClick={() => onOpen?.(next)}
            >
              다음 사건 · {next}장<Icon name="arrow" size={18} />
            </button>
          )}
        </div>
      )}
      {step === 2 && completed && <StoryScene chapter={chapter.id} ending />}
      {step === 2 && chapter.id === 8 && completed && <Certificate />}
      <div className={styles.introPager}>
        <button
          className="btn secondary"
          disabled={step === 0}
          onClick={() => setStep(step - 1)}
        >
          이전 단계
        </button>
        <span>
          {step + 1} / {steps.length}
        </span>
        <button
          className="btn primary"
          disabled={step === 2}
          onClick={() => setStep(step + 1)}
        >
          다음 단계
          <Icon name="arrow" size={18} />
        </button>
      </div>
      {state.mode === "teacher" && state.settings.projection && (
        <p className={styles.keyboardHelp}>
          키보드 ← →로 장 안의 단계를 넘길 수 있어요.
        </p>
      )}
    </section>
  );
}

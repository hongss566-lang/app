export type Mode = "teacher" | "group" | "solo";
export type ChapterId = 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8;
export type Theme = "light" | "dark" | "system";
export type CollectionKind = "prediction" | "peerReview" | "familyChoice";

export interface Group {
  id: string;
  name: string;
}
export interface Progress {
  completedChapters: ChapterId[];
  badges: string[];
}
export interface ScoreEntry {
  id: string;
  participantId: string;
  delta: number;
  source: "teacher" | "mission" | "peer";
  chapter?: ChapterId;
}
export type Choice = "A" | "B" | "same";
export interface Product {
  name: string;
  price: string;
  amount: string;
  unit: "L" | "mL";
}
export interface ProductPair {
  A: Product;
  B: Product;
}
export interface Prediction {
  choice: Choice;
  reason: string;
  eligible: boolean;
}
export interface ScoopRecord {
  prediction: string;
  locked: boolean;
  scoops: number;
  done: boolean;
}
export interface CalculationRecord {
  stage: number;
  place: 1 | 10;
  entries: string[][];
}
export interface Rule {
  left: "A" | "B";
  right: "A" | "B";
  operator: "<" | ">" | "=";
  target: "A" | "B";
}
export interface PeerReview {
  id: string;
  from: string;
  to: string;
  stars: [number, number, number];
  praise: string;
  wish: string;
  applied: boolean;
}
export interface FamilyAnswer {
  choice: "A" | "B";
  reason: string;
}
export interface Report {
  pair: ProductPair;
  source: string;
  event: string;
  evidenceA: string;
  evidenceB: string;
  principle: string;
  conclusion: string;
}
export interface Notebook {
  missionPages?: Partial<Record<ChapterId, number>>;
  briefingAnswers?: Record<string, string>;
  steps: Partial<Record<ChapterId, number>>;
  hints: Record<string, number>;
  prediction?: Prediction;
  contexts: string[];
  ownContext: string;
  introGuess: string;
  fractionIndex: number;
  scoops: Record<string, ScoopRecord>;
  selectedCase: string;
  calculations: Record<string, CalculationRecord>;
  shelfPrices: [string, string];
  outline: {
    order: string[];
    flowVerified: boolean;
    flowStep: number;
    rule: Rule;
    ruleVerified: boolean;
    features: string[];
    blanks: string[];
    storyVerified: boolean;
  };
  toolPair: ProductPair;
  toolCalculated: boolean;
  speed?: {
    startedAt: number;
    elapsedMs: number;
    answers: (Choice | "timeout")[];
    timed: boolean;
    finished: boolean;
  };
  bugs: Record<string, { verdict: string; cause: string; solved: boolean }>;
  hand: [string, string];
  handVerified: boolean;
  report?: Report;
  reportSaved: boolean;
  milkAmount: string;
  milkExplored: boolean;
  familyIndex: number;
  families: Record<string, FamilyAnswer>;
  ads: Record<string, Choice>;
  pledge: string;
  pledgeSaved: boolean;
}
export interface AppState {
  version: 1;
  mode: Mode | null;
  groups: Group[];
  nickname: string;
  activeGroupId: string;
  currentChapter: ChapterId;
  openChapters: ChapterId[];
  settings: {
    theme: Theme;
    sound: boolean;
    projection: boolean;
    showAnswers: boolean;
    speedLimit: boolean;
  };
  teacher: { selectedGroupId: string; collectionKind: CollectionKind };
  scores: ScoreEntry[];
  progress: Record<string, Progress>;
  learning: Record<string, Notebook>;
  reviews: PeerReview[];
  envelopeRevealed: boolean;
}

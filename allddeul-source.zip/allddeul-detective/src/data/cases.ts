import type { ChapterId, ProductPair } from "../types";

export interface Chapter {
  id: ChapterId;
  stage: string;
  stageLabel: string;
  color: "preview" | "research" | "outline" | "make" | "present" | "together";
  title: string;
  subtitle: string;
  question: string;
  missions: string[];
}

export const chapters: Chapter[] = [
  {
    id: 1,
    stage: "P",
    stageLabel: "발견",
    color: "preview",
    title: "수상한 가격표",
    subtitle: "첫 번째 단서를 찾아요",
    question: "양이 다른 두 음료, 어느 쪽이 정말 더 저렴할까요?",
    missions: [
      "어느 쪽이 더 저렴할지 예측 봉투에 담기",
      "같은 양으로 비교해야 하는 생활 속 상황 찾기",
    ],
  },
  {
    id: 2,
    stage: "R",
    stageLabel: "원리 탐구",
    color: "research",
    title: "나눴는데 왜 커졌지?",
    subtitle: "분수의 나눗셈을 탐구해요",
    question: "1보다 작은 수로 나누면 몫은 어떻게 될까요?",
    missions: [
      "컵으로 몇 번 덜어낼지 예측하기",
      "덜어내기로 분수의 나눗셈 원리 찾기",
    ],
  },
  {
    id: 3,
    stage: "R",
    stageLabel: "계산 탐구",
    color: "research",
    title: "1L로 맞춰라!",
    subtitle: "계산으로 봉투를 열어요",
    question: "두 상품을 모두 1L로 맞추면 어떤 차이가 날까요?",
    missions: [
      "단위를 맞추고 1L당 가격 계산하기",
      "어림한 가격을 비교하고 예측 봉투 열기",
      "다른 상품과 가격표로 연습하기",
    ],
  },
  {
    id: 4,
    stage: "O",
    stageLabel: "설계",
    color: "outline",
    title: "탐정기 설계도",
    subtitle: "나만의 판단 규칙을 만들어요",
    question: "탐정기에 어떤 순서와 규칙을 알려 주면 좋을까요?",
    missions: [
      "입력·계산·판단·시각화 순서 맞추기",
      "알뜰 선택 규칙 조립하기",
      "나만의 탐정기 기능과 프롬프트 설계하기",
    ],
  },
  {
    id: 5,
    stage: "M",
    stageLabel: "만들기",
    color: "make",
    title: "탐정기 조립",
    subtitle: "알뜰 선택 도장을 찍어요",
    question: "상품 정보를 넣으면 알뜰 선택을 찾아낼 수 있을까요?",
    missions: [
      "두 상품의 1L당 가격 비교하기",
      "반짝마트 스피드 라운드 도전하기",
    ],
  },
  {
    id: 6,
    stage: "M",
    stageLabel: "고치기",
    color: "make",
    title: "버그 사냥",
    subtitle: "계산 속 숨은 실수를 찾아요",
    question: "탐정기의 답이 맞는지 어떻게 확인할까요?",
    missions: [
      "1L 덜어내기 그림으로 이유 설명하기",
      "AI 답에서 버그와 원인 찾기",
      "손계산과 탐정기 결과 대조하기",
    ],
  },
  {
    id: 7,
    stage: "P",
    stageLabel: "발표",
    color: "present",
    title: "사건 브리핑",
    subtitle: "친구들에게 증거를 보여 줘요",
    question: "우리의 알뜰 선택을 계산과 그림으로 설명할 수 있을까요?",
    missions: [
      "증거와 결론을 담은 보고서 만들기",
      "발표하고 친구 탐정기에 의견 전하기",
    ],
  },
  {
    id: 8,
    stage: "T",
    stageLabel: "성찰",
    color: "together",
    title: "선택의 갈림길",
    subtitle: "가격 너머의 이유를 찾아요",
    question: "1L당 가격이 낮으면 언제나 합리적인 선택일까요?",
    missions: [
      "마신 양에 따른 실제 가격 비교하기",
      "가족 상황과 가상 광고 속 선택 살펴보기",
      "알뜰 소비 다짐과 탐정 수료증 완성하기",
    ],
  },
];

export const productCases = [
  {
    id: "drink",
    label: "음료",
    A: { name: "큰 병 음료", price: "2480", amount: "1.5", unit: "L" },
    B: { name: "작은 병 음료", price: "1200", amount: "500", unit: "mL" },
  },
  {
    id: "milk",
    label: "우유",
    A: { name: "우유 900mL", price: "2650", amount: "900", unit: "mL" },
    B: { name: "우유 2.3L", price: "5980", amount: "2.3", unit: "L" },
  },
  {
    id: "juice",
    label: "주스",
    A: { name: "주스 1L", price: "3200", amount: "1", unit: "L" },
    B: { name: "주스 250mL", price: "900", amount: "250", unit: "mL" },
  },
] as const;

export const contextCards = [
  "라면 한 봉지와 5개 묶음",
  "우유 200mL와 1L",
  "과자 작은 봉지와 큰 봉지",
  "길이가 다른 리본의 가격",
];
export const fractionCases = [
  { id: "six-half", level: 1, a: [6, 1], b: [1, 2] },
  { id: "three-quarter", level: 1, a: [3, 1], b: [1, 4] },
  { id: "one-eighth", level: 1, a: [1, 1], b: [1, 8] },
  { id: "fraction-eighth", level: 2, a: [3, 4], b: [1, 8] },
  { id: "mixed-quarter", level: 2, a: [3, 2], b: [1, 4] },
  { id: "partial-cup", level: 3, a: [1, 1], b: [3, 8] },
] as const;
export const flowOrder = ["입력", "계산", "판단", "시각화"];
export const featureChoices = [
  "상품 입력 칸",
  "L/mL 단위 맞추기",
  "알뜰 선택 표시",
  "덜어내기 그림",
];
export const speedCases: (ProductPair & { id: string })[] = [
  { ...productCases[0], id: "speed-drink" },
  { ...productCases[1], id: "speed-milk" },
  { ...productCases[2], id: "speed-juice" },
  {
    id: "speed-equal",
    A: { name: "노란 음료", price: "1800", amount: "750", unit: "mL" },
    B: { name: "초록 음료", price: "2400", amount: "1", unit: "L" },
  },
  {
    id: "speed-water",
    A: { name: "큰 병 생수", price: "1700", amount: "2", unit: "L" },
    B: { name: "작은 병 생수", price: "600", amount: "500", unit: "mL" },
  },
];
export const speedSeconds = 150;
export const bugCauses = [
  { id: "unit", text: "mL를 L로 바꾸지 않았어요" },
  { id: "reverse", text: "양을 가격으로 나누었어요" },
  { id: "multiply", text: "양으로 나누지 않고 곱했어요" },
  { id: "rounding", text: "반올림할 자리를 잘못 정했어요" },
];
export const bugCases = [
  {
    id: "unit",
    output: "B의 1L당 가격은 2원",
    correct: false,
    cause: "unit",
    explanation: "500mL = 0.5L로 바꾼 뒤 1,200 ÷ 0.5 = 2,400원으로 구해요.",
  },
  {
    id: "right-a",
    output: "A의 1L당 가격은 1,653원",
    correct: true,
    cause: "",
    explanation:
      "2,480 ÷ 1.5 = 1,653.33…을 반올림하여 일의 자리까지 나타냈어요.",
  },
  {
    id: "reverse",
    output: "A의 1L당 가격은 0원 (몫 0.0006…)",
    correct: false,
    cause: "reverse",
    explanation:
      "1.5 ÷ 2,480으로 거꾸로 나누었어요. 가격을 양으로 나누어야 해요.",
  },
  {
    id: "multiply",
    output: "B의 1L당 가격은 600원",
    correct: false,
    cause: "multiply",
    explanation:
      "1,200에 0.5를 곱했어요. 0.5로 나누는 것은 2를 곱하는 것과 같아요.",
  },
  {
    id: "rounding",
    output: "A의 1L당 가격은 1,650원",
    correct: false,
    cause: "rounding",
    explanation:
      "십의 자리까지 반올림한 값이에요. 이번 조건은 일의 자리까지이므로 1,653원이에요.",
  },
  {
    id: "right-b",
    output: "B의 1L당 가격은 2,400원",
    correct: true,
    cause: "",
    explanation: "1,200 ÷ 0.5 = 2,400으로 정확하게 구했어요.",
  },
];
export const familyCases = [
  {
    id: "grandmother",
    title: "혼자 사는 할머니",
    text: "우유를 매일 조금씩 드세요. 유통기한 안에 다 마실 수 있을까요?",
  },
  {
    id: "four",
    title: "우유를 즐기는 4인 가족",
    text: "가족 네 명이 아침마다 우유를 마셔요. 어떤 양이 알맞을까요?",
  },
  {
    id: "fridge",
    title: "냉장고가 작은 집",
    text: "냉장고에 큰 병을 세울 자리가 넉넉하지 않아요.",
  },
  {
    id: "travel",
    title: "다음 주 여행 가는 가족",
    text: "며칠 뒤 집을 오래 비워요. 남는 우유가 생기지 않게 골라 봐요.",
  },
];
export const familyReasons = [
  "유통기한",
  "보관 공간",
  "버리는 양",
  "들고 오기",
];
// 아래 광고의 상품명·가격·양은 수업을 위해 만든 가상 예시이다.
export const adCases: (ProductPair & { id: string; headline: string })[] = [
  {
    id: "one-plus-one",
    headline: "한 병을 사면 한 병 더! 1+1",
    A: {
      name: "노란 과일 음료 400mL 두 병 (총 800mL)",
      price: "2400",
      amount: "800",
      unit: "mL",
    },
    B: {
      name: "초록 과일 음료 1L 한 병",
      price: "2700",
      amount: "1",
      unit: "L",
    },
  },
  {
    id: "large",
    headline: "대용량 특가! 큰 병이 더 저렴할까?",
    A: { name: "구름 음료 큰 병", price: "5400", amount: "1.8", unit: "L" },
    B: { name: "구름 음료 작은 병", price: "1620", amount: "600", unit: "mL" },
  },
  {
    id: "bundle",
    headline: "세 병 묶음! 이번에도 광고에 속은 걸까?",
    A: {
      name: "별빛 음료 250mL 세 병 (총 750mL)",
      price: "2850",
      amount: "750",
      unit: "mL",
    },
    B: {
      name: "별빛 음료 500mL 한 병",
      price: "2000",
      amount: "500",
      unit: "mL",
    },
  },
];
export const reviewCriteria = [
  "계산이 정확해요",
  "그림으로 이유가 잘 보여요",
  "설명이 이해하기 쉬워요",
];
export const badgeNames = [
  "예측의 돋보기",
  "분수 탐험가",
  "단위가격 해결사",
  "규칙 설계자",
  "탐정기 제작자",
  "버그 사냥꾼",
  "증거 발표자",
  "합리적 소비 탐정",
];
export const principles = [
  "양이 다르면 같은 양을 기준으로 비교할 필요가 있어요.",
  "분수로 나누는 것은 나누는 수의 분자와 분모를 바꾸어 곱하는 것과 같아요.",
  "가격을 양(L)으로 나누면 1L당 가격을 구할 수 있어요.",
  "입력 → 계산 → 판단 → 시각화 순서로 규칙을 설계해요.",
  "어림하기 전의 단위가격이 더 작은 상품을 알뜰 선택으로 판단해요.",
  "단위·나누는 순서·반올림할 자리를 확인하면 계산 실수를 찾을 수 있어요.",
  "나눗셈 식과 그림은 내 선택의 이유를 설명하는 증거가 돼요.",
  "실제로 쓸 양과 유통기한, 보관 공간까지 생각해야 합리적인 선택이에요.",
];
export const studentPrompts = {
  make: "두 상품을 비교하는 '알뜰 소비 탐정기' 웹앱을 만들어 줘. 상품 A와 B 각각 이름, 가격(원), 양, 단위(L 또는 mL)를 입력하는 칸을 만들어 줘. 단위가 mL이면 1000으로 나누어 L로 바꿔 줘. (가격) ÷ (양)으로 1L당 가격을 구하고 반올림하여 일의 자리까지 보여 줘. 1L당 가격이 더 낮은 상품에 '알뜰 선택' 표시를 해 줘. 같으면 '같아요'라고 알려 줘.",
  debug:
    "탐정기에 '덜어내기 그림'을 추가해 줘. 1L 길이의 막대를 그리고, 그 안에 상품 한 개의 양만큼 칸을 차례로 채워 줘. 1L 안에 상품이 몇 개 들어가는지(1 ÷ 양) 숫자로도 보여 줘. 1L당 가격 = 상품 가격 × (1 ÷ 양)이라는 식을 그림 아래에 적어 줘. 내가 손으로 계산한 값은 A ____원, B ____원이야. 탐정기 결과가 다르면 어디가 틀렸는지 찾아서 고쳐 줘.",
};

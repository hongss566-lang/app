import { Children, createContext, useContext, type ReactNode } from "react";
import { useLearning } from "../../app/useLearning";
import { adventure } from "../../data/adventure";
import type { ChapterId } from "../../types";
import { StoryScene } from "./StoryScene";
import { Icon } from "../ui/Icon";
import s from "./Story.module.css";

const Navigation = createContext<(page: number) => void>(() => {});
export const useMissionNavigation = () => useContext(Navigation);

export function MissionTrail({
  chapter,
  children,
}: {
  chapter: ChapterId;
  children: ReactNode;
}) {
  const { state, note, patch } = useLearning();
  const slots: { index: number; child: ReactNode }[] = [];
  Children.forEach(children, (child, index) => {
    if (child !== null && child !== undefined && typeof child !== "boolean")
      slots.push({ index, child });
  });
  const remembered = note.missionPages?.[chapter] ?? 0;
  const current = slots.find((slot) => slot.index === remembered) ?? slots[0];
  const order = slots.indexOf(current);
  const story = adventure[chapter];
  const goTo = (index: number) =>
    patch({ missionPages: { ...note.missionPages, [chapter]: index } });
  return (
    <Navigation.Provider value={goTo}>
      {state.mode === "teacher" ? (
        <div className={s.allMissions}>{children}</div>
      ) : (
        <div className={s.trail}>
          <nav className={s.missionNav} aria-label="이번 장의 미션">
            {slots.map(({ index }, position) => (
              <button
                key={index}
                onClick={() => goTo(index)}
                aria-current={current.index === index ? "step" : undefined}
              >
                <span>{position + 1}</span>
                {story.missions[index] ?? "추가 탐험"}
              </button>
            ))}
          </nav>
          <StoryScene
            chapter={chapter}
            line={story.guides[current.index] ?? story.guides[0]}
          />
          {slots.map(({ index, child }) => (
            <div key={index} hidden={index !== current.index}>
              {child}
            </div>
          ))}
          <div className={s.missionPager}>
            <button
              className="btn secondary"
              disabled={order === 0}
              onClick={() => goTo(slots[order - 1].index)}
            >
              앞 미션
            </button>
            <span>
              {order + 1} / {slots.length} 미션
            </span>
            <button
              className="btn primary"
              disabled={order === slots.length - 1}
              onClick={() => goTo(slots[order + 1].index)}
            >
              다음 미션
              <Icon name="arrow" size={18} />
            </button>
          </div>
        </div>
      )}
    </Navigation.Provider>
  );
}
